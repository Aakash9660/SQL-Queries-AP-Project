package com.smartdocs.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.GLAccount;
@Repository
public interface GLAccountRepository extends JpaRepository<GLAccount,String> {


	@Query("select gl from GLAccount gl where "
			+ "(:query is null or lower(gl.code) like lower(concat('%', cast(:query as string),  '%' ))) " 
			+ "or (:query is null or lower(gl.description) like lower(concat('%', cast(:query as string),  '%' )))" )
	Page<GLAccount> getGLAccountPage(String query, Pageable page);
	
	Optional<GLAccount> findOneByCode(String code);
	
}
