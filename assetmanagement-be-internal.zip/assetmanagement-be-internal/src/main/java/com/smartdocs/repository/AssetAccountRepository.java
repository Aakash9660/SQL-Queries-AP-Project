package com.smartdocs.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.group.AssetAccountProjection;
import com.smartdocs.sql.dto.AccountCustomInf;

@Repository
public interface AssetAccountRepository extends JpaRepository<AssetAccount, Long> {

	List<AssetAccount> findAllByAssetCodeAndAccountNumber(String assetCode, String accountNumber);

	AssetAccount findOneByAssetCodeAndAccountNumberAndVendorId(String assetCode, String accountNumber, String vendorId);

	@Query(value = "select * from asset_account ac where ac.account_number=:accountNumber and ac.vendor_id =:vendorId limit 1", nativeQuery = true)
	AssetAccount findOneByAccountNumberAndVendorId(String accountNumber, String vendorId);

	@Query("select case when (count(assetAcc) > 0) " + "then " + "(select case when (count(script) > 0) " + "then "
			+ "true " + "else " + "false " + "end " + "from VendorScript script where script.vendorId = :vendorId) "
			+ "else " + "false " + "end " + "from AssetAccount assetAcc "
			+ "where assetAcc.vendorId = :vendorId and assetAcc.channel = :channel")
	boolean isAssetAccountOrVendorScriptExistsforVendor(String vendorId, String channel);

	@Query(value = " select vs.version from vendor_script vs where vs.vendor_id = :vendorId and vs.version > :version limit 1", nativeQuery = true)
	Integer getVersion(String vendorId, int version);

	@Query(value = " select ac.accountNumber from AssetAccount ac where "
			+ "(lower(ac.accountNumber) like lower(concat('%', cast(:accountNumber as string), '%' )))")
	List<String> findByAccountNo(String accountNumber);

	List<AssetAccount> findByVendorId(String vendorId);

	boolean existsByAssetCodeAndAccountNumberAndVendorId(String assetCode, String accountNo, String vendorId);

	@Query("select distinct(assetCode) from AssetAccount where vendorId = :vendorId")
	Set<String> findVaultByVendorId(String vendorId);

	Page<AssetAccount> findByAccountNumber(String accountNumber, Pageable page);

	@Modifying
	@Query(value = "UPDATE asset_account SET lmd_checked = NULL WHERE lmd_checked IS NOT NULL", nativeQuery = true)
	void setlmdCheckedNullWherelmdCheckedNotNull();

	@Modifying
	@Transactional
	@Query(value = "UPDATE asset_account SET lmd_checked = NULL WHERE account_number =:accountNo AND asset_code =:assetCode AND vendor_id =:vendorId", nativeQuery = true)
	void setlmdCheckedNull(String assetCode, String accountNo, String vendorId);

	@Query("select ac from AssetAccount ac where "
			+ "(:assetQuery is null or lower(ac.assetCode) like lower(concat('%', cast(:assetQuery as string), '%' ))) "
			+ "and ac.vendorId in"
			+ " ( select v.vendorId from Vendor v where (:vendorQuery is null or lower(v.vendorId) like lower(concat('%', cast(:vendorQuery as string), '%' ))) or "
			+ "  (:vendorQuery is null or lower(v.name) like lower(concat('%', cast(:vendorQuery as string), '%' ))) )"
			+ "and (:accountNumber is null or lower(ac.accountNumber) like lower(concat('%', cast(:accountNumber as string), '%' ))) "
			+ " and ac.schedule is :schedule and "
			+ " lower(ac.channel) like lower(concat('%', cast(:channel as string), '%' )) " + " and ac.assetCode in "
			+ "(select a.assetCode from Asset a where "
			+ " (:assetQuery is null or lower(a.name) like lower(concat('%', cast(:assetQuery as string), '%' )))) ")
	List<AssetAccount> fetchAssetAccountDetails(String assetQuery, String vendorQuery, String accountNumber,
			String channel, boolean schedule);

	@Query("select new com.smartdocs.model.group.AssetAccountProjection(ac.assetCode,a.name,a.address,ac.accountNumber,ac.sendToExternal,ac.channel,ac.frequency,g,c) from AssetAccount ac "
			+ "left join Asset a on a.assetCode = ac.assetCode " + "left join Vendor v on v.vendorId = ac.vendorId "
			+ "left join GLAccount g on g.code = ac.glAccount " + "left join CostCenter c on c.code = ac.costCenter "
			+ "where ((:assetQuery is null or lower(a.name) like lower(concat('%', cast(:assetQuery as string), '%' ))) "
			+ " or (:assetQuery is null or lower(a.name) like lower(concat('%', cast(:assetQuery as string), '%' ))) )"
			+ "and (:vendorId is null or v.vendorId = :vendorId)"
			+ " and (:accountNumber is null or lower(ac.accountNumber) like lower(concat('%', cast(:accountNumber as string), '%' )))")
	Page<AssetAccountProjection> findAssetAccountData(String assetQuery, String accountNumber, String vendorId,
			Pageable pageable);

	@Query(value = "SELECT v.vendor_id as VendorId,v.name as VendorName ,ac.account_number as AccountNumber FROM asset_account ac "
			+ " inner join Vendor v on v.vendor_id = ac.vendor_id " + " where ac.asset_code =:assetCode "
			+ " and (:channel is null or cast(:channel as TEXT) = ac.channel )"
			+ "	and	((:vendorQuery is null or lower(v.vendor_id) like lower(concat('%', cast(:vendorQuery as TEXT),  '%' )))"
			+ " or (:vendorQuery is null or lower(v.name) like lower(concat('%', cast(:vendorQuery as TEXT),  '%' ))))"
			+ " GROUP by v.vendor_id,v.name,ac.account_number ", nativeQuery = true)
	List<AccountCustomInf> findDetailsByAssetCode(String assetCode, String channel, String vendorQuery);
}
