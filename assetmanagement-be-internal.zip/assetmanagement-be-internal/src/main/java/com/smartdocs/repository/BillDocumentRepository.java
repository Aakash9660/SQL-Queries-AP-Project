package com.smartdocs.repository;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.BillDocument;
import com.smartdocs.model.group.BillDataRequest;
import com.smartdocs.sql.dto.BillHistoryInf;
import com.smartdocs.sql.dto.OneYearBillInf;

@Repository
public interface BillDocumentRepository extends JpaRepository<BillDocument, Long> {
	 
	List<BillDocument> findByAssetCodeAndAccountNumberAndVendorId(String assetCode, String accountNumber,
			String vendorId);

	@Query("select new com.smartdocs.model.group.BillDataRequest( b, v, g, c ,ac,a) from BillDocument b "
			+ "left join Vendor v on v.vendorId =  b.vendorId " + "left join GLAccount g on g.code = b.glAccount "
			+ "left join CostCenter c on c.code = b.costCenter "
			+ "left join Asset a on a.assetCode = b.assetCode "
			+ "left join AssetAccount ac on ac.accountNumber = b.accountNumber where "
			+ " ((:assetQuery is null or lower(a.assetCode) like lower(concat('%', cast(:assetQuery as string),  '%' ))) or "
			+ "  (:assetQuery is null or lower(a.name) like lower(concat('%', cast(:assetQuery as string),  '%' ))))"
			+ "and ((:vendorQuery is null or lower(v.vendorId) like lower(concat('%', cast(:vendorQuery as string),  '%' ))) or "
			+ " (:vendorQuery is null or lower(v.name) like lower(concat('%', cast(:vendorQuery as string),  '%' ))) )"
			+ "and (:accountNumber is null or lower(b.accountNumber) like lower(concat('%', cast(:accountNumber as string),  '%' )))"
			+ "and (:jobId is null or lower(b.jobId) like lower(concat('%', cast(:jobId as string),  '%' )))"
			+ "and (:invoiceNumber is null or lower(b.invoiceNumber) like lower(concat('%', cast(:invoiceNumber as string),  '%' )))"
			+ "and (:txId is null or lower(b.txId) like lower(concat('%', cast(:txId as string),  '%' )))"
			+   " and (:channel is null or ac.channel=:channel)"
			+ " and b.portalVisible is true "
			+ " and ((cast(:billfromDate as timestamp) is null and cast(:billtoDate as timestamp) is null) or (b.billMonth >= :billfromDate and b.billMonth < :billtoDate)) "
			+ " and ((cast(:invoicefromDate as timestamp) is null and cast(:invoicetoDate as timestamp) is null) or (b.invoiceDate >= :invoicefromDate and b.invoiceDate < :invoicetoDate)) "
			+ "and (:status is null or lower(b.status) like lower(concat('%', cast(:status as string), '%' )))"
			+ "and (:notrequirestatus is null or lower(b.status) not like lower(concat('%', cast(:notrequirestatus as string), '%' )))"
			+" and (:yearOfBillMonth is 0 or EXTRACT(YEAR FROM b.billMonth) = :yearOfBillMonth)and (:monthOfBillMonth is 0 or EXTRACT(MONTH FROM b.billMonth) =:monthOfBillMonth)")
	Page<BillDataRequest> fetchDeatils(String notrequirestatus,String assetQuery, String vendorQuery, String accountNumber, String jobId,ZonedDateTime invoicefromDate,
			ZonedDateTime invoicetoDate,String txId,String invoiceNumber,ZonedDateTime billfromDate,ZonedDateTime billtoDate,String channel, Pageable page,String status,int monthOfBillMonth,int yearOfBillMonth);
	
	Optional<BillDocument> findFirstByTxId(String txId);
	
	@Query("select b from BillDocument b where " + " b.vendorId =:vendorId and "
			+ "  b.portalVisible is true "
			+ " and (:invoiceNumber is null or lower(b.invoiceNumber) like lower(concat('%', cast(:invoiceNumber as string),  '%' )))"
			+ " and ((cast(:fromDate as timestamp) is null and cast(:toDate as timestamp) is null) or (b.invoiceDate >= :fromDate and b.invoiceDate < :toDate)) "
			+ " and (:assetCode is null or lower(b.assetCode) like lower(concat('%', cast(:assetCode as string),  '%' ))) "
			+ "and (:accountNumber is null or lower(b.accountNumber) like lower(concat('%', cast(:accountNumber as string),  '%' )))"
			+ "and (:status is null or lower(b.status) like lower(concat('%', cast(:status as string), '%' )))"
			+" and (:yearOfBillMonth is 0 or EXTRACT(YEAR FROM b.billMonth) = :yearOfBillMonth)and (:monthOfBillMonth is 0 or EXTRACT(MONTH FROM b.billMonth) =:monthOfBillMonth)")
	Page<BillDocument> searchBillDeatils(String assetCode, String accountNumber,String status,String invoiceNumber, String vendorId, ZonedDateTime fromDate,
			ZonedDateTime toDate,int monthOfBillMonth,int yearOfBillMonth, Pageable page);

	@Query("select b from BillDocument b where " + " b.vendorId =:vendorId " + "and b.assetCode =:assetCode "
			+ " and b.accountNumber =:accountNumber"
			+ " and b.portalVisible is true "
			+ "  and ( b.uploadedDate >:toDate and b.uploadedDate <=:fromDate )")
	List<BillDocument> searchBills(String assetCode, String accountNumber, String vendorId, ZonedDateTime fromDate,
			ZonedDateTime toDate);

	boolean existsByAssetCodeAndAccountNumberAndVendorId(String assetCode, String accountNumber, String vendorId);

	List<BillDocument> findByAssetCodeAndStatus(String assetCode, String status);

	List<BillDocument> findByVendorIdAndStatus(String vendorId, String status);

	@Query("select b from BillDocument b where " 
			+ " b.portalVisible is true and "
	        + " b.vendorId =:vendorId " + "and b.assetCode =:assetCode "
			+ " and b.status =:status" + "  and ( b.uploadedDate >:toDate and b.uploadedDate <=:fromDate )")
	List<BillDocument> findByAssetCodeAndVendorIdAndStatus(String assetCode, String vendorId, String status,
			ZonedDateTime fromDate, ZonedDateTime toDate);

	@Query(value = "select * from bill_document b where " + " b.vendor_id =:vendorId "
			+ "  and b.status != 'NEW' " + " and b.asset_code =:assetCode "
			+ " and b.account_number =:accountNumber order by uploaded_date DESC limit 1 ", nativeQuery = true)
	BillDocument findByAccountNumberAndAssetCodeAndVendorId(String accountNumber, String assetCode, String vendorId);
	
	@Query("select count(b)>0 from BillDocument b where " + " b.vendorId =:vendorId " + "and b.assetCode =:assetCode and b.portalVisible is true" 
			+ " and b.accountNumber =:accountNumber and ( b.billMonth >:toDate and b.billMonth <=:fromDate) and b.status is not 'CANCELED' ")
	boolean isBillsPresent(String assetCode, String accountNumber, String vendorId,ZonedDateTime fromDate,
			ZonedDateTime toDate);   
	
	@Query(value = "select a.asset_code as Assetcode,a.name as Assetname,v.vendor_id as VendorId,v.name as VendorName,vcl.classifications,ac.account_number as AccountNumber,ac.channel as Channel,"
			+ " c.code as CostCenter,c.description as CostCenterDesc,g.code as GlAccount,g.description as GlAccountDesc,"
			+ " b.docid,b.status,b.amount,b.portal_doc_id as PortalDocId,b.invoice_number as InvoiceNumber,"
			+ " b.bill_month as BillMonth,b.invoice_date as InvoiceDate,b.invoice_created_date as InvoiceCreatedDate, "
			+ " b.portal_visible as PortalVisible,b.tx_id as TxId ,b.uploaded_by as UploadedBy,b.uploaded_date as UploadedDate,b.s1sync as S1Sync,b.id"
			+ " from bill_document b "
			+ " left join asset a on a.asset_code = b.asset_code "
			+ " left join asset_account ac on ac.account_number = b.account_number "
			+ " left join vendor v on v.vendor_id = b.vendor_id "
			+ " left JOIN vendor_classifications vcl on v.id = vcl.vendor_id "
			+ " left join cost_center c on c.code = b.cost_center "
			+ " left join glaccount g on g.code = b.gl_account "
			+ " where "
			+ " (:assetQuery is null or (a.asset_code =cast(:assetQuery as TEXT)"
			+ " or a.name=cast(:assetQuery as TEXT)))"
			+ "	and (:accountNumber is null or cast(:accountNumber as TEXT) =ac.account_number) "
			+ "	and	(:vendorQuery is null or (v.vendor_id =cast(:vendorQuery as TEXT)"
			+ " or v.name=cast(:vendorQuery as TEXT)))"
			+ " and (:utilityType is null or cast(:utilityType as TEXT) = vcl.classifications )"
			+ " and (:channel is null or cast(:channel as TEXT) = ac.channel )"
			+ " AND (COALESCE(:statuses,NULL) IS NULL or b.status IN (:statuses)) "
			+ " and (:invoiceNumber is null or b.invoice_number like concat('%' ,cast(:invoiceNumber as TEXT), '%'))"
			+ " and ( cast(cast(:invoicefromDate as TEXT) as timestamp) is null and cast(cast(:invoicetoDate as TEXT) as timestamp) is null or "
			+ " b.invoice_date >= cast(cast(:invoicefromDate as TEXT) as timestamp) and b.invoice_date < cast(cast(:invoicetoDate as TEXT) as timestamp) )"
			+ " and (:yearOfBillMonth = 0 or EXTRACT(YEAR FROM b.bill_month) = :yearOfBillMonth)and (:monthOfBillMonth = 0 or EXTRACT(MONTH FROM b.bill_month) =:monthOfBillMonth)"
			+ " order by true",nativeQuery = true)
	Page<BillHistoryInf> fetchDeatilsByNativeQuery(String utilityType,List<String> statuses,String assetQuery,String vendorQuery,String accountNumber,String invoiceNumber,String channel,ZonedDateTime invoicefromDate,
			ZonedDateTime invoicetoDate,int monthOfBillMonth,int yearOfBillMonth, Pageable pageable);
	
	
	@Query(value = "select a.asset_code as Assetcode,a.name as Assetname,v.vendor_id as VendorId,v.name as VendorName,vcl.classifications,ac.account_number as AccountNumber,ac.channel as Channel,"
			+ " c.code as CostCenter,c.description as CostCenterDesc,g.code as GlAccount,g.description as GlAccountDesc,"
			+ " b.docid,b.status,b.amount,b.portal_doc_id as PortalDocId,b.invoice_number as InvoiceNumber,"
			+ " b.bill_month as BillMonth,b.invoice_date as InvoiceDate,b.invoice_created_date as InvoiceCreatedDate from bill_document b "
			+ " left join asset a on a.asset_code = b.asset_code "
			+ " left join asset_account ac on ac.account_number = b.account_number "
			+ " left join vendor v on v.vendor_id = b.vendor_id "
			+ " left JOIN vendor_classifications vcl on v.id = vcl.vendor_id "
			+ " left join cost_center c on c.code = b.cost_center "
			+ " left join glaccount g on g.code = b.gl_account "
			+ " where "
			+ " (:assetQuery is null or (a.asset_code =cast(:assetQuery as TEXT)"
			+ " or a.name=cast(:assetQuery as TEXT)))"
			+ "	and (:accountNumber is null or cast(:accountNumber as TEXT) =ac.account_number) "
			+ "	and	(:vendorQuery is null or (v.vendor_id =cast(:vendorQuery as TEXT)"
			+ " or v.name=cast(:vendorQuery as TEXT)))"
			+ " and (:utilityType is null or cast(:utilityType as TEXT) = vcl.classifications )"
			+ "  and  b.portal_visible is true "
			+ " and (:channel is null or cast(:channel as TEXT) = ac.channel )"
			+ " AND (COALESCE(:statuses,NULL) IS NULL or b.status IN (:statuses)) "
			+ " and (:invoiceNumber is null or b.invoice_number like concat('%' ,cast(:invoiceNumber as TEXT), '%'))"
			+ " and ( cast(cast(:invoicefromDate as TEXT) as timestamp) is null and cast(cast(:invoicetoDate as TEXT) as timestamp) is null or "
			+ " b.invoice_date >= cast(cast(:invoicefromDate as TEXT) as timestamp) and b.invoice_date < cast(cast(:invoicetoDate as TEXT) as timestamp) )"
			+ " and (:yearOfBillMonth = 0 or EXTRACT(YEAR FROM b.bill_month) = :yearOfBillMonth)and (:monthOfBillMonth = 0 or EXTRACT(MONTH FROM b.bill_month) =:monthOfBillMonth)"
			+ " order by true",nativeQuery = true)
	List<BillHistoryInf> fetchDeatilsByNativeQuery(String utilityType,List<String> statuses,String assetQuery,String vendorQuery,String accountNumber,String invoiceNumber,String channel,ZonedDateTime invoicefromDate,
			ZonedDateTime invoicetoDate,int monthOfBillMonth,int yearOfBillMonth);
	
	@Query(value = "SELECT classifications,SUM(SUM) FROM ( SELECT SUM(amount),vcl.classifications FROM bill_document b "
			+ "INNER JOIN vendor v on b.vendor_id = v.vendor_id\r\n"
			+ "INNER JOIN vendor_classifications vcl ON vcl.vendor_id = v.id\r\n"
			+ " where  status = :status AND EXTRACT(YEAR FROM bill_month) = :yearOfBillMonth and EXTRACT(MONTH FROM bill_month) = :monthOfBillMonth \r\n"
			+ " and (:assetCode is null or lower(b.asset_code) like lower(concat('%', cast(:assetCode as Text),  '%' ))) "
			+ " and b.portal_visible is true "
			+ " GROUP BY amount,vcl.classifications ) AS custom GROUP BY classifications" ,nativeQuery = true)
	List<Map<String,Double>> getOneMonthBills(String assetCode,String status,int monthOfBillMonth,int yearOfBillMonth);
	
	@Query(value = "SELECT SUM(custom.sum) FROM (SELECT SUM(amount) FROM bill_document "
			+ " where  status =:status AND EXTRACT(YEAR FROM bill_month) = :yearOfBillMonth and EXTRACT(MONTH FROM bill_month) = :monthOfBillMonth"
			+ " and  b.portal_visible is true"
			+ " and (:assetCode is null or lower(asset_code) like lower(concat('%', cast(:assetCode as Text),  '%' ))) "
			+ " GROUP BY amount ) AS custom",nativeQuery = true)
	Double  getOneMonthBillsTotalAmount(String assetCode,String status,int monthOfBillMonth,int yearOfBillMonth);
	
	@Query(value = "SELECT custom.classifications,TO_CHAR AS month,sum(custom.amount) AS totalAmount FROM (SELECT to_char(bill_month, 'YYYY-MM'),SUM(b.amount) AS amount,classifications FROM  bill_document b "
			+ "inner JOIN vendor v ON v.vendor_id = b.vendor_id "
			+ "inner JOIN vendor_classifications vcl on  v.id = vcl.vendor_id "
			+ "WHERE "
			+ "b.bill_month > date_trunc('month', CURRENT_DATE) - INTERVAL '1 year' "
			+ " AND b.bill_month < CURRENT_TIMESTAMP and  b.portal_visible is true"
			+ "and (:status is null or lower(b.status) like lower(concat('%', cast(:status as text), '%' )))"
//			+ "AND (COALESCE(:types,NULL) IS NULL or vcl.classifications IN (:types)) "
			+ "GROUP BY b.bill_month,to_char(b.bill_month, 'MONYYYY'),b.amount,classifications HAVING b.amount != 0 ) AS custom "
			+ "GROUP BY TO_CHAR,custom.classifications ORDER BY TO_CHAR ASC",nativeQuery = true)
	List<OneYearBillInf>  findByNativeQueryOneYearBill(String status);
	
	@Query(value = "select b from BillDocument b where " 
			+ "(:assetCode is null or lower(b.assetCode) like lower(concat('%', cast(:assetCode as string),  '%' ))) "
			+ "  and b.portalVisible is true "
			+ "and (:vendorId is null or lower(b.vendorId) like lower(concat('%', cast(:vendorId as string),  '%' )))"
			+ "and (:accountNumber is null or lower(b.accountNumber) like lower(concat('%', cast(:accountNumber as string),  '%' )))")
	Page<BillDocument> searchBills(String accountNumber, String assetCode, String vendorId,Pageable pageable);
	
	@Query(value = "select b.* from bill_document b where"
			+ "  (:assetCode is null or cast(:assetCode as TEXT) =b.asset_code) "
			+ "  and b.portal_visible is true  and b.status != 'CANCELED' "
			+ " and (:accountNo is null or cast(:accountNo as TEXT) =b.account_number) "
			+ " and (:vendorId is null or cast(:vendorId as TEXT) =b.vendor_id) order by b.uploaded_date DESC limit 1 ",nativeQuery = true)
	Optional<BillDocument> searchBills(String accountNo, String assetCode, String vendorId);
	
	@Query(value="select count(DISTINCT(b.id)) FROM bill_document b INNER JOIN vendor v ON v.vendor_id=b.vendor_id WHERE v.manual_intervention IS true",nativeQuery = true)
	long countBillsHaveManualIntervention();
	
	@Query(value="select count(DISTINCT(b.id)) FROM bill_document b INNER JOIN asset_account ac ON ac.account_number=b.account_number WHERE ac.channel = 'AutoPilot-Bot'",nativeQuery = true)
	long countBillsByBots();
}
