package com.smartdocs.repository;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.RobotLog;
import com.smartdocs.model.group.RobotLogData;

@Repository
public interface RobotLogRepository extends JpaRepository<RobotLog,String>  {
		
	@Query("select new com.smartdocs.model.group.RobotLogData(r,a.name,v.name) from RobotLog r"
			+ " inner join Asset a on a.assetCode =r.assetCode "
			+ " inner join Vendor v on v.vendorId =r.vendorId "
			+ " where (:botName is null or lower(r.botName) like lower(concat('%', cast(:botName as string), '%' )))"
			+ " and (:assetCode is null or r.assetCode =:assetCode) "
			+ " and (:stage is null or r.stage =:stage ) "
			+ " and (:vendorId is null or r.vendorId =:vendorId) " 
			+ " and (:accountNo is null or lower(r.accountNo) like lower(concat('%', cast(:accountNo as string), '%' )))"
			+ " and (r.status is  'OPEN' ) "
			+ " and (:buildStatus is null or r.buildStatus =:buildStatus) "
			+ "")
	List<RobotLogData> findRobotLogData(Integer stage,String botName,String assetCode,String vendorId,String accountNo,String buildStatus);
	
	@Query("select new com.smartdocs.model.group.RobotLogData(r,a.name,v.name) from RobotLog r"
			+ " inner join Asset a on a.assetCode =r.assetCode "
			+ " inner join Vendor v on v.vendorId =r.vendorId "
			+ " where (:botName is null or lower(r.botName) like lower(concat('%', cast(:botName as string), '%' )))"
			+ " and (:assetCode is null or r.assetCode =:assetCode) "
			+ " and (:stage is null or r.stage =:stage ) "
			+ " and (:vendorId is null or r.vendorId =:vendorId) " 
			+ " and (:accountNo is null or lower(r.accountNo) like lower(concat('%', cast(:accountNo as string), '%' )))"
			+ " and (r.status is  'OPEN' ) "
			+ " and (:buildStatus is null or r.buildStatus =:buildStatus) "
			+ "")
	Page<RobotLogData> findRobotLogData(Integer stage,String botName,String assetCode,String vendorId,String accountNo,String buildStatus,Pageable pageable);

	@Query("select new com.smartdocs.model.group.RobotLogData(r,a.name,v.name) from RobotLog r"
			+ " inner join Asset a on a.assetCode =r.assetCode "
			+ " inner join Vendor v on v.vendorId =r.vendorId "
			+ " where (:botName is null or lower(r.botName) like lower(concat('%', cast(:botName as string), '%' )))"
			+ " and (:assetCode is null or r.assetCode =:assetCode) "
			+ " and (:stage is null or r.stage =:stage ) "
			+ " and (:vendorId is null or r.vendorId =:vendorId) " 
			+ " and (:accountNo is null or lower(r.accountNo) like lower(concat('%', cast(:accountNo as string), '%' )))"
			+ " and (:buildStatus is null or r.buildStatus =:buildStatus) "
			+ " and ((cast(:bdExTimeFrom as timestamp) is null and cast(:bdExTimeFrom as timestamp) is null) or (r.buildExTime >= :bdExTimeFrom and  r.buildExTime < :bldExTimeTo)) "
			+ " and (:status is null or r.status =:status)")
	Page<RobotLogData> findReport(Integer stage,String botName,String assetCode,String vendorId,String accountNo,String buildStatus,String status,ZonedDateTime bdExTimeFrom ,ZonedDateTime bldExTimeTo ,Pageable pageable);
    
	long countByBuildStatus(String status);


}
