package com.smartdocs.repository;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.smartdocs.model.Robot;
import com.smartdocs.model.group.RobotData;
import com.smartdocs.sql.dto.RobotInf;

public interface RobotRepository extends JpaRepository<Robot, String> {

	@Query("select new com.smartdocs.model.group.RobotData(r, a, ac, v) from Robot r "
			+ "inner join AssetAccount ac on ac.accountNumber = r.accountNo "
			+ "inner join Vendor v on v.vendorId = r.vendorId " + " inner join Asset a on a.assetCode = r.assetCode "
			+ " where (:accountNo is null or lower(ac.accountNumber) like lower(concat('%', cast(:accountNo as string),  '%' ))) "
			+ " and lower(ac.channel) like lower(concat('%', cast(:channel as string), '%' )) "
			+ " and  (:status is null or lower(r.status) like lower(concat('%', cast(:status as string),  '%' )))"
			+ " and (:id is null or lower(r.id) like lower(concat('%', cast(:id as string),  '%' )))"
			+ " and ( (:assetQuery is null or lower(a.name) like lower(concat('%', cast(:assetQuery as string),  '%' ))) or "
			+ " (:assetQuery is null or lower(a.assetCode) like lower(concat('%', cast(:assetQuery as string),  '%' ))) )"
			+ " and ((:query is null or lower(v.name) like lower(concat('%', cast(:query as string),  '%' )))"
			+ " or (:query is null or lower(v.vendorId) like lower(concat('%', cast(:query as string),  '%' )))) group by r.id,a.id,ac.assetAccountId,v.id")
	Page<RobotData> getPage(String assetQuery, String status, String query, String accountNo, String id, String channel,
			Pageable pageable);

	@Query("select r from Robot r where "
			+ "(:assetCode is null or lower(r.assetCode) like lower(concat('%', cast(:assetCode as string),  '%' ))) "
			+ "and (:status is null or lower(r.status) like lower(concat('%', cast(:status as string),  '%' )))")
	List<Robot> findRobots(String assetCode, String status);

	List<Robot> findByVendorId(String vendorId);

	Optional<Robot> findByJobId(String jobId);

	Optional<Robot> findByIdAndSchedule(String id, boolean schedule);

	@Query(value = "SELECT * FROM Robot r WHERE r.vendor_id in (:myList)", nativeQuery = true)
	List<Robot> findAllByVendorId(@Param("myList") List<String> vendorIds);

	@Query(value = "select * from Robot r where "
			+ " ( r.next_execution > cast(now() - interval '5 MINUTES ' as timestamp) and "
			+ " r.next_execution < cast(now() + interval '5 MINUTES' as timestamp) )"
			+ " and (:assetCode is null or cast(:assetCode as TEXT) =r.asset_code) "
			+ " and (:accountNo is null or cast(:accountNo as TEXT) =r.account_no) "
			+ " and (:vendorId is null or cast(:vendorId as TEXT) =r.vendor_id) ", nativeQuery = true)
	Page<Robot> findRobotsByTimeInterval(@Param("assetCode") String assetCode, @Param("vendorId") String vendorId,
			@Param("accountNo") String accountNo, Pageable pageable);

	@Query(value = "select count(*) from Robot r where "
			+ " ( r.next_execution > cast(now() - interval '5 MINUTES ' as timestamp) and "
			+ " r.next_execution < cast(now() + interval '5 MINUTES' as timestamp) )", nativeQuery = true)
	long countRobotsByTimeInterval();

	@Query(value = "select j from Robot j where " + " j.nextExecution > now() and"
			+ "(:vendorId is null or j.vendorId = :vendorId) and "
			+ " (:accountNo is null or lower(j.accountNo) like lower(concat('%', cast(:accountNo as string),  '%' ))) and "
			+ " (:assetCode is null or j.assetCode = :assetCode) ")
	Page<Robot> findUpComingRobots(@Param("assetCode") String assetCode, @Param("vendorId") String vendorId,
			@Param("accountNo") String accountNo, Pageable pageable);

	@Query(value = "select count(*) from Robot r where " + " r.next_execution > now()", nativeQuery = true)
	long countUpComingRobots();

	@Query(value = "select * from Robot r where " + " r.last_executed < now()"
			+ " and (:assetCode is null or cast(:assetCode as TEXT) =r.asset_code) "
			+ " and (:accountNo is null or cast(:accountNo as TEXT) =r.account_no) "
			+ " and (:vendorId is null or cast(:vendorId as TEXT) =r.vendor_id) ", nativeQuery = true)
	Page<Robot> findfinishedBotRobots(@Param("assetCode") String assetCode, @Param("vendorId") String vendorId,
			@Param("accountNo") String accountNo, Pageable pageable);

	@Query(value = "select count(*) from Robot r where " + " r.last_executed < now()", nativeQuery = true)
	long countfinishedBotRobots();

	@Query(value = "select * from Robot ac where ac.asset_code =:assetCode and ac.account_no=:accountNumber and ac.vendor_id =:vendorId limit 1", nativeQuery = true)
	Robot findOneByAssetCodeAndAccountNumberAndVendorId(String assetCode, String accountNumber, String vendorId);

	@Query(value = "Select r.nextExecution from Robot r where r.id=:id")
	List<ZonedDateTime> findAllNextExecutionById(String id);

	@Query(value = "Select r from Robot r where r.vendorId=:vendorId and r.status =:status")
	List<Robot> getByVendorId(String vendorId, String status);

	long countBySchedule(boolean schedule);

	List<Robot> findByStatusAndSchedule(String status, boolean scheduled);

	List<Robot> findByStatusNot(String status);

	@Query(value = "SELECT r.id,r.account_no AS AccountNo,r.vendor_id AS VendorId,r.asset_code AS AssetCode,r.last_updated  AS LastUpdated,r.status,r.last_executed AS LastExecuted,r.schedule,r.job_id AS JobId,r.jenkins_command AS JenkinsCommand,r.frequency,v.name AS VendorName,a.name AS AssetName from Robot r \r\n"
			+ "			left join Vendor v on v.vendor_id = r.vendor_id \r\n"
			+ "			left join Asset a on a.asset_code = r.asset_code "
			+ "         where (:frequency is null or cast(:frequency as TEXT) =r.frequency)"
			+ "          and (:assetCode is null or cast(:status as TEXT) =r.status)"
			+ " 	     and (:assetCode is null or cast(:assetCode as TEXT) =r.asset_code) "
			+ "			 and (:accountNo is null or cast(:accountNo as TEXT) =r.account_no) "
			+ "			 and (:vendorId is null or cast(:vendorId as TEXT) =r.vendor_id) GROUP BY r.id,v.name,a.name order by true ", nativeQuery = true)
	Page<RobotInf> findRobotsByPage(@Param("assetCode") String assetCode, @Param("status") String status,
			@Param("frequency") String frequency, @Param("vendorId") String vendorId,
			@Param("accountNo") String accountNo, Pageable pageable);

	@Modifying
	@Transactional
	@Query(value = "UPDATE robot SET status ='PAUSED' ,schedule =FALSE , jenkins_command = Null", nativeQuery = true)
	void unPublishAllRobots();

	@Query(value = "SELECT COUNT(*) FROM robot WHERE jenkins_command LIKE (concat('%', cast(:pattern as text),'%' ))", nativeQuery = true)
	long countRobotsByPattern(String pattern);

	@Query(value = "SELECT COUNT(*) FROM robot WHERE jenkins_command LIKE (concat('%', cast(:pattern as text),'%' )) and  executed_status =:status  AND EXTRACT(DAY FROM CURRENT_TIMESTAMP) =  EXTRACT(DAY FROM last_executed)  ", nativeQuery = true)
	long countRobotsByPatternAndStatus(String pattern, String status);

	@Query(value = "SELECT COUNT(*) FROM robot WHERE jenkins_command LIKE (concat('%', cast(:pattern as text),'%' )) AND ((CURRENT_DATE) > last_executed OR last_executed IS NULL)   ", nativeQuery = true)
	long countUpComingRobotsByPattern(String pattern);

	@Query(value = "SELECT UNNEST(fn_total_success_robot_in_month())", nativeQuery = true)
	String[] totalSuccessRobotInMonth();

	@Query(value = "SELECT UNNEST(fn_total_failure_robot_in_month())", nativeQuery = true)
	String[] totalFailRobotInMonth();

	@Query(value = "SELECT UNNEST(fn_total_failure_robot_in_day())", nativeQuery = true)
	String[] totalFailRobotInDay();

	@Query(value = "  SELECT UNNEST(fn_total_succes_robot_in_day())", nativeQuery = true)
	String[] totalSuccessRobotInDay();

	Robot findFirstByAssetCodeAndAccountNoAndVendorId(String assetCode, String accountno, String vendorId);

}
