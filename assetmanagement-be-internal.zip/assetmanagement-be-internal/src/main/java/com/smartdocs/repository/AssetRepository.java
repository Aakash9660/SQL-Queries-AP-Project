package com.smartdocs.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.Asset;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.group.AssetData;
import com.smartdocs.model.group.AssetRequireData;
import com.smartdocs.sql.dto.AssetCustomInf;
import com.smartdocs.sql.dto.AssetDataInf;

@Repository
public interface AssetRepository extends JpaRepository<Asset, Long> {

	Optional<Asset> findOneByAssetCode(String assetCode);

	long countAccountsById(Long id);

	@Query("select new com.smartdocs.model.group.AssetData(a, v, g, c) from AssetAccount a "
			+ "left join Vendor v on v.vendorId = a.vendorId " + "left join GLAccount g on g.code = a.glAccount "
			+ "left join CostCenter c on c.code = a.costCenter " + "left join v.classifications as classification "
			+ "where (:frequency is null or a.frequency =:frequency)  "
			+ "and (:channel is null or a.channel =:channel) "
			+ "and (:vendorId is null or lower(a.vendorId) like lower(concat('%', cast(:vendorId as string), '%' ))) "
			+ "and (:accountNumber is null or lower(a.accountNumber) like lower(concat('%', cast(:accountNumber as string), '%' ))) "
			+ "and (:utilityType is null or classification = :utilityType)"
			+ "and (:assetCode is null or a.assetCode = :assetCode)")
	Page<AssetData> fetchAssetAccountDetails(String assetCode, String frequency, String channel, String vendorId,
			String accountNumber, String utilityType, Pageable page);

	@Query("select v from Vendor v where v.vendorId in "
			+ "(select ac.vendorId from AssetAccount ac where ac.assetCode in "
			+ "(select a.assetCode from Asset a where a.assetCode = :assetCode )) ")
	List<Vendor> findVendorsByAssetCode(String assetCode);

	@Query(value = "select distinct(a.asset_type) from asset a WHERE a.asset_type IS NOT null order by a.asset_type", nativeQuery = true)
	Set<String> getDistinctAssetTypes();

	@Query(value = "SELECT * FROM Asset a WHERE a.asset_code in (:myList)", nativeQuery = true)
	List<Asset> findByAssetCodes(@Param("myList") List<String> assetCodes);

	@Query("select a from Asset a where "
			+ "(:query is null or lower(a.assetCode) like lower(concat('%', cast(:query as string), '%' ))) "
			+ "or  (:query is null or lower(a.name) like lower(concat('%', cast(:query as string), '%' ))) ")
	Page<Asset> findAssetByAssetCodeOrAssetName(String query, Pageable pageable);

	@Query(value = "Select * from Asset a where a.asset_code=:assetCode limit 1", nativeQuery = true)
	Asset getNameByAssetCode(String assetCode);

	@Query(value = "select a.asset_type, count(a.asset_type) from Asset a where a.asset_type is not null group by a.asset_type order by asset_type ASC ", nativeQuery = true)
	List<Map<String, Integer>> getAssetTypeCount();

	@Query("select new com.smartdocs.model.group.AssetRequireData(a.id,a.assetCode,a.name,a.assetType,a.address,a.latitude,a.longitude) "
			+ "FROM Asset a " + "WHERE a.assetCode =:assetCode")
	AssetRequireData findAssetRequireDataByAssetCode(String assetCode);
	
    @Query(value = "SELECT a.asset_code,a.name FROM asset a "
    		+ " where (a.asset_code like concat('%' ,cast(:assetQuery as TEXT), '%')"
    		+ "	or  "
			+ " a.name like concat('%' ,cast(:assetQuery as TEXT), '%'))"
    		+ " GROUP by a.asset_code,a.name ",nativeQuery = true)
	List<Map<String, Integer>> findAssetNameByAssetCodeOrName(String assetQuery);
   
	@Query(value = "SELECT ac.asset_account_id as AssetAccountId,ac.account_number as AccountNumber,ac.secondary_account_number as SecondaryAccountNumber,ac.vault_id as VaultId,ac.frequency,ac.channel,ac.send_to_external as SendToExternal,ac.start_date as StartDate,"
			+ "c.code AS costCode,c.description AS CostDescription,"
			+ "g.code AS glCode,g.description AS glDescription,"
			+ "v.name AS vendorName,v.vendor_id AS vendorId,vcl.classifications,"
			+ "ad.address1,ad.address2,ad.city,ad.state,ad.country,ad.zip,ad.location " + "FROM asset_account ac "
			+ "LEFT JOIN vendor v ON v.vendor_id = ac.vendor_id "
			+ "LEFT JOIN vendor_classifications vcl ON  v.id = vcl.vendor_id "
			+ "LEFT JOIN address ad ON  ad.id = v.address_id " + "LEFT JOIN glaccount g ON g.code = ac.gl_account "
			+ "LEFT JOIN cost_center c ON c.code = ac.cost_center " + "WHERE "
			+ "ac.asset_code =:assetCode", nativeQuery = true)
	List<AssetCustomInf> findAssetAccountDeatils(String assetCode);
	

	@Query(value = "SELECT a.id,a.asset_code as AssetCode,a.name ,a.asset_type as AssetType,a.latitude,a.longitude,ad.address1,ad.address2,ad.city,ad.state,ad.country,ad.zip,ad.location,COUNT(distinct(v.vendor_id)) as count FROM asset a LEFT JOIN asset_account ac ON ac.asset_code = a.asset_code "
			+ " LEFT JOIN vendor v on v.vendor_id =ac.vendor_id " + "LEFT JOIN address ad on ad.id =a.address_id "
			+ " where "
			+ " (:assetQuery is null or (a.asset_code =cast(:assetQuery as TEXT)"
			+ " or a.name=cast(:assetQuery as TEXT)))"
			+ "	and	(:vendorQuery is null or (v.vendor_id =cast(:vendorQuery as TEXT)"
			+ " or v.name=cast(:vendorQuery as TEXT)))"
			+ " and (:assetType is null or a.asset_type = cast(:assetType as TEXT))"
			+ " GROUP BY a.id,ad.id ORDER BY true", nativeQuery = true)
	Page<AssetDataInf> findAssetsByNativeQuery(String vendorQuery, String assetType, String assetQuery, Pageable page);

}