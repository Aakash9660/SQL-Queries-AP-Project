package com.smartdocs.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.AssetType;

@Repository
public interface AssetTypeRepository extends JpaRepository<AssetType, String>{
	

	@Query(value = "select * from Asset_Type  where name = ?  limit 1", nativeQuery = true)
	Optional<AssetType> findOneByNameIgnoreCase(@Param("name") String name);
	
	void deleteByNameIgnoreCase(String name);
	
	@Query("select a from AssetType a where "
			+ "(:query is null or lower(a.name) like lower(concat('%', cast(:query as string),  '%' ))) " 
			+ "or (:query is null or lower(a.description) like lower(concat('%', cast(:query as string),  '%' )))" )
	Page<AssetType> getPage(String query, Pageable page);

}
