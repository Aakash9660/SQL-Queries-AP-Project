package com.smartdocs.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;

import com.smartdocs.model.Manager;

public interface ManagerRepository extends JpaRepository<Manager, Long> {

	@Query("select v from Manager v "
			+ "where (:email is null or lower(v.email) like lower(concat('%', cast(:email as string),  '%' ))) "
			+ "and (:name is null or lower(v.name) like lower(concat('%', cast(:name as string),  '%' ))) ")
	Page<Manager> findManagers(String name, String email, Pageable page);

	@Query(value = "select * from Manager m where m.email =:email limit 1", nativeQuery = true)
	Optional<Manager> findOneByEmailIgnoreCase(String email);

	@Query(value = "select m.* from manager AS m inner join asset_managers_ids a on m.id = a.managers_ids where a.asset_id =:id", nativeQuery = true)
	List<Manager> findManagersByAssetId(long id);

	@Query(value = "select * from manager AS m left join asset_managers_ids a on m.id = a.managers_ids "
			+ " inner join asset ast on ast.id=a.asset_id where ast.asset_code= :assetCode limit 1", nativeQuery = true)
	List<Manager> findManagersByAssetCode(String assetCode);
	
	@Modifying
	@Procedure
	String fn_set_asset_manager(int managerId,boolean action);

}
