package com.smartdocs.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.VendorClassifications;

@Repository
public interface VendorClassificationsRepository extends JpaRepository<VendorClassifications, String> {

	Optional<VendorClassifications> findByNameIgnoreCase(String name);

	void deleteByNameIgnoreCase(String name);

	@Query("select a from VendorClassifications a where "
			+ "(:query is null or lower(a.name) like lower(concat('%', cast(:query as string),  '%' ))) "
			+ "or (:query is null or lower(a.description) like lower(concat('%', cast(:query as string),  '%' )))")
	Page<VendorClassifications> getPage(String query, Pageable page);

}
