package com.smartdocs.repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.smartdocs.dto.VendorAssets;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.Vendor;
import com.smartdocs.sql.dto.ManageBillsInf;
import com.smartdocs.sql.dto.VendorInf;

@Repository
public interface VendorRepository extends JpaRepository<Vendor, Long> {
	
	@Query(value = "SELECT v.id,v.vendor_id as VendorId,v.name as VendorName,v.last_updated as LastUpdated ,ad.address1,ad.address2,ad.city,ad.state,ad.country,ad.zip,ad.location,"
			+ " vcl.classifications as Classifications,COUNT(DISTINCT(a.id)) as count,v.manual_intervention as ManualIntervention,v.manual_intervention_added_by as AddedBy  "
			+ "FROM vendor v "
			+ "LEFT JOIN asset_account ac on v.vendor_id =ac.vendor_id "
			+ "LEFT JOIN asset  a ON ac.asset_code = a.asset_code "
			+ "LEFT JOIN vendor_classifications vcl on v.id = vcl.vendor_id "
			+ "LEFT JOIN address ad on ad.id =v.address_id "
			+  "WHERE "
			+ "(:utilityType IS NULL or  vcl.classifications =CAST(:utilityType as TEXT)) "
			+ " and (:manualIntervention is null or cast(v.manual_intervention as TEXT)=cast(:manualIntervention as TEXT)) "
			+ "	and	((:vendorQuery is null or lower(v.vendor_id) like lower(concat('%', cast(:vendorQuery as TEXT),  '%' )))"
			+ " or (:vendorQuery is null or lower(v.name) like lower(concat('%', cast(:vendorQuery as TEXT),  '%' ))))"
			+ " GROUP BY v.id,ad.id,vcl.classifications ORDER BY true",nativeQuery = true)
	Page<VendorInf> findAllVendors(Boolean manualIntervention,String vendorQuery, String utilityType, Pageable page);

	
	@Query("select count(v.utilityVendor) from Vendor v " + "where (v.utilityVendor = :utilityVendor )")
	long countVendors(Boolean utilityVendor);

	@Query(value = "select distinct c.classifications from vendor_classifications c order by c.classifications", nativeQuery = true)
	Set<String> getDistinctClassifications();

	@Query(value = "select c.classifications, count(c.classifications) from vendor_classifications c where  vendor_id in "
			+ " (select v.id from vendor v where utility_vendor = true )"
			+ " group by c.classifications order by classifications ASC ", nativeQuery = true)
	List<Map<String, Integer>> getDistinctCountClassifications();

	@Query("select new com.smartdocs.dto.VendorAssets(ac, a, cc, gl) from Vendor v "
			+ "left join v.classifications classification " + "left join AssetAccount ac on ac.vendorId = v.vendorId "
			+ "left join Asset a on ac.assetCode = a.assetCode " + "left join CostCenter cc on ac.costCenter = cc.code "
			+ "left join GLAccount gl on ac.glAccount = gl.code " + "where (v.vendorId = :vendorId) "
			+ "and (v.utilityVendor = :utilityVendor)  "
			+ "and  (:accountNo is null or lower(ac.accountNumber) like lower(concat('%', cast(:accountNo as string),  '%' ))) "
			+ "group by v.id, ac.id, a.id, cc.id, gl.id ")
	Page<VendorAssets> findAllVendorAssets(String vendorId,String accountNo, Boolean utilityVendor, Pageable pageable);

	Vendor findOneById(Long id);

	@Query(value = "select * from vendor  where vendor_id = ?  limit 1", nativeQuery = true)
	Optional<Vendor> findOneByVendorId(@Param("vendor_id") String vendorId);

	@Query("select v from Vendor v  " + "left join v.classifications classification "
			+ "where (:utilityType is null or classification =:utilityType )  "
			+ "and ((:query is null or lower(v.vendorId)  like lower(concat('%', cast(:query as string),  '%' ))) "
			+ "or (:query is null or lower(v.name) like lower(concat('%', cast(:query as string),  '%' )))) group by v.id ")
	Page<Vendor> findVendors(String utilityType, String query, Pageable page);

	@Query(value = "select Distinct(v.classifications) from vendor_classifications  v "
			+ " group by v.classifications having v.classifications is not null order by v.classifications", nativeQuery = true)
	Set<String> getVedorClassifications();

	@Query("select ac from AssetAccount ac where ac.vendorId in "
			+ " ( select v.vendorId from Vendor v where v.vendorId = :vendorId)")
	List<AssetAccount> getLinkAccount(String vendorId);
	
	@Query("select count(a) from Asset a where a.assetCode in "
			+ " (select ac.assetCode from AssetAccount ac where ac.vendorId in "
			+ " ( select v.vendorId from Vendor v where v.vendorId = :vendorId ))")
	int getLinkAsset(String vendorId);
	
	@Query(value = "select v from Vendor v "
			+ "where ((:query is null or lower(v.vendorId) like lower(concat('%', cast(:query as string),  '%' )))"
			+ "or (:query is null or lower(v.name) like lower(concat('%', cast(:query as string),  '%' ))) ) ")
	Page<Vendor> findByVendorIdOrName(String query,Pageable pageable);

	Vendor findFirstByVendorId(String vendorId);

	List<Vendor> findByVendorIdLikeOrNameLikeIgnoreCase(String vendorId,String name);
	
	@Query(value="Select a.name from Vendor a where a.vendor_id=:vendorId limit 1",nativeQuery = true)
	String getNameByVendorId(String vendorId);
	
    @Query(value ="SELECT v.url FROM vendor v INNER JOIN asset_account ac ON v.vendor_id=ac.vendor_id WHERE ac.account_number =:accountNo limit 1",nativeQuery = true)
    String getURLByAccountNo(String accountNo);
    

    @Query(value = "SELECT v.vendor_id,v.name FROM vendor v "
    		+ " where (v.vendor_id like concat('%' ,cast(:vendorQuery as TEXT), '%')"
    		+ "	or  "
			+ " (:vendorQuery is null or lower(v.name) like lower(concat('%', cast(:vendorQuery as TEXT),  '%' ))))"
    		+ " GROUP by v.vendor_id,v.name ",nativeQuery = true)
	List<Map<String, Integer>> findVendorNameByVendorIdOrName(String vendorQuery);
    
    @Query("select v from Vendor v  " + "left join v.classifications classification "
			+ "where (:utilityType is null or classification =:utilityType )  "
			+ "and ((:query is null or lower(v.vendorId)  like lower(concat('%', cast(:query as string),  '%' ))) "
			+ "or (:query is null or lower(v.name) like lower(concat('%', cast(:query as string),  '%' )))) group by v.id ")
	Page<Vendor> findVendors1(String utilityType, String query, Pageable page);
    
	@Query(value = "select v.vendor_id as VendorId,v.name as VendorName,a.asset_code as AssetCode,a.name as AssetName,ac.account_number AS AccountNo,ac.frequency,ac.notes  "
			+ " from vendor v "
			+ "	inner join asset_account ac on ac.vendor_id = v.vendor_id"
			+ "	left join asset a on a.asset_code = ac.asset_code "
			+ "	WHERE "
			+ " (:vendorId is null or cast(:vendorId as TEXT) =v.vendor_id) "
			+ " and (:assetCode is null or cast(:assetCode as TEXT) =a.asset_code) "
			+ " and (:frequency is null or cast(:frequency as TEXT) =ac.frequency) "
			+ " and (:accountNo is null or cast(:accountNo as TEXT) =ac.account_number) "
			+ " and v.manual_intervention IS true order by true ",nativeQuery = true)
	Page<ManageBillsInf>  findManageBills(String vendorId,String accountNo,String assetCode,String frequency,Pageable pageable);
	
	@Query(value = "select v.vendor_id as VendorId,v.name as VendorName,a.asset_code as AssetCode,a.name as AssetName,ac.account_number AS AccountNo,ac.frequency  "
			+ " from vendor v "
			+ "	left join asset_account ac on ac.vendor_id = v.vendor_id"
			+ "	left join asset a on a.asset_code = ac.asset_code "
			+ "	WHERE "
			+ " (:vendorId is null or cast(:vendorId as TEXT) =v.vendor_id) "
			+ " and (:assetCode is null or cast(:assetCode as TEXT) =a.asset_code) "
			+ " and (:accountNo is null or cast(:accountNo as TEXT) =ac.account_number) "
			+ " and v.manual_intervention IS true  ",nativeQuery = true)
	List<ManageBillsInf>  findManageBills(String vendorId,String accountNo,String assetCode);
	
	@Modifying
	@Query(value="update vendor set manual_intervention =:manualIntervention,last_updated = CURRENT_TIMESTAMP,manual_intervention_added_by=:addedby WHERE vendor_id in :ids",nativeQuery = true)
	void setManualIntervention(List<String> ids,boolean manualIntervention,String addedby);
	
	@Query(value="SELECT COUNT(DISTINCT(v.vendor_id)) FROM vendor v INNER JOIN robot r ON v.vendor_id =r.vendor_id ",nativeQuery = true)
	long countVendorsHaveBots();
	
	
	long countByManualIntervention(boolean manualIntervention);
	
	@Query(value="SELECT v.* FROM vendor v INNER JOIN asset_account ac ON v.vendor_id=ac.vendor_id  WHERE vault_id=:vaultId GROUP BY v.id",nativeQuery = true)
	List<Vendor>  findVendorsByVaultId(long vaultId);
    
}
