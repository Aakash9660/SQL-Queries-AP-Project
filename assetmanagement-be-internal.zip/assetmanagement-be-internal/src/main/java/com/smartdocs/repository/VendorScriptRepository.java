package com.smartdocs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.VendorScript;

@Repository
public interface VendorScriptRepository extends JpaRepository<VendorScript, Long> {

	VendorScript findByVendorId(String vendorId);

	List<VendorScript> findAllByVendorIdIn(List<String> vendorIds);

	void deleteByVendorId(String vendorId);

	@Query("select count(vs)>0 from VendorScript  vs where vs.version > :version and vs.vendorId =:vendorId ")
	boolean checkVersion(String vendorId, int version);
	
	@Query("select count(vs)>0 from VendorScript vs where vs.vendorId =:vendorId ")
	boolean existVendorId(String vendorId);
}
