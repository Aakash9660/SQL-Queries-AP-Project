package com.smartdocs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smartdocs.model.BillDocumentLog;

public interface BillDocumentLogRepository extends JpaRepository<BillDocumentLog, Long> {

	List<BillDocumentLog> findByBillIdOrderByDateTimeDesc(long id);
}
