package com.smartdocs.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.CostCenter;

@Repository
public interface CostCenterRepository extends JpaRepository<CostCenter, String> {

	@Query("select cc from CostCenter cc where "
			+ "(:query is null or lower(cc.code) like lower(concat('%', cast(:query as string),  '%' ))) "
			+ "or (:query is null or lower(cc.description) like lower(concat('%', cast(:query as string),  '%' )))")
	Page<CostCenter> getCostCenterPage(String query, Pageable page);

	Optional<CostCenter> findOneByCode(String code);

}
