package com.smartdocs.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.smartdocs.model.SystemConfig;

public interface SystemConfigRepository extends JpaRepository<SystemConfig, String> {

	Optional<SystemConfig> findByConfig(String config);
	
	@Query(value =  "select value from system_config where config =:config limit 1",nativeQuery = true)
	String findValueByConfig(String config);
}
