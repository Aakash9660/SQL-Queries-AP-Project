package com.smartdocs.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.EmailChannel;

@Repository
public interface EmailChannelRepository extends JpaRepository<EmailChannel, String>{

	@Query("select ec from EmailChannel ec where "
			+ " (:email is null or lower(ec.email) like lower(concat('%', cast(:email as string), '%' ))) "
			+ "and (:authType is null or lower(ec.authType) like lower(concat('%', cast(:authType as string), '%' ))) " 
			+ "and (:tenantId is null or lower(ec.tenantId) like lower(concat('%', cast(:tenantId as string), '%' ))) " 
			  )
	Page<EmailChannel> getEmailChannelPage(String email,String authType,String tenantId, Pageable page);
	
	
	EmailChannel findOneByEmail(String email);
	
	EmailChannel findOneBySharedEmail(String email);
}
