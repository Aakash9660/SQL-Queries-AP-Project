package com.smartdocs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.smartdocs.model.ManageBillsLog;
import com.smartdocs.sql.dto.ManageBillsLogInf;

public interface ManageBillsLogRepository extends JpaRepository<ManageBillsLog, Long> {

	List<ManageBillsLog>  findByAssetCodeAndAccountNoAndVendorIdOrderByIdDesc(String assetCode,String accountNo,String vendorId);
	 
	@Query(value = " select m.asset_code as AssetCode,m.account_no as AccountNo,m.vendor_id as VendorId,m.user_name as UserName,"
			+ "m.comments,m.doc_id as DocId,m.file_name as FileName,m.file_type as FileType, m.activity_code as ActicityCode, m.activity_desc as ActivityDesc,"
			+ " m.uploaded_date as UploadedDate,b.bill_month as BillMonth"
			+ " from manage_bills_log m "
			+ "	left join  bill_document b on b.docid = m.doc_id and b.bill_month is not null and b.status !='CANCELED'"
			+ "	and b.portal_visible is true  WHERE "
			+ " (:vendorId is null or cast(:vendorId as TEXT) =m.vendor_id) "
			+ " and (:assetCode is null or cast(:assetCode as TEXT) =m.asset_code) "
			+ " and (:accountNo is null or cast(:accountNo as TEXT) =m.account_no) "
			+ " order by m.uploaded_date  desc"
			+ "  ",nativeQuery = true)
	List<ManageBillsLogInf>  findManageBillsLog(String vendorId,String accountNo,String assetCode);
	
	
	
}
