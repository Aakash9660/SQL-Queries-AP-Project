package com.smartdocs.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.smartdocs.model.TimeSlots;
import com.smartdocs.sql.dto.TimeSlotsInf;

@Repository
public interface TimeSlotsRepository extends JpaRepository<TimeSlots, Long> {

	@Query("delete from TimeSlots t")
	@Modifying
	@Transactional
	void deleteAllRecords();
	
	List<TimeSlots> findByAllocatedOrderByIdAsc(boolean allocated);
	
	
	List<TimeSlots> findByIdIn(List<Long> ids);
	
	TimeSlots findByIdAndAllocatedOrderByIdAsc(Long id,boolean allocated);
	
	Page<TimeSlots>  findByAllocated(boolean allocated,Pageable pageable);

	@Query(value = "SELECT * FROM time_slots WHERE allocated=FALSE ORDER BY id ASC LIMIT 1", nativeQuery = true)
	TimeSlots  findFirstOrderById();
	
	@Modifying
	@Procedure
	String fn_create_timeslots();
	
	@Query(value = "SELECT distinct(job_id) FROM time_slots WHERE allocated =:allocated",nativeQuery = true)
	List<String> findJobIdByAllocated(boolean allocated);

	List<TimeSlots> findByJobId(String jobName);
	
	long countByAllocated(boolean allocated);
	
	@Query(value = "SELECT t.allocated,t.job_id as JobId,a.asset_code as AssetCode,a.name as AssetName,v.vendor_id as VendorId,v.name as VendorName,r.account_no as AccountNumber,r.jenkins_command as jenkinsCommand ,r.executed_status as status,r.last_executed as LastExecuted ,le_log_id as leLogId  FROM time_slots t "
			+ "LEFT JOIN robot r ON r.job_id = t.job_id "
			+ "LEFT JOIN asset a ON a.asset_code = r.asset_code "
			+ "LEFT JOIN vendor v ON v.vendor_id = r.vendor_id "
			+ "WHERE (from_time like concat(cast(:fromtime1 as TEXT), '%') or from_time like concat(cast(:fromtime2 as TEXT), '%')   ) AND DAY =:day AND t.allocated =true",nativeQuery = true)
	List<TimeSlotsInf>  findByHourAndDay(String fromtime1,String fromtime2,int day);
	

	
}
