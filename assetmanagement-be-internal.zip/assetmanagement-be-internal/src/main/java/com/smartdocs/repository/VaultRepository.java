package com.smartdocs.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.Vault;

@Repository
public interface VaultRepository extends JpaRepository<Vault, Long> {

	@Query("select v from Vault v where "  
	+" (:name is null or lower(v.name) like lower(concat('%', cast(:name as string),  '%' ))) ")
	Page<Vault> findByName(String name, Pageable page);

	List<Vault> findAllByIdIn(List<Long> vaultIds);
	
	Vault findOneByName(String name);
	
	
	@Query("select vt from Vault vt where vt.id in (select ac.vaultId from AssetAccount ac where ac.vendorId in ( select v.vendorId from Vendor v where vendorId = :vendorId ))")
	List<Vault> findVaultByVendorId(String vendorId);
	
	@Query(value = "select * from vault vt inner join asset_account ac on vt.id=ac.vault_id  where ac.account_number =:accountNo limit 1",nativeQuery = true)
     Vault findByAccountNumber(String accountNo);

	@Query("select v from Vault v where "  
	+" (:name is null or lower(v.name) like lower(concat('%', cast(:name as string),  '%' ))) ")
	List<Vault> findByName(String name);
}
