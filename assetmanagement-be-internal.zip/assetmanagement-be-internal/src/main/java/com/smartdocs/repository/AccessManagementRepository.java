package com.smartdocs.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.AccessManagement;

@Repository
public interface AccessManagementRepository extends JpaRepository<AccessManagement, Long> {

	Optional<AccessManagement> findOneByAppIdIgnoreCaseAndUserEmail(String appId,String userEmail);
	
	Optional<AccessManagement> findByIdAndUserEmail(Long id,String userEmail);

	List<AccessManagement> findByUserEmail(String userEmail);

	Optional<AccessManagement> findByAppIdAndAppSecret(String appId,String appSecret);
	
}
