package com.smartdocs.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.smartdocs.model.MissingBills;
import com.smartdocs.sql.dto.MissingBillInf;

@Repository
public interface MissingBillsRepository extends JpaRepository<MissingBills, String> {


	@Query(value = "select a.name as AssetName, a.asset_code as AssetCode,ac.account_number as AccountNo,ac.channel,ac.frequency,v.name as VendorName,v.vendor_id as VendorId,m.period from missing_bills m "
			+ " left join asset a on a.asset_code=m.asset_code "
			+ " left join asset_account ac on ac.account_number=m.account_no "
			+ " left join vendor v on v.vendor_id=m.vendor_id " + " where "
			+ " (:channel is null or cast(:channel as TEXT) = ac.channel )"
			+ " and (:period is null or m.period like concat('%' ,cast(:period as TEXT), '%'))"
			+ " and (:assetCode is null or cast(:assetCode as TEXT) =a.asset_code) "
			+ " and (:accountNo is null or cast(:accountNo as TEXT) =ac.account_number) "
			+ " and (:manualIntervention = false or v.manual_intervention=:manualIntervention) "
			+ " and (:vendorId is null or cast(:vendorId as TEXT) =v.vendor_id) "
			+ " and (:status is null or m.status =cast(:status as TEXT) )", nativeQuery = true)
	List<MissingBillInf> searchMissingBillsList(boolean manualIntervention,String status, String period, String assetCode, String accountNo,
			String vendorId, String channel);

	@Query(value = "delete from missing_bills WHERE status !='Obsolete'", nativeQuery = true)
	@Modifying
	@Transactional
	void deleteAllRecords();

	@Query("delete from MissingBills m where m.assetCode=:assetCode and m.accountNo=:accountNumber and m.vendorId=:vendorId and m.status is not 'Obsolete'")
	@Modifying
	@Transactional
	void deleteByAssetCodeAndAccountNoAndVendorId(String assetCode, String accountNumber, String vendorId);
	

	@Query(value = "UPDATE missing_bills SET status = 'Obsolete' , comments =cast(:comments as TEXT) WHERE id IN :ids", nativeQuery = true)
	@Modifying
	void setObsoleteByIds(List<String> ids,String comments);

	@Query(value = "select a.name as AssetName, a.asset_code as AssetCode,ac.account_number as AccountNo,ac.channel as channel,ac.frequency as frequency,v.name as VendorName,v.vendor_id as VendorId,m.period,m.id,m.status from missing_bills m "
			+ " left join asset a on a.asset_code=m.asset_code "
			+ " left join asset_account ac on ac.account_number=m.account_no "
			+ " left join vendor v on v.vendor_id=m.vendor_id " + " where "
			+ " (:channel is null or cast(:channel as TEXT) = ac.channel )"
			+ " and (:period is null or m.period like concat('%' ,cast(:period as TEXT), '%'))"
			+ " and (:assetCode is null or cast(:assetCode as TEXT) =a.asset_code) "
			+ " and (:accountNo is null or cast(:accountNo as TEXT) =ac.account_number) "
			+ " and (:vendorId is null or cast(:vendorId as TEXT) =v.vendor_id) "
			+ " and (:manualIntervention = false or v.manual_intervention=:manualIntervention) "
			+ " and (:status is null or m.status =cast(:status as TEXT)) "
			+ " group by m.id,a.id,ac.account_number,ac.channel,ac.frequency,v.id order by true ", nativeQuery = true)
	Page<MissingBillInf> searchMissingBillsByNativeQuery(boolean manualIntervention,String status, String period, String assetCode,
			String accountNo, String vendorId, String channel, Pageable pageable);
}
