package com.smartdocs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.SmartStoreConfigurator;

@Repository
public interface SmartStoreConfiguratorRepository extends JpaRepository<SmartStoreConfigurator, Long> {

}
