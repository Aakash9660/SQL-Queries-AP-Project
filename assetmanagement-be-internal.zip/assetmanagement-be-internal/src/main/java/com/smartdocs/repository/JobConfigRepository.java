package com.smartdocs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.smartdocs.model.JobConfigModel;

@Repository
public interface JobConfigRepository extends JpaRepository<JobConfigModel,Long>  {
	
}
