package com.smartdocs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.RobotLogActivityDetail;

@Repository
public interface RobotLogActivityDetailRepository extends JpaRepository<RobotLogActivityDetail,Long>  {
	
	List<RobotLogActivityDetail> findByRobotLogIdOrderByIdDesc(String robotLogId);
}
