package com.smartdocs.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.BufferDocument;

@Repository
public interface BufferDocumentRepository extends JpaRepository<BufferDocument, Long> {
	BufferDocument findOneByTxId(String txId);
	
	@Query("select b from BufferDocument b where "
			+ "(:assetCode is null or lower(b.assetCode) like lower(concat('%', cast(:assetCode as string),  '%' ))) "
			+ "and (:vendorId is null or lower(b.vendorId) like lower(concat('%', cast(:vendorId as string),  '%' )))"
			+ "and (:accountNumber is null or lower(b.accountNumber) like lower(concat('%', cast(:accountNumber as string),  '%' )))"
			+ "and (:jobId is null or lower(b.jobId) like lower(concat('%', cast(:jobId as string),  '%' )))"
			+"and (:status is null or b.status=:status)"
			+ "and (:txId is null or lower(b.txId) like lower(concat('%', cast(:txId as string),  '%' )))"
			)
	Page<BufferDocument> serachPage(String assetCode, String vendorId, String accountNumber, String jobId,String txId,
			Integer status ,Pageable page);


}
