package com.smartdocs.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.EmployeeMaster;


@Repository
public interface EmployeeMasterRepository extends JpaRepository<EmployeeMaster, Long> {

	@Query("select e from EmployeeMaster e where "
			+ "(:email is null or lower(e.email) like lower(concat('%', cast(:email as string),  '%' ))) "
			 + "and (:firstName is null or lower(e.firstName) like lower(concat('%', cast(:firstName as string),  '%' ))) "
			 + "and (:lastName is null or lower(e.lastName) like lower(concat('%', cast(:lastName as string),  '%' ))) "
			)
	Page<EmployeeMaster> findAllEmployeeMaster(String email,String firstName,String lastName, Pageable page);
	
	
	@Query("select e from EmployeeMaster e where "
			+ " (:firstName is null or lower(e.firstName) like lower(concat('%', cast(:firstName as string),  '%' ))) "
			 + "or (:lastName is null or lower(e.lastName) like lower(concat('%', cast(:lastName as string),  '%' ))) ")
	List<EmployeeMaster> findByName(String firstName,String lastName);
}
