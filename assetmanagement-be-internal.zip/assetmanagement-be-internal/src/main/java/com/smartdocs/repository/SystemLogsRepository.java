package com.smartdocs.repository;

import java.time.ZonedDateTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.smartdocs.model.log.SystemLogs;

public interface SystemLogsRepository extends JpaRepository<SystemLogs, Long> {

	
	@Query("select a from SystemLogs a where "
			+ "(:systemTag is null or lower(a.systemTag) like lower(concat('%', cast(:systemTag as string), '%' ))) "
			+ "and (:ip is null or lower(a.ip) like lower(concat('%', cast(:ip as string), '%' ))) "
			+ "and (:jobId is null or a.jobId=:jobId ) "
			+ "and (:agentId is null or lower(a.agentId) like lower(concat('%', cast(:agentId as string), '%' ))) "
	      + " and ((cast(:fromDate as timestamp) is null and cast(:toDate as timestamp) is null) or (a.dateTime >= :fromDate and a.dateTime < :toDate)) ")
	Page<SystemLogs> findBySystemTag(String systemTag,String ip,String agentId,String jobId,ZonedDateTime fromDate,ZonedDateTime toDate,Pageable page);

}
