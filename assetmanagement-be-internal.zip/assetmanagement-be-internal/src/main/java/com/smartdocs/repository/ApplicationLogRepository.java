package com.smartdocs.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.model.log.ApplicationLog;


@Repository
public interface ApplicationLogRepository extends JpaRepository<ApplicationLog, String> , JpaSpecificationExecutor<ApplicationLog>{

	public Page<ApplicationLog> findAll(Pageable pageable);

	@Query("select a from ApplicationLog a where "
			+ "(:type is null or lower(a.type) like lower(concat('%', cast(:type as string), '%' ))) "
			+ "and (:ipAddress is null or lower(a.ipAddress) like lower(concat('%', cast(:ipAddress as string), '%' ))) "
			+ "and (:agent is null or lower(a.agent) like lower(concat('%', cast(:agent as string), '%' ))) "
	        +" and (:dateTime is null) or  (cast(a.dateTime as string) like %:dateTime%)")
	public Page<ApplicationLog> findByType(String type, String ipAddress, String agent, String dateTime, Pageable pageable);
	
}
