package com.smartdocs.service;

import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.EmailChannel;
import com.smartdocs.repository.EmailChannelRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class EmailChannelService {
	@Autowired
	private EmailChannelRepository emailChannelsRepository;

	public Page<Map<String, Object>> getEmailChannel(String user, String authType, String orderBy,String tenantId, int pageIndex,
			int size) {
		if (StringUtils.isBlank(user)) {
			user = null;
		} else {
			user = user.trim();
		}
		if (StringUtils.isBlank(authType)) {
			authType = null;
		} else {
			authType = authType.trim();
		}
		if (StringUtils.isBlank(tenantId)) {
			tenantId = null;
		} else {
			tenantId = tenantId.trim();
		}
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		try {
			return this.emailChannelsRepository.getEmailChannelPage(user, authType,tenantId, page).map(this::getJson);

		} catch (Exception e) {
			page = PageRequest.of(pageIndex, size);
			return this.emailChannelsRepository.getEmailChannelPage(user, authType,tenantId, page).map(this::getJson);
		}

	}
	
	public JsonResponse updateEmailChannel(String id,String sharedEmail) {
		Optional<EmailChannel> existEmail = emailChannelsRepository.findById(id);
		if(existEmail.isPresent()){
			existEmail.get().setSharedEmail(sharedEmail);
			emailChannelsRepository.save(existEmail.get());
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Update Successfully", JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't Updated", JsonResponse.STATUS_500);
	}

	public Map<String, Object> getJson(EmailChannel emailChannel) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("id", emailChannel.getId());
		jsonObject.put("authType", emailChannel.getAuthType());
		jsonObject.put("email", emailChannel.getEmail());
		jsonObject.put("expires_in", emailChannel.getExpires_in());
		jsonObject.put("lastUpdated", emailChannel.getLastUpdated());
		jsonObject.put("redirectURL", emailChannel.getRedirectURI());
		jsonObject.put("isEnabled", emailChannel.isEnabled());
		jsonObject.put("sharedEmail", emailChannel.getSharedEmail());
		return jsonObject.toMap();
	}

	public JsonResponse deleteEmailChannel(String emailChannelId) {
		JsonResponse jsonResponse = new JsonResponse();
		Optional<EmailChannel> emailChannelExist = emailChannelsRepository.findById(emailChannelId);
		if (emailChannelExist.isPresent()) {
			emailChannelsRepository.deleteById(emailChannelId);
			jsonResponse.setMessage("Successfully Deleted...");
			jsonResponse.setStatus(JsonResponse.RESULT_SUCCESS);
			jsonResponse.setStatusCode(JsonResponse.STATUS_200);
			return jsonResponse;
		} else {
			jsonResponse.setMessage("Email Channel Id " + emailChannelId + " Not Found");
			jsonResponse.setStatus(JsonResponse.RESULT_FAILED);
			jsonResponse.setStatusCode(JsonResponse.STATUS_404);
			return jsonResponse;
		}
	}
}
