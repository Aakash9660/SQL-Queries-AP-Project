package com.smartdocs.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.AssetType;
import com.smartdocs.repository.AssetTypeRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class AssetTypeService {

	@Autowired
	private AssetTypeRepository assetTypeRepository; 
	
	public JsonResponse createAssetType(AssetType assetType) {
		if (assetType != null && assetType.getName() != "" && assetType.getName() != null) {
			Optional<AssetType> existassetType = assetTypeRepository.findOneByNameIgnoreCase(assetType.getName());
			if (existassetType.isPresent()) {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Asset Type is already exist",
						JsonResponse.STATUS_400);
			}
			return new JsonResponse(assetTypeRepository.save(assetType), JsonResponse.RESULT_SUCCESS,
					"New Asset type created", JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "AssetType or Asset Type name is empty",
					JsonResponse.STATUS_400);

		}
	}

	public JsonResponse getAssetType(String name) {
		Optional<AssetType> existassetType = assetTypeRepository.findOneByNameIgnoreCase(name);
		if (existassetType.isPresent()) {
			return new JsonResponse(existassetType.get(), JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't get Asset Type from " + name,
					JsonResponse.STATUS_404);
		}
	}

	public List<AssetType> getAssetTypeList() {
		return assetTypeRepository.findAll();
	}

	public Page<AssetType> getAssetTypePage(String query, int pageIndex, int size, String orderBy) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		try {
			return assetTypeRepository.getPage(query, page);
		} catch (Exception e) {
			page = PageRequest.of(pageIndex, size);
			return assetTypeRepository.getPage(query, page);
		}

	}

	@Transactional
	public JsonResponse deleteAssetType(String name) {
		Optional<AssetType> existassetType = assetTypeRepository.findOneByNameIgnoreCase(name);
		if (existassetType.isPresent()) {
			assetTypeRepository.deleteByNameIgnoreCase(name);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Sucessfully deleted " + name,
					JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't get Asset Type from " + name,
					JsonResponse.STATUS_404);
		}
	}

	public JsonResponse updateAssetType(AssetType assetType) {
		if (assetType != null && assetType.getName() != "" && assetType.getName() != null) {
			Optional<AssetType> existassetType = assetTypeRepository.findOneByNameIgnoreCase(assetType.getName());
			if (existassetType.isPresent()) {
				existassetType.get().setName(existassetType.get().getName());
				existassetType.get().setDescription(assetType.getDescription());
				return new JsonResponse(assetTypeRepository.save(existassetType.get()), JsonResponse.RESULT_SUCCESS,
						"Update sucessfully", JsonResponse.STATUS_200);
			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, " Asset Type name can't update",
						JsonResponse.STATUS_404);
			}
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Asset type or Asset type name is null or empty",
					JsonResponse.STATUS_404);
		}
	}

}
