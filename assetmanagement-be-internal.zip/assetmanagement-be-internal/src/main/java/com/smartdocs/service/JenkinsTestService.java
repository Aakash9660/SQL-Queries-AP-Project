package com.smartdocs.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartdocs.jenkins.dto.Hudson;

public class JenkinsTestService {

	public static void main(String[] args) {
		Hudson resp = null;
		try {
			String jenkinsServerUsername="Sdocs-admin";
			String jenkinsServerPassword="ActIprocess_v6-71";
			String urlP="https://autopilot2.smartdocs.one/api/json?tree=jobs[name,builds[number,url,inProgress,estimatedDuration,duration,keepLog,building,id,timestamp,queueId,result]{0,1}]&pretty=true";
			URL url = new URL(urlP); // Jenkins URL localhost:8080, job named
			String authStr = jenkinsServerUsername + ":" + jenkinsServerPassword;
			String encoding = Base64.getEncoder().encodeToString(authStr.getBytes("utf-8"));

			StringBuilder body = null;
			String line = "";

			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("Authorization", "Basic " + encoding);
			if (connection.getResponseCode() == 200) {
				InputStream content = connection.getInputStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(content));
				body = new StringBuilder();
				while ((line = br.readLine()) != null) {
					//System.out.println("line :" + line);
					body.append(line);
				}
				connection.disconnect();
				ObjectMapper mapper = new ObjectMapper();
				//mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				resp = mapper.readValue(body.toString(), Hudson.class);
				//JobWithDetails jobWithDetails = jenkins.getJob(jobId);
				System.out.println("?>>");
				System.out.println(":"+resp);

			}
		} catch (Exception e) {
			System.out.println("Ex:"+e.getMessage());
			 e.printStackTrace();
		}
			System.out.println("we are good.");
		 
	}
	
}
