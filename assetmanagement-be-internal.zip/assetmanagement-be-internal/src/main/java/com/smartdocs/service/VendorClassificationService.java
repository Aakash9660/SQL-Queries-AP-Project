package com.smartdocs.service;

import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.VendorClassifications;
import com.smartdocs.repository.VendorClassificationsRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class VendorClassificationService {

	@Autowired
	private VendorClassificationsRepository vendorClassificationsRepository; 
	
	public JsonResponse createVendorClassifications(VendorClassifications classifications) {
		if (classifications != null && classifications.getName() != "" && classifications.getName() != null) {
			Optional<VendorClassifications> existassetType = vendorClassificationsRepository
					.findByNameIgnoreCase(classifications.getName());
			if (existassetType.isPresent()) {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Classification is already created",
						JsonResponse.STATUS_400);
			}
			return new JsonResponse(vendorClassificationsRepository.save(classifications), JsonResponse.RESULT_SUCCESS,
					"New Classification created", JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED,
					"Vendor classifications or Vendorclassifications name is empty", JsonResponse.STATUS_400);
		}
	}

	public JsonResponse getVendorClassifications(String name) {
		Optional<VendorClassifications> existvenclass = vendorClassificationsRepository.findByNameIgnoreCase(name);
		if (existvenclass.isPresent()) {
			return new JsonResponse(existvenclass.get(), JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't get VendorClassifications from " + name,
					JsonResponse.STATUS_404);
		}
	}

	public Page<VendorClassifications> getVendorClassificationsPage(String query, String orderBy, int pageIndex,
			int size) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		try {
			return vendorClassificationsRepository.getPage(query, page);
		} catch (Exception e) {
			page = PageRequest.of(pageIndex, size);
			return vendorClassificationsRepository.getPage(query, page);
		}
	}

	@Transactional
	public JsonResponse deleteVendorClassifications(String name) {
		Optional<VendorClassifications> existvenclass = vendorClassificationsRepository.findByNameIgnoreCase(name);
		if (existvenclass.isPresent()) {
			vendorClassificationsRepository.deleteByNameIgnoreCase(name);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Sucessfully deleted " + name,
					JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't delete VendorClassifications from " + name,
					JsonResponse.STATUS_404);
		}
	}

	public JsonResponse updateVendorClassifications(VendorClassifications vendorClassifications) {
		if (vendorClassifications != null && vendorClassifications.getName() != ""
				&& vendorClassifications.getName() != null) {
			Optional<VendorClassifications> existvenclass = vendorClassificationsRepository
					.findByNameIgnoreCase(vendorClassifications.getName());
			if (existvenclass.isPresent()) {
				existvenclass.get().setName(existvenclass.get().getName());
				existvenclass.get().setDescription(vendorClassifications.getDescription());
				return new JsonResponse(vendorClassificationsRepository.save(existvenclass.get()),
						JsonResponse.RESULT_SUCCESS, "Update sucessfully", JsonResponse.STATUS_200);
			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Vendor Classifications name can't update ",
						JsonResponse.STATUS_404);
			}
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED,
					"Vendor Classifications  or Vendor Classifications name is null or empty", JsonResponse.STATUS_404);
		}
	}
}
