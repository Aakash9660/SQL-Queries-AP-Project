package com.smartdocs.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.google.api.client.http.GenericUrl;
import com.smartdocs.service.util.HttpClientUtil;
import com.smartdocs.service.util.OAuthConstants;
import com.smartdocs.service.util.OauthResponseHandler;

@Component
public class OauthUtils {

	private static final Logger log = LoggerFactory.getLogger(OauthUtils.class);

	public static String getRedirectUri(HttpServletRequest req) {
		log.info("OauthUtils -> getRedirectUri");
		GenericUrl url = new GenericUrl(req.getRequestURL().toString());
		url.setRawPath("/microservices/sso/ad/redirect");
		   if(!url.getHost().equalsIgnoreCase("localhost")){
			   url.setScheme("https");
		   }
		return url.build();

	}
	public static JSONObject getAccessToken(String code,  String redirectUri,String appId, String appSecreat)
			throws JSONException {
		log.info("OauthUtils -> getAccessToken");
		String requestBody = new StringBuilder(OAuthConstants.CLIENT_ID).append("=")
				.append(appId).append("&").append(OAuthConstants.CLIENT_SECRET)
				.append("=").append(appSecreat).append("&").append(OAuthConstants.CODE)
				.append("=").append(code).append("&").append(OAuthConstants.REDIRECT_URI).append("=")
				.append(redirectUri).append("&").append(OAuthConstants.RESOURCE).append("=")
				.append(OAuthConstants.ONEDRIVE_RESOURCE_URL)

				.append("&").append(OAuthConstants.GRANT_TYPE).append("=authorization_code").append("&prompt=none").toString();

		JSONObject jsonObject = null;
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
			HttpPost httpPost = new HttpPost(OAuthConstants.ONEDRIVE_ACCESS_TOKEN_URL);
			System.out.println("requestBody"+requestBody);
			ByteArrayEntity byteArrayEntity = new ByteArrayEntity(requestBody.getBytes(),
					ContentType.APPLICATION_FORM_URLENCODED);
			httpPost.setEntity(byteArrayEntity);

			String rawResponse = httpClient.execute(httpPost, new OauthResponseHandler());
			System.out.println(rawResponse);
			log.info("Raw Response: {}", rawResponse);
			jsonObject = new JSONObject(rawResponse);

		} catch (Exception e) {
			 
			log.error("Exception: {}", e.getMessage());

		}

		return jsonObject;
	}

	public static JSONObject refreshTokenn(String refreshToken, String redirectURL) throws JSONException {
		log.info("OauthUtils -> refreshTokenn");
		String requestBody = new StringBuilder(OAuthConstants.CLIENT_ID).append("=")
				.append("1fadbb45-cd60-4bc6-88d9-0928c31b8acc").append("&").append(OAuthConstants.CLIENT_SECRET)
				.append("=").append("l-h?fpjcSK/I:icYyxrc9TOXlHN2Yl25").append("&").append(OAuthConstants.REFRESH_TOKEN)
				.append("=").append(refreshToken).append("&").append(OAuthConstants.REDIRECT_URI).append("=")
				.append(redirectURL).append("&").append(OAuthConstants.RESOURCE).append("=")
				.append(OAuthConstants.ONEDRIVE_RESOURCE_URL)

				.append("&").append(OAuthConstants.GRANT_TYPE).append("=").append(OAuthConstants.REFRESH_GRANT_TYPE)
				.toString();

		HttpPost httpPost = new HttpPost(OAuthConstants.ONEDRIVE_ACCESS_TOKEN_URL);
		ByteArrayEntity byteArrayEntity = new ByteArrayEntity(requestBody.getBytes(),
				ContentType.APPLICATION_FORM_URLENCODED);
		httpPost.setEntity(byteArrayEntity);
		HttpResponse httpResponse = HttpClientUtil.executePost(httpPost);
		JSONObject jsonObject = null;
		try {
			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				log.debug("Status is not 200");
			} else {
				String response = IOUtils.toString(httpResponse.getEntity().getContent());
				jsonObject = new JSONObject(response);
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		return jsonObject;
	}

	public static JSONObject getGraphAccessToken(String code,  String redirectUri,String appId, String appSecreat,String tenantId)
			throws JSONException {
		log.info("OauthUtils -> getIMAPAccessToken");
		String requestBody = new StringBuilder(OAuthConstants.CLIENT_ID).append("=")
				.append(appId).append("&").append(OAuthConstants.CLIENT_SECRET)
				.append("=").append(appSecreat)
				.append("&").append(OAuthConstants.CODE).append("=").append(code)
				.append("&").append(OAuthConstants.REDIRECT_URI).append("=")
				.append(redirectUri)
				.append("&").append(OAuthConstants.GRANT_TYPE).append("=authorization_code").append("&prompt=none").toString();
		JSONObject jsonObject = null;
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
			String accessTokenURL=OAuthConstants.SMTP_OAUTH_ACCESS_TOKEN_URL.replace("{tenantId}", tenantId);
			HttpPost httpPost = new HttpPost(accessTokenURL);
			ByteArrayEntity byteArrayEntity = new ByteArrayEntity(requestBody.getBytes(),
					ContentType.APPLICATION_FORM_URLENCODED);
			httpPost.setEntity(byteArrayEntity);
			
			String rawResponse = httpClient.execute(httpPost, new OauthResponseHandler());
			log.info("Raw Response: {}", rawResponse);
			
			
			jsonObject = new JSONObject(rawResponse);
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured: {}", e.getMessage());
			
		}
		return jsonObject;
	}
	
	
	public static JSONObject getUser(String accessToken)
			throws JSONException {
		log.info("OauthUtils -> getUser");
		 
		JSONObject jsonObject = null;
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
			String meURL=OAuthConstants.SMTP_OAUTH_RESOURCE_URL+"v1.0/me";
			HttpGet httpGet = new HttpGet(meURL);
			 
			httpGet.setHeader("Authorization","Bearer "+accessToken);
			
			String rawResponse = httpClient.execute(httpGet, new OauthResponseHandler());
			log.info("Raw Response: {}", rawResponse);
			jsonObject = new JSONObject(rawResponse);
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception occured: {}", e.getMessage());
			
		}
		return jsonObject;
	}
	
	public static JSONObject refreshIMAPToken(String refreshToken,String clientId,String clientSecret,String tenantId, String redirectURL) throws JSONException {
		log.info("refreshIMAPToken ...");
		String requestBody = new StringBuilder(OAuthConstants.CLIENT_ID).append("=")
				.append(clientId).append("&").append(OAuthConstants.CLIENT_SECRET)
				.append("=").append(clientSecret).append("&").append(OAuthConstants.REFRESH_TOKEN)
				.append("=").append(refreshToken).append("&").append(OAuthConstants.REDIRECT_URI).append("=")
				.append(redirectURL)
				//.append("&").append(OAuthConstants.RESOURCE).append("=")
				//.append(OAuthConstants.ONEDRIVE_RESOURCE_URL)
				.append("&").append(OAuthConstants.GRANT_TYPE).append("=").append(OAuthConstants.REFRESH_GRANT_TYPE)
				.toString();

		//log.debug(requestBody.toString());
		System.out.println(requestBody);
		System.out.println(tenantId);
		log.info("request Body : {}",requestBody);
		String accessTokenURL=OAuthConstants.SMTP_OAUTH_ACCESS_TOKEN_URL.replace("{tenantId}", tenantId);
		HttpPost httpPost = new HttpPost(accessTokenURL);
		ByteArrayEntity byteArrayEntity = new ByteArrayEntity(requestBody.getBytes(),
				ContentType.APPLICATION_FORM_URLENCODED);
		httpPost.setEntity(byteArrayEntity);
		HttpResponse httpResponse = HttpClientUtil.executePost(httpPost);
		JSONObject jsonObject = null;
		try {
			log.info("response code: {}",httpResponse.getStatusLine().getStatusCode());
			System.out.println();
			if (httpResponse.getStatusLine().getStatusCode() != 200) {
				String response = IOUtils.toString(httpResponse.getEntity().getContent());
				System.out.println(response);
			} else {
				String response = IOUtils.toString(httpResponse.getEntity().getContent());
				System.out.println("response >> "+response);
				jsonObject = new JSONObject(response);
			}
		} catch (IOException e) {
			log.error("Exception : {}",e);
			throw new RuntimeException(e);
		}
		
		return jsonObject;
	}
}
