package com.smartdocs.service;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.net.URL;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.apache.commons.lang.RandomStringUtils;

import com.smartdocs.model.SmartStoreConfigurator;
import com.smartdocs.model.Vendor;
import com.smartdocs.mongo.collections.EmailTemplates;
import com.smartdocs.mongo.collections.EmailTemplatesConstants;
import com.smartdocs.mongo.collections.Emails;
import com.smartdocs.mongo.repository.EmailTemplatesRepository;
import com.smartdocs.mongo.repository.EmailsRepository;
import com.smartdocs.repository.VendorRepository;

import java.util.regex.Pattern;

@Service
public class SendEmailService {

	private static final Logger logging = LoggerFactory.getLogger(SendEmailService.class);
	
	@Value("${url}")
	private String frontEndURI;
	
	@Autowired
	private EmailTemplatesRepository emailTemplateRepository;
	
	@Autowired
	private EmailsRepository emailsRepository;
	
	@Autowired
	private DocumentUploadService documentUploadService;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private VendorRepository vendorRepository;
	

	@Value("${smtp.email}")
	private String from;
	
	
	public void sendL1ReviewNotification(String name, List<String> toRecipients,
			String assetCode,String vendorId,String accountNo, String comments
			) {
		System.out.println("Sending l1 Notiffication.");
		Vendor vendor = vendorRepository.findFirstByVendorId(vendorId);
		String vendorName="";
		if(vendor!=null) {
			vendorName=vendor.getName();
		}
		Map<String, String> data = new HashMap<>();
		data.put("name", name);
		data.put("assetCode", assetCode);
		data.put("vendorId", vendorId);
		data.put("lastComment", comments);
		data.put("vendorName", vendorName);
		data.put("accountNo", accountNo);
		data.put("item_url",frontEndURI + "");
		data.put("inbox_url","");

		data.put("app_url", frontEndURI + "/sp/company/dashboard");

		EmailTemplates emailTemplates = getEmailTemplates(
				EmailTemplatesConstants.AP_FAILED_BOT_L1_REVIEW);

		if (emailTemplates != null) {
			 sendEmail(emailTemplates, data, toRecipients, null);
		}
	}
	
	
	public void sendL2ReviewNotification(String name, List<String> toRecipients,String assetCode,String vendorId,String accountNo,String comments) {
		
		Vendor vendor = vendorRepository.findFirstByVendorId(vendorId);
		String vendorName="";
		if(vendor!=null) {
			vendorName=vendor.getName();
		}
		Map<String, String> data = new HashMap<>();
		data.put("name", name);
		data.put("assetCode", assetCode);
		data.put("vendorId", vendorId);
		data.put("accountNo", accountNo);
		data.put("lastComment", comments);
		data.put("vendorName", vendorName);
		data.put("item_url",frontEndURI + "");
		data.put("inbox_url","");

		data.put("app_url", frontEndURI + "/sp/company/dashboard");

		EmailTemplates emailTemplates = getEmailTemplates(
				EmailTemplatesConstants.AP_FAILED_BOT_L2_REVIEW);

		if (emailTemplates != null) {
			 sendEmail(emailTemplates, data, toRecipients, null);
		}
	}
	
	private void sendEmail(EmailTemplates emailTemplates, Map<String, String> data, List<String> toRecipients,
			List<String> ccRecipients) {
		logging.info("Sending email..");
		String body = emailTemplates.getMainTemplate();
		if (body != null) {
			String subject = emailTemplates.getSubject();
			try {
				for (Map.Entry<String, String> entry : data.entrySet()) {
					if (entry.getValue() != null) {
						body = replaceAll(body, "{{" + entry.getKey() + "}}", entry.getValue());
						subject = replaceAll(subject, "{{" + entry.getKey() + "}}", entry.getValue());

					} else {
						body = replaceAll(body, "{{" + entry.getKey() + "}}", "");
						subject = replaceAll(subject, "{{" + entry.getKey() + "}}", "");
					}
				}
			} catch (Exception e) {
				logging.error("Exception occured while replacing the key with value in main template: {}",
						e.getMessage());
			}

			Emails emails = new Emails(subject, emailTemplates.getId(), from, toRecipients, ccRecipients, null,
					emailTemplates.getTemplateId(), "AutoPilot", data);

			saveEmailBody(body, emails);
			
			emails.setEngine("SMTP");
			emails.setStatus("");
			emails.setEmailSent(false);
			
			emailsRepository.save(emails);
		}
	}
	
	private String replaceAll(String source, String key, String value) {
		value = value.replaceAll("\\r|\\n", "<br>");
		String[] split = source.split(Pattern.quote(key));
		StringBuilder builder = new StringBuilder();
		if (split.length > 0) {
			builder.append(split[0]);
			for (int i = 1; i < split.length; i++) {
				builder.append(value);
				builder.append(split[i]);
			}
		}
		while (source.endsWith(key)) {
			builder.append(value);
			source = source.substring(0, source.length() - key.length());
		}
		return builder.toString();
	}

	private boolean saveEmailBody(String body, Emails email) {
		try {
			logging.info("Saving Email Body");
			String url = "";
			String documentid = RandomStringUtils.randomAlphanumeric(32).toUpperCase();
			SmartStoreConfigurator ssConfig=adminService.getSmartStoreConfig().get(0);
			
			url = documentUploadService.buildURL(ssConfig, documentid, "create", "body.html");
			if (uploadFile(url, body, "text/html; charset=UTF-8") == 201) {
				email.setArchiveDocId(documentid);
				email.setArchiveId(ssConfig.getContRep());
			} else {
				email.setBody(body);
			}

		} catch (Exception e) {
			logging.error("Exception while saving email body: {}", e.getMessage());
			e.printStackTrace();
		}

		return true;
	}

	private int uploadFile(String url, String content, String conenttype) {
		logging.info("Uploading file");
		url = url.replace("ssp=true", "sp=true");
		//RetryOnExceptionStrategy retry = new RetryOnExceptionStrategy();
		int responceCode = 0;

			HttpURLConnection httpcon = null;
			try {
				ByteArrayOutputStream baos = new ByteArrayOutputStream(); // LINE A
				byte[] b = content.getBytes();
				baos.write(b); // LINE B

				httpcon = (HttpURLConnection) (new URL(url).openConnection());
				httpcon.setRequestProperty("User-Agent",
						"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
				httpcon.setRequestMethod("PUT");
				httpcon.setReadTimeout(100000);
				httpcon.setDoOutput(true);
				httpcon.setRequestProperty("Content-Type", conenttype);
				httpcon.connect();
				OutputStream os = httpcon.getOutputStream();
				os.write(baos.toByteArray(), 0, baos.size());
				responceCode = httpcon.getResponseCode();
				httpcon.disconnect();
				//break;
			} catch (Exception e) {
				e.printStackTrace();
				//try {
					//retry.errorOccured();
				//} catch (RuntimeException e1) {
				//	throw new RuntimeException("Exception while calling URL:" + url, e);
				///} catch (Exception e1) {
				//	throw new RuntimeException(e1);
				//}
			} finally {
				if (httpcon != null) {
					httpcon.disconnect();
				}

			}
		return responceCode;
	}
	
	private EmailTemplates getEmailTemplates(String id) {
		
		EmailTemplates emailTemplates = emailTemplateRepository.findOneByIdAndEnabled(id, true);
		if (emailTemplates != null && emailTemplates.getMainTemplate() != null) {
			emailTemplates.setMainTemplate(
					emailTemplates.getMainTemplate().replace("#signature", emailTemplates.getSignature()));
			emailTemplates
					.setMainTemplate(emailTemplates.getMainTemplate().replace("#header", emailTemplates.getHeader()));
			emailTemplates.setMainTemplate(emailTemplates.getMainTemplate().replace("#logo",
					"<img src='" + emailTemplates.getLogo() + "' alt='Logo'>"));
			emailTemplates.setMainTemplate(
					emailTemplates.getMainTemplate().replace("#body", emailTemplates.getTemplateBody()));
		} else {
			logging.error("Error -> Invalid email template Id : {}", id);
		}
		return emailTemplates;
	}
}
