package com.smartdocs.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.offbytwo.jenkins.JenkinsServer;
import com.offbytwo.jenkins.model.Build;
import com.offbytwo.jenkins.model.Job;
import com.offbytwo.jenkins.model.JobWithDetails;
import com.smartdocs.dto.BillDocumentRequest;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.RobotCustomData;
import com.smartdocs.jenkins.dto.APBuild;
import com.smartdocs.jenkins.dto.APJobWithDetails;
import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.BillDocument;
import com.smartdocs.model.Robot;
import com.smartdocs.model.Vault;
import com.smartdocs.model.VendorScript;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.AssetRepository;
import com.smartdocs.repository.BillDocumentRepository;
import com.smartdocs.repository.RobotRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.VaultRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.EncryptionDecryption;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.service.util.HttpReqRespUtils;

@Service
public class JenkinsService2 {

	@Value("${jenkinsUsername2}")
	private String jenkinsServer2Username;

	@Value("${jenkinsPassword2}")
	private String jenkinsServer2Password;

	@Value("${jenkinsUrl2}")
	private String jenkinsServer2Url;

	@Value("${sftpeqactualpath2}")
	private String sftpeqactualpath;

	@Autowired
	private RobotRepository robotRepository;

	@Autowired
	private SystemLogsRepository systemLogsRepository;

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private BillDocumentRepository billDocumentRepository;

	@Value("${sftpHost2}")
	private String sftpHost;

	@Value("${sftpPath2}")
	private String sftpPath;

	@Value("${sftpPort2}")
	private int sftpPort;

	@Value("${sftpUser2}")
	private String sftpUser;

	@Value("${sftpPassword2}")
	private String sftpPassword;

	@Value("${localPathToTransferFile}")
	private String localPathToTransferFile;

	@Value("${protocal2}")
	private String protocal;
	
	@Value("${baseURL}")
	private String baseURL;

	@Autowired
	private VaultRepository vaultRepository;

	public boolean removeFileFromFTP(String txtId, AssetAccount assetAccount, String fileName, String id) {
		String vendorId = assetAccount.getVendorId();
		String accountNo = assetAccount.getAccountNumber();
		String assetCode = assetAccount.getAssetCode();

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		try {

			JSch jSch = new JSch();

			Session session = jSch.getSession(sftpUser, sftpHost, sftpPort);

			session.setConfig("StrictHostKeyChecking", "no");

			session.setPassword(sftpPassword);
			System.out.println("connecting");
			try {

				session.connect();
			} catch (Exception e) {
				SystemLogs systemLogs = new SystemLogs("unPublish file from sftp", e.getLocalizedMessage(),
						ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_ERROR,
						SystemLogs.SYSTEM_TAG_SFTP, user.getEmail(), SystemLogs.USER, accountNo, vendorId, assetCode,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());

				systemLogsRepository.save(systemLogs);
				return false;
			}
			Channel channel=null;
			try {
				System.out.println("connected");
				channel= session.openChannel(protocal);

				ChannelSftp channelSftp = (ChannelSftp) channel;

				channelSftp.connect();
				System.out.println("remove files ");
				channelSftp.rm(sftpPath + "/" + fileName);
			} catch (Exception e) {
				SystemLogs systemLogs = new SystemLogs("unPublish file from sftp", e.getLocalizedMessage(),
						ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_ERROR,
						SystemLogs.SYSTEM_TAG_SFTP, user.getEmail(), SystemLogs.USER, accountNo, vendorId, assetCode,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());

				systemLogsRepository.save(systemLogs);
				
			}
			finally {
				 if (channel != null) {
				        Session sess = channel.getSession();
				        channel.disconnect();
				        sess.disconnect();
				        System.out.println(channel.isConnected());
				    }
			 }
			
			System.out.println("removed files ");
			SystemLogs systemLogs = new SystemLogs("unPublish file from sftp", fileName + " removed successfully",
					ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_SUCCESS,
					SystemLogs.SYSTEM_TAG_SFTP, user.getEmail(), SystemLogs.USER, accountNo, vendorId, assetCode,
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());

			systemLogsRepository.save(systemLogs);
			return true;
		} catch (Exception e) {

			SystemLogs systemLogs = new SystemLogs("unPublish file from sftp", e.getLocalizedMessage(),
					ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_ERROR,
					SystemLogs.SYSTEM_TAG_SFTP, user.getEmail(), SystemLogs.USER, accountNo, vendorId, assetCode,
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());

			systemLogsRepository.save(systemLogs);
			return false;
		}
	}

	public boolean createFileToFTP(String txId, AssetAccount assetAccount, String fileName, String jobId,
			VendorScript vendorScript) {
		String vendorId = assetAccount.getVendorId();
		String accountNo = assetAccount.getAccountNumber();
		String assetCode = assetAccount.getAssetCode();
		Long vaultId = assetAccount.getVaultId();
		File file = null;
		double kb = 0;
		String userEmail="";
		String userName="";
		try{
			SecurityContext securityContext = SecurityContextHolder.getContext();
			Authentication authentication = securityContext.getAuthentication();
			UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());
			userEmail=user.getEmail();
			userName=user.getName();
		}catch(Exception ex) {
			
		}
		try {

			String script = vendorScript.getCodeScript();

			if (script != null) {

				script = script.replace("{{Asset_Code}}", assetAccount.getAssetCode());
				script = script.replace("{{Vendor_ID}}", assetAccount.getVendorId());
				script = script.replace("{{Account_ID}}", assetAccount.getAccountNumber());
				script = script.replace("{{SecondaryAccountNo}}", assetAccount.getSecondaryAccountNumber());
				script = script.replace("{{JOB_ID}}", jobId);
				script = script.replace("{{BaseURL}}", baseURL);

				if (vaultId != null) {
					Optional<Vault> existVault = vaultRepository.findById(vaultId);
					if (existVault.isPresent()) {
						script = script.replace("{{LOGIN_ID}}", existVault.get().getUserId());
						if (existVault.get().getPassword() != null) {
							script = script.replace("{{LOGIN_PWD}}",
									EncryptionDecryption.decrypt(existVault.get().getPassword()));
						} else {
							script = script.replace("{{LOGIN_PWD}}", existVault.get().getPassword());
						}
					}
				}
			}

			String path = localPathToTransferFile + fileName;
			file = new File(path);

			// If file doesn't exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			if (script != null) {
				bw.write(script);
			}
			// Close connection
			bw.close();
			kb = (double) file.length() / 1024;

			if (kb != 0.0) {

				JSch jSch = new JSch();
				Session session = jSch.getSession(sftpUser, sftpHost, sftpPort);
				session.setConfig("StrictHostKeyChecking", "no");
				session.setPassword(sftpPassword);
				System.out.println("connecting");
				Channel channel=null;
				try {
					session.connect();
				} catch (Exception e) {

					SystemLogs systemLogs = new SystemLogs("transfer File To SFTP", e.getLocalizedMessage(),
							ZonedDateTime.now(), txId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_ERROR,
							SystemLogs.SYSTEM_TAG_SFTP, userEmail, SystemLogs.USER, accountNo, vendorId,
							assetCode, HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);
					systemLogsRepository.save(systemLogs);
					return false;
				}
				System.out.println("connected");
				try {
				 channel = session.openChannel(protocal);
				ChannelSftp channelSftp = (ChannelSftp) channel;
				channelSftp.connect();
				System.out.println("send files ");

				channelSftp.put(localPathToTransferFile + "/" + file.getName(), sftpPath);
				System.out.println("sent files ");
				}
				catch(Exception ex) {
					ex.printStackTrace();
				}
				 finally {
					 if (channel != null) {
					        Session sess = channel.getSession();
					        channel.disconnect();
					        sess.disconnect();
					        System.out.println(channel.isConnected());
					    }
				 }
				SystemLogs systemLogs = new SystemLogs("transfer File To SFTP",
						file.getName() + " file is sent successfully ", ZonedDateTime.now(), txId,
						SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_SFTP,
						userEmail, SystemLogs.USER, accountNo, vendorId, assetCode,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);
				systemLogsRepository.save(systemLogs);
				return true;
			} else {

				SystemLogs systemLogs = new SystemLogs("transfer File To SFTP",
						file.getName() + " file size is " + kb
								+ " KB couldn't able send to SFTP server please try again ",
						ZonedDateTime.now(), txId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_FAIL,
						SystemLogs.SYSTEM_TAG_SFTP, userEmail, SystemLogs.USER, accountNo, vendorId, assetCode,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);

				systemLogsRepository.save(systemLogs);
				return false;
			}

		} catch (Exception e) {

			SystemLogs systemLogs = new SystemLogs("transfer File To SFTP", e.getMessage(), ZonedDateTime.now(), txId,
					SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_SFTP,
					userEmail, SystemLogs.USER, accountNo, vendorId, assetCode,
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);
			systemLogsRepository.save(systemLogs);
			return false;
		}
	}

	public JsonResponse deleteJob(String jobName) throws URISyntaxException, IOException {
		JsonResponse jsonResponse = new JsonResponse();
		JenkinsServer jenkinsServer2 = new JenkinsServer(new URI(jenkinsServer2Url), jenkinsServer2Username,
				jenkinsServer2Password);
		JobWithDetails jobWithDetails = jenkinsServer2.getJob(jobName);
		if (jobWithDetails != null) {
			jenkinsServer2.deleteJob(jobName);
			robotRepository.deleteById(jobName);
			jsonResponse.setMessage("Successfully Deleted Job");
			jsonResponse.setStatus(JsonResponse.RESULT_SUCCESS);
			jsonResponse.setStatusCode(JsonResponse.STATUS_200);
			return jsonResponse;
		} else {
			Optional<Robot> robot = robotRepository.findById(jobName);
			if (robot.isPresent()) {
				robotRepository.deleteById(jobName);
			}
			jsonResponse.setMessage("No Job Found");
			jsonResponse.setStatusCode(JsonResponse.STATUS_404);
			return jsonResponse;
		}

	}

	public boolean createUpdateJob(String txtId, AssetAccount assetAccount, String jobName, String description,
			String fileName) throws ParserConfigurationException, TransformerConfigurationException {
		// + fileName
		String command = "npx playwright test " + fileName + " --headed";
		boolean isCreateUpdateJob = false;

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		try {

			JenkinsServer jenkinsServer2 = new JenkinsServer(new URI(jenkinsServer2Url), jenkinsServer2Username,
					jenkinsServer2Password);

			// our XML file for this example
			JobWithDetails jobWithDetailsOfJenkinsServer2 = jenkinsServer2.getJob(jobName);

			String JenkinsServer2JobXml = getXmLOfJenkinsServer2();
			String filePath = sftpeqactualpath;

			JenkinsServer2JobXml = JenkinsServer2JobXml.replace("{{customWorkspace}}", filePath);

			JenkinsServer2JobXml = JenkinsServer2JobXml.replace("{{command}}", command);

			JenkinsServer2JobXml = JenkinsServer2JobXml.replace("{{description}}", description);

			if (jobWithDetailsOfJenkinsServer2 != null) {
				jenkinsServer2.updateJob(jobName, JenkinsServer2JobXml, true);
				isCreateUpdateJob = true;

				SystemLogs systemLogs = new SystemLogs("Update Job in Jenkins server 2",
						jobName + " job is successfully updated", ZonedDateTime.now(), txtId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
						assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
						user.getName());
				systemLogsRepository.save(systemLogs);
			} else {
				jenkinsServer2.createJob(jobName, JenkinsServer2JobXml, true);
				isCreateUpdateJob = true;

				SystemLogs systemLogs = new SystemLogs("create Job in Jenkins server 2",
						jobName + " job is successfully created", ZonedDateTime.now(), txtId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
						assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
						user.getName());
				systemLogsRepository.save(systemLogs);
			}

			jenkinsServer2.close();

			return isCreateUpdateJob;
		} catch (Exception e) {
			e.printStackTrace();
			isCreateUpdateJob = false;

			SystemLogs systemLogs = new SystemLogs("create or Update Job", e.getMessage(), ZonedDateTime.now(), txtId,
					SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK,
					user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
					assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					user.getName());

			systemLogsRepository.save(systemLogs);
			return isCreateUpdateJob;
		}

	}

	public JsonResponse run(String jobId, String txId) throws URISyntaxException, IOException, InterruptedException {
		System.out.println("get job detail");

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		Optional<Robot> robotDetails = robotRepository.findById(jobId);

		JsonResponse jsonResponse = new JsonResponse();
		JobWithDetails jobWithDetails = null;

		try {
			JenkinsServer jenkinsServer2 = new JenkinsServer(new URI(jenkinsServer2Url), jenkinsServer2Username,
					jenkinsServer2Password);
			jobWithDetails = jenkinsServer2.getJob(jobId);
			if (jobWithDetails != null) {
				jobWithDetails.build(true);
				
				System.out.println(jobWithDetails);
				Thread.sleep(30000);

				SystemLogs systemLogs = new SystemLogs("Run the job in JK2",
						"Build run status is " + jobWithDetails.getLastBuild().details().getResult().toString(),
						ZonedDateTime.now(), txId, SystemLogs.SYSTEM_TYPE_JENKINS,
						jobWithDetails.getLastBuild().details().getResult().toString(), SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, robotDetails.get().getAccountNo(),
						robotDetails.get().getVendorId(), robotDetails.get().getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());
				systemLogsRepository.save(systemLogs);
				jsonResponse.setMessage("Bot execution Started");
				jsonResponse.setResult(jobWithDetails.getLastBuild().details().getResult());
				jsonResponse.setStatusCode(JsonResponse.STATUS_200);
				return jsonResponse;
			} else {
				SystemLogs systemLogs = new SystemLogs("Run the job in JK2",
						jobId + " Job id doesn't exist please create a job", ZonedDateTime.now(), txId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, robotDetails.get().getAccountNo(),
						robotDetails.get().getVendorId(), robotDetails.get().getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());
				systemLogsRepository.save(systemLogs);
				jsonResponse.setMessage(jobId + " Job id doesn't exist please create a job");
				jsonResponse.setStatusCode(JsonResponse.STATUS_404);
				return jsonResponse;
			}
		} catch (Exception e) {
			SystemLogs systemLogs = new SystemLogs("Run the job in JK2", e.getLocalizedMessage(), ZonedDateTime.now(), txId,
					SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK,
					user.getEmail(), SystemLogs.USER, robotDetails.get().getAccountNo(),
					robotDetails.get().getVendorId(), robotDetails.get().getAssetCode(),
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());
			systemLogsRepository.save(systemLogs);
			if (e.getLocalizedMessage() != "") {
				jsonResponse.setMessage(e.getLocalizedMessage());
			} else {
				jsonResponse.setMessage("Connection time out");
			}
			jsonResponse.setStatusCode(JsonResponse.STATUS_500);
			return jsonResponse;
		}
	}
 

	// ---------------------------------------

	public JobWithDetails getJobDetail(String jobId) {
		System.out.println("get job detail");
		JobWithDetails jobWithDetails = null;
		try {
			JenkinsServer jenkinsServer2 = new JenkinsServer(new URI(jenkinsServer2Url), jenkinsServer2Username,
					jenkinsServer2Password);
			jobWithDetails = jenkinsServer2.getJob(jobId);
			System.out.println(jobWithDetails);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("good");
		return jobWithDetails;
	}

	public APJobWithDetails getJobHistoryDetails(String jobId) {
		APJobWithDetails resp = null;
		String finalJenkinsUrl = jenkinsServer2Url;
		String finalJenkinsUsername = jenkinsServer2Username;
		String finalJenkinsPassword = jenkinsServer2Password;

		try {
			JenkinsServer jenkins = new JenkinsServer(new URI(finalJenkinsUrl), finalJenkinsUsername,
					finalJenkinsPassword);
			System.out.println(finalJenkinsUrl + "job/" + jobId + "/api/json");
			URL url = new URL(finalJenkinsUrl + "job/" + jobId + "/api/json"); // Jenkins URL localhost:8080, job named
																				// 'test'
			String user = finalJenkinsUsername; // username
			String pass = finalJenkinsPassword; // password or API token
			String authStr = user + ":" + pass;
			String encoding = Base64.getEncoder().encodeToString(authStr.getBytes("utf-8"));

			StringBuilder body = null;
			String line = "";

			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("Authorization", "Basic " + encoding);
			if (connection.getResponseCode() == 200) {
				InputStream content = connection.getInputStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(content));
				body = new StringBuilder();
				while ((line = br.readLine()) != null) {
					System.out.println("line :" + line);
					body.append(line);
				}

				connection.disconnect();

				ObjectMapper mapper = new ObjectMapper();
				mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				resp = mapper.readValue(body.toString(), APJobWithDetails.class);
				JobWithDetails jobWithDetails = jenkins.getJob(jobId);
				if (jobWithDetails != null) {
					List<Build> builds = jobWithDetails.getAllBuilds();
					List<APBuild> apBuilds = resp.getBuilds();

					System.out.println(builds.size());
					Build build = builds.get(0);
					build.details().getResult();
					int count = 0;

					for (count = builds.size() - 1; count >= 0; count--) {
						try {
							apBuilds.get(count).setTimeStamp(new Timestamp(builds.get(count).details().getTimestamp()));
							apBuilds.get(count).setStatus(builds.get(count).details().getResult().toString());

						} catch (Exception e) {
							apBuilds.get(count).setStatus("Running");
						}
					}

					if (jobWithDetails.getFirstBuild().details().getTimestamp() != 0) {
						resp.getFirstBuild()
								.setTimeStamp(new Timestamp(jobWithDetails.getFirstBuild().details().getTimestamp()));
						try {
							resp.getFirstBuild()
									.setStatus(jobWithDetails.getFirstBuild().details().getResult().toString());
						} catch (Exception e) {
							resp.getFirstBuild().setStatus("Running");
						}
					}

					if (jobWithDetails.getLastCompletedBuild().details().getTimestamp() != 0) {
						resp.getLastCompletedBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastCompletedBuild().details().getTimestamp()));
						resp.getLastCompletedBuild()
								.setStatus(jobWithDetails.getLastCompletedBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastFailedBuild().details().getTimestamp() != 0) {
						resp.getLastFailedBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastFailedBuild().details().getTimestamp()));
						resp.getLastFailedBuild()
								.setStatus(jobWithDetails.getLastFailedBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastStableBuild().details().getTimestamp() != 0) {
						resp.getLastStableBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastStableBuild().details().getTimestamp()));
						resp.getLastStableBuild()
								.setStatus(jobWithDetails.getLastStableBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastSuccessfulBuild().details().getTimestamp() != 0) {
						resp.getLastSuccessfulBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastSuccessfulBuild().details().getTimestamp()));
						resp.getLastSuccessfulBuild()
								.setStatus(jobWithDetails.getLastSuccessfulBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastUnstableBuild().details().getTimestamp() != 0) {
						resp.getLastUnstableBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastUnstableBuild().details().getTimestamp()));
						resp.getLastUnstableBuild()
								.setStatus(jobWithDetails.getLastUnstableBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastUnsuccessfulBuild().details().getTimestamp() != 0) {
						resp.getLastUnsuccessfulBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastUnsuccessfulBuild().details().getTimestamp()));
						resp.getLastUnsuccessfulBuild()
								.setStatus(jobWithDetails.getLastUnsuccessfulBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastBuild().details().getTimestamp() != 0) {
						resp.getLastBuild()
								.setTimeStamp(new Timestamp(jobWithDetails.getLastBuild().details().getTimestamp()));
						try {
							resp.getLastBuild()
									.setStatus(jobWithDetails.getLastBuild().details().getResult().toString());
						} catch (Exception e) {
							resp.getLastBuild().setStatus("Running");
						}
					}
				}
				System.out.println(resp);

			}
		} catch (Exception e) {

		}

		return resp;
	}

	public String getBuildConsole(int buildId, String jobId) throws URISyntaxException, IOException {
		String jsonResponse = null;
		String finalJenkinsUrl = jenkinsServer2Url;
		String finalJenkinsUsername = jenkinsServer2Username;
		String finalJenkinsPassword = jenkinsServer2Password;

		JenkinsServer jenkins = new JenkinsServer(new URI(finalJenkinsUrl), finalJenkinsUsername, finalJenkinsPassword);
		JobWithDetails jobWithDetails = jenkins.getJob(jobId);
		if (jobWithDetails != null) {
			Build build = jobWithDetails.getBuildByNumber(buildId);
			if (build != null) {
				jsonResponse = build.details().getConsoleOutputText();

			}
		}
		return jsonResponse;
	}

	private String getXmLOfJenkinsServer2() {
		String configXML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><project>\r\n"
				+ "<actions/>\r\n" + "<description>{{description}}</description>n"
				+ "<keepDependencies>false</keepDependencies>\r\n" + "<properties/>\r\n"
				+ "<scm class=\"hudson.scm.NullSCM\"/>\r\n" + "<canRoam>true</canRoam>\r\n"
				+ "<disabled>false</disabled>\r\n"
				+ "<blockBuildWhenDownstreamBuilding>false</blockBuildWhenDownstreamBuilding>\r\n"
				+ "<blockBuildWhenUpstreamBuilding>false</blockBuildWhenUpstreamBuilding>\r\n"
				+ "<concurrentBuild>false</concurrentBuild>\r\n"
				+ "<customWorkspace>{{customWorkspace}}</customWorkspace>\r\n" + "<builders>\r\n"
				+ "<hudson.tasks.BatchFile>\r\n" + "<command>{{command}}</command>\r\n" + "<configuredLocalRules/>\r\n"
				+ "</hudson.tasks.BatchFile>\r\n" + "</builders>\r\n" + "<publishers/>\r\n" + "<buildWrappers/>\r\n"
				+ "\r\n" + "</project>";

		return configXML;
	}

	public boolean deleteJenkinsJob(String txtId, AssetAccount assetAccount, String id) {
		System.out.println("j server2");
		boolean isdeleteJob = false;

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		try {

			JenkinsServer jenkinsServer2 = new JenkinsServer(new URI(jenkinsServer2Url), jenkinsServer2Username,
					jenkinsServer2Password);

			// our XML file for this example
			// JobWithDetails jobWithDetails = jenkinsServer1.getJob(id);
			JobWithDetails jobWithDetailsOfJenkinsServer2 = jenkinsServer2.getJob(id);

			if (jobWithDetailsOfJenkinsServer2 != null) {
				jenkinsServer2.deleteJob(id, true);
				isdeleteJob = true;
				SystemLogs systemLogs = new SystemLogs("delete Jenkins Job in jenkins server2",
						id + " Job id successfully Deleted", ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_JENKINS,
						SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_JK, user.getEmail(), SystemLogs.USER,
						assetAccount.getAccountNumber(), assetAccount.getVendorId(), assetAccount.getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());
				systemLogsRepository.save(systemLogs);
			} else {
				SystemLogs systemLogs = new SystemLogs("delete Jenkins Job in jenkins server2",
						id + " Job id Does not exist please create again", ZonedDateTime.now(), txtId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
						assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
						user.getName());

				systemLogsRepository.save(systemLogs);
				isdeleteJob = false;
			}

			jenkinsServer2.close();
		} catch (Exception e) {
			e.printStackTrace();
			SystemLogs systemLogs = new SystemLogs("delete Jenkins Job", e.getLocalizedMessage(), ZonedDateTime.now(),
					txtId, SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK,
					user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
					assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					user.getName());
			systemLogsRepository.save(systemLogs);
			isdeleteJob = false;
		}

		return isdeleteJob;
	}

	

	public String getConsole(String jobId) throws URISyntaxException, IOException {
		JenkinsServer jenkins = new JenkinsServer(new URI(jenkinsServer2Url), jenkinsServer2Username,
				jenkinsServer2Password);
		String jsonResponse = "";
		JobWithDetails jobWithDetails = jenkins.getJob(jobId);
		if (jobWithDetails != null) {
			Build build = jobWithDetails.getLastBuild();
			if (build != null) {
				jsonResponse = build.details().getConsoleOutputText();
				return jsonResponse;
			}

		}
		return jsonResponse;
	}

	public void deleteAllJobsInJenkinsServer() {
		try {
			JenkinsServer jenkinsServer2 = new JenkinsServer(new URI(jenkinsServer2Url), jenkinsServer2Username,
					jenkinsServer2Password);
			Map<String, Job> getJobsFromJenkinsServer2 = jenkinsServer2.getJobs();
			for (Map.Entry<String, Job> entry : getJobsFromJenkinsServer2.entrySet()) {
				jenkinsServer2.deleteJob(entry.getKey(), true);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	 public boolean publishBot(Robot robot, String txtId, String jobName,String fileName,String userName,
			   String userEmail)
		{
			String command = "npx playwright test " + fileName+" --headed";
			boolean isCreateUpdateJob = false;
			try {
				JenkinsServer jenkinsServer = new JenkinsServer(new URI(jenkinsServer2Url), jenkinsServer2Username,
						jenkinsServer2Password);

				// our XML file for this example
				JobWithDetails jobWithDetailsOfJenkinsServer = jenkinsServer.getJob(jobName);

				getXmLOfJenkinsServer2();
				
				// our XML file for this example
			
				String filePath=sftpeqactualpath;
				String jobXml = getXmLOfJenkinsServer2();
				jobXml = jobXml.replace("{{customWorkspace}}", filePath);
				jobXml = jobXml.replace("{{command}}", command);
				jobXml = jobXml.replace("{{description}}","");
				jobXml = jobXml.replace("{{timeslot}}", "");
				 
				System.out.println("jobXml " + jobXml);

				if (jobWithDetailsOfJenkinsServer != null) {
					jenkinsServer.updateJob(jobName, jobXml, true);
					isCreateUpdateJob = true;

					SystemLogs systemLogs = new SystemLogs("Update Job in Jenkins server 1",
							jobName + " job is successfully updated", ZonedDateTime.now(), txtId,
							SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_JK,
							userEmail, SystemLogs.USER, robot.getAccountNo(), robot.getVendorId(),
							robot.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
							userName);
					systemLogsRepository.save(systemLogs);
				} else {
					jenkinsServer.createJob(jobName, jobXml, true);
					isCreateUpdateJob = true;

					SystemLogs systemLogs = new SystemLogs("create Job in Jenkins server 1",
							jobName + " job is successfully created", ZonedDateTime.now(), txtId,
							SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_JK,
							userEmail, SystemLogs.USER, robot.getAccountNo(), robot.getVendorId(),
							robot.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
							userName);
					systemLogsRepository.save(systemLogs);
				}

				jenkinsServer.close();

				return isCreateUpdateJob;
			} catch (Exception e) {
				e.printStackTrace();
				isCreateUpdateJob = false;

				SystemLogs systemLogs = new SystemLogs("create or Update Job", e.getMessage(), ZonedDateTime.now(), txtId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK,
						userEmail, SystemLogs.USER, robot.getAccountNo(), robot.getVendorId(),
						robot.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
						userName);
				systemLogsRepository.save(systemLogs);
				return isCreateUpdateJob;
			}

		}
}
