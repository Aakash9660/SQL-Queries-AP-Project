package com.smartdocs.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.Robot;
import com.smartdocs.model.VendorScript;
import com.smartdocs.model.VendorScriptLog;
import com.smartdocs.model.dto.VendorScriptDto;
import com.smartdocs.model.log.ApplicationLog;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.ApplicationLogRepository;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.repository.RobotRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.VendorScriptLogRepository;
import com.smartdocs.repository.VendorScriptRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.Constants;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.service.util.HttpReqRespUtils;
import com.smartdocs.service.util.JKUtil;

@Service
public class VendorScriptService {

	@Autowired
	private VendorScriptRepository vendorScriptRepository;

	@Autowired
	private ApplicationLogRepository applicationLogRepository;

	@Autowired
	private RobotRepository robotRepository;

	@Autowired
	private AssetAccountRepository assetAccountRepository;

	@Autowired
	private JenkinsService1 jenkinsService1;

	@Autowired
	private JenkinsService2 jenkinsService2;

	@Autowired
	private SystemLogsRepository systemLogsRepository;

	@Autowired
	private VendorScriptLogRepository vendorScriptLogRepository;

	final static Logger logger = LoggerFactory.getLogger(VendorScriptService.class);

	public VendorScript createVendorScript(UserPrincipal logedInUser, VendorScript vscript) {

		VendorScript script = vendorScriptRepository.findByVendorId(vscript.getVendorId());
		if (script == null) {
			script = new VendorScript();
			script.setId(Long.valueOf(vscript.getVendorId()));
		}
		updateVersion(script);
		script.setVendorId(vscript.getVendorId());
		script.setUpdatedBy(logedInUser.getEmail());
		script.setCodeScript(vscript.getCodeScript());
		script.setScriptType(vscript.getScriptType());
		script.setLastUpdated(ZonedDateTime.now());
		script.setFileName(vscript.getFileName());
		script.setSync(false);

		applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
				Constants.ACTIVITY_TYPE_CREATE_VENDOR_SCRIPT, logedInUser.getEmail(), logedInUser.getName(), null, null,
				logedInUser.getName() + " Vendor Script created successfully", "Vendor Script created successfully",
				"VendorScriptRestAPIs:createVendorScript()", "/vendorScript", logedInUser.getRole()));

		vendorScriptLogRepository
				.save(new VendorScriptLog("comment", "CREATE", vscript.getVendorId(), vscript.getVersion(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), logedInUser.getUsername()));
		return vendorScriptRepository.save(script);
	}

	public JsonResponse uploadVendorFile(UserPrincipal logedInUser, String vendorId, MultipartFile file) {
		// if
		String content = "";
		try {
			logger.info("uploadVendorFile");
			content = new String(file.getBytes(), StandardCharsets.UTF_8);

			VendorScript script = vendorScriptRepository.findByVendorId(vendorId);
			if (script == null) {
				script = new VendorScript();

				script.setId(Long.parseLong(vendorId));

			}
			updateVersion(script);
			script.setUpdatedBy(logedInUser.getEmail());
			script.setCodeScript(content);
			script.setVendorId(vendorId);
			script.setScriptType(file.getContentType());
			script.setLastUpdated(ZonedDateTime.now());
			script.setFileName(file.getOriginalFilename());
			script.setSync(false);

			System.out.println("Content :" + content);
			vendorScriptLogRepository.save(new VendorScriptLog("", "UPLOAD", script.getVendorId(), script.getVersion(),
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), logedInUser.getUsername()));
			vendorScriptRepository.save(script);
			logger.info("upload Vendor File");

			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_UPLOAD_VENDOR_SCRIPT, logedInUser.getEmail(), logedInUser.getName(), null,
					null, logedInUser.getName() + " VendorScript Seccessfully updated", "",
					"VendorScriptRestAPIs:uploadVendorFile()", "/vendorScript/upload/{vendorId}",
					logedInUser.getRole()));

			return new JsonResponse("Success", JsonResponse.RESULT_SUCCESS, "VendorScript Seccessfully updated",
					JsonResponse.STATUS_200);
		} catch (IOException e) {
			e.printStackTrace();

			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_UPLOAD_VENDOR_SCRIPT, logedInUser.getEmail(), logedInUser.getName(), null,
					null, logedInUser.getName() + " VendorScript does not exist with " + vendorId, content,
					"VendorScriptRestAPIs:uploadVendorFile()", "/vendorScript/upload/{vendorId}",
					logedInUser.getRole()));

			return new JsonResponse(JsonResponse.RESULT_FAILED, "VendorScript does not exist with " + vendorId,
					JsonResponse.STATUS_500);
		}

	}

	private void updateVersion(VendorScript script) {
		try {
			if (script.getVersion() == 0) {
				script.setVersion(1);
			} else {
				script.setVersion(script.getVersion() + 1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public VendorScript getVendorScript(String vendorId) {

		return this.vendorScriptRepository.findByVendorId(vendorId);
	}

	public Map<String, Object> checkVendorSriptVersion(String vendorId, int version) {
		JSONObject jsonObject = new JSONObject();
		boolean existVendorId = vendorScriptRepository.existVendorId(vendorId);
		if (existVendorId) {
			boolean checkVersion = vendorScriptRepository.checkVersion(vendorId, version);
			if (checkVersion) {
				jsonObject.put("isUpgradation", true);
				jsonObject.put("message", "Vendor is present and version upgradation required");
				return jsonObject.toMap();
			} else {
				jsonObject.put("isUpgradation", false);
				jsonObject.put("message", "Vendor is present and version upgradation not required");
				return jsonObject.toMap();
			}
		} else {
			jsonObject.put("isUpgradation", false);
			jsonObject.put("message", "Vendor is not present");
			return jsonObject.toMap();
		}

	}

	@Transactional
	public JsonResponse deleteVendorScript(long id) {
		Optional<VendorScript> vendorScript = this.vendorScriptRepository.findById(id);

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());
		if (vendorScript.isPresent()) {
			vendorScriptRepository.deleteById(id);
			vendorScriptLogRepository.save(
					new VendorScriptLog("", "DELETE", vendorScript.get().getVendorId(), vendorScript.get().getVersion(),
							HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getUsername()));

			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_DELETE_VENDOR_SCRIPT, user.getEmail(), user.getName(), null, null,
					user.getName() + " Deleted successfully with id " + id, "",
					"VendorScriptRestAPIs:deleteVendorScript()", "/vendorScript/{vendorId}", user.getRole()));
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Deleted sucessfully", JsonResponse.STATUS_200);
		} else {
			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_DELETE_VENDOR_SCRIPT, user.getEmail(), user.getName(), null, null,
					user.getName() + "No Vendor Script found with id " + id, "",
					"VendorScriptRestAPIs:deleteVendorScript()", "/vendorScript/{vendorId}", user.getRole()));
			return new JsonResponse(JsonResponse.RESULT_FAILED, "No Vendor Script found with id " + id,
					JsonResponse.STATUS_500);
		}
	}

	public JsonResponse updateVendorScript(VendorScriptDto vendorScriptDto, Long id) {

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		VendorScript vendorScript = new VendorScript();
		BeanUtils.copyProperties(vendorScriptDto, vendorScript);
		Optional<VendorScript> existVendorScript = this.vendorScriptRepository.findById(id);
		if (existVendorScript.isPresent()) {
			vendorScript.setId(existVendorScript.get().getId());
			updateVersion(vendorScript);
			vendorScriptRepository.save(vendorScript);
			vendorScriptLogRepository.save(new VendorScriptLog("", "UPDATE", existVendorScript.get().getVendorId(),
					existVendorScript.get().getVersion(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					user.getUsername()));
			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_UPDATE_VENDOR_SCRIPT, user.getEmail(), user.getName(), null, null,
					user.getName() + " Update successfully with " + id, "", "VendorScriptRestAPIs:updateVendorScript()",
					"/vendorScript/{id}", user.getRole()));

			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Update successfully with " + id,
					JsonResponse.STATUS_200);
		}
		applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
				Constants.ACTIVITY_TYPE_UPDATE_VENDOR_SCRIPT, user.getEmail(), user.getName(), null, null,
				user.getName() + "VendorScript does not exist with " + id, vendorScript.getCodeScript(),
				"VendorScriptRestAPIs:updateVendorScript()", "/vendorScript/{id}", user.getRole()));

		return new JsonResponse(JsonResponse.RESULT_FAILED, "VendorScript does not exist with " + id,
				JsonResponse.STATUS_404);

	}

	public JsonResponse rePublishVendoScriptOnAllServers(String vendorId) {
		VendorScript vendorScript = vendorScriptRepository.findByVendorId(vendorId);

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		String txId = UUID.randomUUID().toString();
		if (vendorScript != null) {
			List<Robot> robots = robotRepository.findByVendorId(vendorId);
			if (robots != null) {
				for (Robot robot : robots) {
					AssetAccount assetAccount = assetAccountRepository.findOneByAssetCodeAndAccountNumberAndVendorId(
							robot.getAssetCode(), robot.getAccountNo(), robot.getVendorId());
					if (assetAccount != null) {
						String id = assetAccount.getAssetCode() + "-" + assetAccount.getVendorId() + "-"
								+ assetAccount.getAccountNumber();
						String fileName = JKUtil.getScriptFileName(assetAccount);

						jenkinsService1.createFileToFTP(txId, assetAccount, fileName, id, vendorScript);
						jenkinsService2.createFileToFTP(txId, assetAccount, fileName, id, vendorScript);

						robot.setScriptVersion(vendorScript.getVersion());
						robotRepository.save(robot);
					} else {
						SystemLogs systemLogs = new SystemLogs(
								"Publish VendoScript On All Servers for vendorId" + vendorId,
								"Asset Code " + robot.getAssetCode() + ";" + "Account No " + robot.getAccountNo() + ";"
										+ "VendorId " + robot.getVendorId() + "; Asset account not found ",
								ZonedDateTime.now(), txId, SystemLogs.SYSTEM_TYPE_AUTOPILOT,
								SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_AP, user.getEmail(), SystemLogs.USER,
								robot.getAccountNo(), robot.getVendorId(), robot.getAssetCode(),
								HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());
						systemLogsRepository.save(systemLogs);
					}

				}
			}
			vendorScriptLogRepository.save(new VendorScriptLog("", "UPDATE SCRIPT ON ALL SERVERS",
					vendorScript.getVendorId(), vendorScript.getVersion(),
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getUsername()));
		}
		return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Success ", JsonResponse.STATUS_200);
	}

	public Page<VendorScriptLog> vendorscriptlogs(String orderBy, int page, int limit, String vendorId) {
		Pageable pageable = GeneralUtil.getSortPageRequest(orderBy, page, limit);
		if (StringUtils.isBlank(vendorId)) {
			return vendorScriptLogRepository.findAll(pageable);
		} else {
			return vendorScriptLogRepository.findByVendorId(vendorId, pageable);
		}
	}
}