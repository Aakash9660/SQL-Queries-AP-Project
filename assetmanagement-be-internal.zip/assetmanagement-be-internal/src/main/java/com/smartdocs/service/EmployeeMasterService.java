package com.smartdocs.service;

import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.model.EmployeeMaster;
import com.smartdocs.repository.EmployeeMasterRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class EmployeeMasterService {

	@Autowired
	private EmployeeMasterRepository employeeMasterRepository;

	public List<EmployeeMaster> getEmployee(String name) {
		if (name != null ) {
			return employeeMasterRepository.findByName(name, name);
		}else {
			return Collections.emptyList();
		}
	}

	public Page<EmployeeMaster> getEmployeeMasterPages(String email, String firstName, String lastName, int pageIndex,
			int size, String orderBy) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		if (StringUtils.isBlank(email)) {
			email = null;
		} else {
			email=email.trim();
		}
		if (StringUtils.isBlank(firstName)) {
			firstName = null;
		} else {
			firstName.trim();
		}
		if (StringUtils.isBlank(lastName)) {
			lastName = null;
		} else {
			lastName.trim();
		}
		return this.employeeMasterRepository.findAllEmployeeMaster(email, firstName, lastName, page);
	}
}
