package com.smartdocs.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.Manager;
import com.smartdocs.model.SmartStoreConfigurator;
import com.smartdocs.model.log.ApplicationLog;
import com.smartdocs.repository.ApplicationLogRepository;
import com.smartdocs.repository.ManagerRepository;
import com.smartdocs.repository.SmartStoreConfiguratorRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.Constants;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.service.util.HttpReqRespUtils;

@Service
public class AdminService {

	@Autowired
	private SmartStoreConfiguratorRepository smartStoreConfiguratorRepository;

	@Autowired
	private ManagerRepository managerRepository;

	@Autowired
	private ApplicationLogRepository applicationLogRepository;

	public List<SmartStoreConfigurator> getSmartStoreConfig() {
		return smartStoreConfiguratorRepository.findAll();
	}

	public JsonResponse createManager(Manager manager) {
		return new JsonResponse(managerRepository.save(manager), JsonResponse.RESULT_SUCCESS, "Save successfully",
				JsonResponse.STATUS_200);
	}

	public Page<Manager> getPage(int pageIndex, int size, String orderBy, String name, String email) {
		if (StringUtils.isBlank(email)) {
			email = null;
		} else {
			email = email.trim();
		}
		if (StringUtils.isBlank(name)) {
			name = null;
		} else {
			name = name.trim();
		}
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		return managerRepository.findManagers(name, email, page);
	}

	public JsonResponse updateManager(Long id, Manager manager) {
		Optional<Manager> existManager = managerRepository.findById(id);
		if (existManager.isPresent()) {
			BeanUtils.copyProperties(manager, existManager.get());
			existManager.get().setId(id);
			managerRepository.save(existManager.get());
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Update Sucessfully", JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Not Updated", JsonResponse.STATUS_500);
		}
	}

	public JsonResponse deleteManager(Long id) {
		Optional<Manager> existManager = managerRepository.findById(id);
		if (existManager.isPresent()) {
			managerRepository.deleteById(id);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "delete Sucessfully", JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Not deleted", JsonResponse.STATUS_500);
		}
	}

	public List<Manager> getListOfManager() {
		return managerRepository.findAll();
	}

	public long totalManager() {
		return this.managerRepository.count();
	}

	public List<Manager> getAssetIdByAssetCode(String assetCode) {
		List<Manager> findManagersByAssetCode = managerRepository.findManagersByAssetCode(assetCode);
		return findManagersByAssetCode;
	}

	@Transactional
	public JsonResponse actionOnAssetManagers(UserPrincipal logedInUser, int managerId, boolean action) {
		if (action) {
			managerRepository.fn_set_asset_manager(managerId, action); // set manager for all assets
			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_MANAGER_UPDATION, logedInUser.getEmail(), logedInUser.getName(), null, null,
					logedInUser.getName() + "Manager for all asset update successfully",
					"manager for all asset update successfully", "ManagerRestAPIs:actionOnAssetManagers()",
					"/common/manager", logedInUser.getRole()));
		} else {
			managerRepository.fn_set_asset_manager(managerId, action); // remove manager from all assets
			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_MANAGER_DELETION, logedInUser.getEmail(), logedInUser.getName(), null, null,
					logedInUser.getName() + "Manager for all asset delete successfully",
					"manager for all asset delete successfully", "ManagerRestAPIs:actionOnAssetManagers()",
					"/common/manager", logedInUser.getRole()));
		}
		return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Action perform sucessfully.", JsonResponse.STATUS_200);
	}

}
