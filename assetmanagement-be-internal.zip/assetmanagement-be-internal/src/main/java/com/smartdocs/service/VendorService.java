package com.smartdocs.service;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartdocs.dto.AssetAccountCustomDto;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.UtilVendorDto;
import com.smartdocs.dto.VendorAssets;
import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.VendorClassifications;
import com.smartdocs.model.dto.VendorAssetsDto;
import com.smartdocs.model.dto.VendorDto;
import com.smartdocs.repository.AssetRepository;
import com.smartdocs.repository.VendorClassificationsRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.sql.dto.VendorInf;

@Service
public class VendorService {

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private VendorClassificationsRepository vendorClassificationsRepository;

	@Autowired
	private AssetRepository assetRepository;


	@Deprecated
	public Vendor createVendor(VendorDto vendorDto) {
		Vendor vendor = new Vendor();
		BeanUtils.copyProperties(vendorDto, vendor);
		return this.vendorRepository.save(vendor);
	}

	public JsonResponse updateVendor(VendorDto vendorDto, String vendorId) {
		Optional<Vendor> existVendor = this.vendorRepository.findOneByVendorId(vendorId);
		if (existVendor.isPresent()) {
			Vendor vendor = existVendor.get();
			Long id = vendor.getId();
			BeanUtils.copyProperties(vendorDto, vendor);
			vendor.setId(id);
			vendor.setUtilityVendor(true);
			vendor.setLastUpdated(ZonedDateTime.now());
			this.vendorRepository.save(vendor);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Updated successfully", JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Vendor does not exist with " + vendorId,
				JsonResponse.STATUS_404);
	}

	public Vendor getVendorByVendorId(String vendorId) {
		return vendorRepository.findOneByVendorId(vendorId).orElseThrow(null);
	}

	public Vendor getVendorById(Long id) {
		return this.vendorRepository.findById(id).orElseThrow(null);
	}

	public JsonResponse getVendorName(String vendorId) {
		return new JsonResponse(vendorRepository.getNameByVendorId(vendorId), JsonResponse.RESULT_SUCCESS, "",
				JsonResponse.STATUS_200);
	}

	public Page<VendorInf> getVendorsPage(Boolean manualIntervention,String query, String utilityType, String orderBy, int pageIndex, int size) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		if (StringUtils.isBlank(utilityType)) {
			utilityType = null;
		} else {
			utilityType = utilityType.trim();
		}
		return vendorRepository.findAllVendors(manualIntervention,query, utilityType, page);
	}

	public UtilVendorDto getCountOfUtilies() {
		UtilVendorDto utilVendorDto = new UtilVendorDto();
		utilVendorDto.setTotalUtilityVendors(vendorRepository.countVendors(true));
		utilVendorDto.setMapList(vendorRepository.getDistinctCountClassifications());
		return utilVendorDto;
	}

	public Page<VendorAssetsDto> findAllVendorAssets(String vendorId, String orderBy, String accountNo, int pageIndex,
			int size) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		if (StringUtils.isBlank(accountNo)) {
			accountNo = null;
		} else {
			accountNo = accountNo.trim();
		}
		Page<VendorAssets> pages = vendorRepository.findAllVendorAssets(vendorId, accountNo, true, page);
		boolean isNotEmpty = false;
		for (VendorAssets vendorAssets : pages) {
			if (vendorAssets.getAsset() != null && vendorAssets.getCostCenter() != null
					&& vendorAssets.getAssetAccount() != null && vendorAssets.getGlAccount() != null) {
				isNotEmpty = true;
			}
		}
		if (isNotEmpty) {
			return pages.map(this::mapVendorAccountsToAccountsDto);
		} else {
			return Page.empty();
		}
	}

	public Page<VendorDto> getVendors(String utilityType, String query, String orderBy, int pageIndex, int size) {
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		if (StringUtils.isBlank(utilityType)) {
			utilityType = null;
		} else {
			utilityType = utilityType.trim();
		}
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		return vendorRepository.findVendors(utilityType, query, page).map(this::setData);
	}

	private VendorDto setData(Vendor vendor) {
		VendorDto vendorDto = new VendorDto();
		BeanUtils.copyProperties(vendor, vendorDto);
		List<AssetAccount> linkAccount = vendorRepository.getLinkAccount(vendor.getVendorId());
		if (linkAccount != null) {
			vendorDto.setTotalAccounts(linkAccount.size());
		}
		return vendorDto;
	}
	
	public List<AssetAccountCustomDto> getAccounts(String vendorId) {
		return vendorRepository.getLinkAccount(vendorId).stream().map(this::setDataInAccountDto)
				.collect(Collectors.toList());
	}

	private AssetAccountCustomDto setDataInAccountDto(AssetAccount assetAccount) {
		AssetAccountCustomDto customDto = new AssetAccountCustomDto();
		customDto.setAssetAccount(assetAccount);
		Optional<Asset> existAsset = assetRepository.findOneByAssetCode(assetAccount.getAssetCode());
		if (existAsset.isPresent()) {
			customDto.setAddress(existAsset.get().getAddress());
			customDto.setAssetname(existAsset.get().getName());
			customDto.setAssetId(existAsset.get().getId());
		}
		return customDto;
	}

	public VendorAssetsDto mapVendorAccountsToAccountsDto(VendorAssets vendorAsset) {
		VendorAssetsDto vendorAssetsDto = new VendorAssetsDto();
		if (vendorAsset != null) {
			if (vendorAsset.getAsset() != null) {
				vendorAssetsDto.setAssetCode(vendorAsset.getAsset().getAssetCode());
				vendorAssetsDto.setAssetName(vendorAsset.getAsset().getName());
				vendorAssetsDto.setAssetAddress(vendorAsset.getAsset().getAddress());
			}
			if (vendorAsset.getAssetAccount() != null) {
				vendorAssetsDto.setAccountNo(vendorAsset.getAssetAccount().getAccountNumber());
				vendorAssetsDto.setChannel(vendorAsset.getAssetAccount().getChannel());
				vendorAssetsDto.setFrequency(vendorAsset.getAssetAccount().getFrequency());
			}
			if (vendorAsset.getCostCenter() != null) {
				vendorAssetsDto.setCostCenter(vendorAsset.getCostCenter().getCode());
				vendorAssetsDto.setCostCenterDesc(vendorAsset.getCostCenter().getDescription());
			}
			if (vendorAsset.getGlAccount() != null) {
				vendorAssetsDto.setGlAccount(vendorAsset.getGlAccount().getCode());
				vendorAssetsDto.setGlAccountDesc(vendorAsset.getGlAccount().getDescription());
			}
			return vendorAssetsDto;
		}
		return vendorAssetsDto;
	}

	public Set<String> getDistinctVedorClassifications() {
		return vendorRepository.getVedorClassifications();
	}

	public List<Map<String, Integer>> findVendorNameByVendorIdOrName(String query) {
		return vendorRepository.findVendorNameByVendorIdOrName(query);
	}

	// ---------------vendor classifications CRUD // -----------------//

	public JsonResponse createVendorClassifications(VendorClassifications classifications) {
		if (classifications != null && classifications.getName() != "" && classifications.getName() != null) {
			Optional<VendorClassifications> existassetType = vendorClassificationsRepository
					.findByNameIgnoreCase(classifications.getName());
			if (existassetType.isPresent()) {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Classification is already created",
						JsonResponse.STATUS_400);
			}
			return new JsonResponse(vendorClassificationsRepository.save(classifications), JsonResponse.RESULT_SUCCESS,
					"New Classification created", JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED,
					"Vendor classifications or Vendorclassifications name is empty", JsonResponse.STATUS_400);
		}
	}

	public JsonResponse getVendorClassifications(String name) {
		Optional<VendorClassifications> existvenclass = vendorClassificationsRepository.findByNameIgnoreCase(name);
		if (existvenclass.isPresent()) {
			return new JsonResponse(existvenclass.get(), JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't get VendorClassifications from " + name,
					JsonResponse.STATUS_404);
		}
	}

	public Set<String> getListOfVendorClassifications() {
		return vendorRepository.getDistinctClassifications();
	}
	
	public long getTotalVendors() {
		return vendorRepository.count();
	}
	
	public long getTotalManualIntervationsVendors() {
		return vendorRepository.countByManualIntervention(true);
	}

	public long getTotalVendorsHaveBots() {
		return vendorRepository.countVendorsHaveBots();
	}
	
	public Page<VendorClassifications> getVendorClassificationsPage(String query, String orderBy, int pageIndex,
			int size) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		try {
			return vendorClassificationsRepository.getPage(query, page);
		} catch (Exception e) {
			page = PageRequest.of(pageIndex, size);
			return vendorClassificationsRepository.getPage(query, page);
		}
	}

	@Transactional
	public JsonResponse deleteVendorClassifications(String name) {
		Optional<VendorClassifications> existvenclass = vendorClassificationsRepository.findByNameIgnoreCase(name);
		if (existvenclass.isPresent()) {
			vendorClassificationsRepository.deleteByNameIgnoreCase(name);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Sucessfully deleted " + name,
					JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't delete VendorClassifications from " + name,
					JsonResponse.STATUS_404);
		}
	}

	public JsonResponse updateVendorClassifications(VendorClassifications vendorClassifications) {
		if (vendorClassifications != null && vendorClassifications.getName() != ""
				&& vendorClassifications.getName() != null) {
			Optional<VendorClassifications> existvenclass = vendorClassificationsRepository
					.findByNameIgnoreCase(vendorClassifications.getName());
			if (existvenclass.isPresent()) {
				existvenclass.get().setName(existvenclass.get().getName());
				existvenclass.get().setDescription(vendorClassifications.getDescription());
				return new JsonResponse(vendorClassificationsRepository.save(existvenclass.get()),
						JsonResponse.RESULT_SUCCESS, "Update sucessfully", JsonResponse.STATUS_200);
			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Vendor Classifications name can't update ",
						JsonResponse.STATUS_404);
			}
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED,
					"Vendor Classifications  or Vendor Classifications name is null or empty", JsonResponse.STATUS_404);
		}
	}

	public Page<VendorDto> getVendors1(String utilityType, String query, String orderBy, int pageIndex, int size) {
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		if (StringUtils.isBlank(utilityType)) {
			utilityType = null;
		} else {
			utilityType = utilityType.trim();
		}
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		return vendorRepository.findVendors(utilityType, query, page).map(this::setData);
	}

	@Transactional
	public JsonResponse setManualIntervention(List<String> vendorIds,Boolean manualIntervention,UserPrincipal logedInUser) {
		if(manualIntervention==null) {
			manualIntervention=false;
		}
		vendorRepository.setManualIntervention(vendorIds, manualIntervention,logedInUser.getName());
		return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Action perform successfully", JsonResponse.STATUS_200);
	}

}
