package com.smartdocs.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.AssetGeoData;


@Service
public class GeoMapService {

	@Autowired
	private AssetService assetService;

	public List<AssetGeoData> providers(double reqlat, double reqlong, double specifiedDistance) {
		List<AssetGeoData> geoAssetList = assetService.getGeoAssetList();
		List<AssetGeoData> geoAssetRespponse = new ArrayList<>();
		for (AssetGeoData geoData : geoAssetList) {
			if (isDistanceWithInRange(specifiedDistance, geoData, reqlat, reqlong)) {
				geoAssetRespponse.add(geoData);
			}
		}
		return geoAssetRespponse;
	}

	private boolean isDistanceWithInRange(double specifiedDistance, AssetGeoData assetGeoData, double reqlat1, double reqlat2) {
		double nearestDistance = distance(reqlat1, reqlat2, assetGeoData.getLatitude(), assetGeoData.getLongitude(),
				'K');
		if (nearestDistance < specifiedDistance) {
			return true;
		} else
			return false;
	}

	private double distance(double lat1, double lon1, double lat2, double lon2, char unit) {
		double theta = lon1 - lon2;
		double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2))
				+ Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
		dist = Math.acos(dist);
		dist = rad2deg(dist);
		dist = dist * 60 * 1.1515;
		if (unit == 'K') {
			dist = dist * 1.609344;
		} else if (unit == 'N') {
			dist = dist * 0.8684;
		}
		return (dist);
	}

	private double deg2rad(double deg) {
		return (deg * Math.PI / 180.0);
	}

	private double rad2deg(double rad) {
		return (rad * 180.0 / Math.PI);
	}
}
