package com.smartdocs.service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.support.CronExpression;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.SystemUtilityDto;
import com.smartdocs.model.JobConfigModel;
import com.smartdocs.model.TimeSlots;
import com.smartdocs.repository.RobotRepository;
import com.smartdocs.repository.TimeSlotsRepository;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.sql.dto.TimeSlotsCustom;
import com.smartdocs.sql.dto.TimeSlotsInf;

@Service
public class TimeSlotsService {

	@Autowired
	private TimeSlotsRepository timeSlotsRepository;

	@Autowired
	private JobConfigService jobConfiService;

	@Autowired
	private RobotRepository robotRepository;

	private String clientTz = "";

	public void setupTimeSlot() {
		timeSlotsRepository.deleteAllRecords();
		JobConfigModel jobConfig = jobConfiService.getJobConfig();
		if (jobConfig != null) {
			for (int i = 1; i <= 28; i++) {
				for (int j = 0; j < jobConfig.getWorkingHours(); j++) {
					for (int k = 0; k < 60;) {
						TimeSlots timeSlots = new TimeSlots();
						timeSlots.setId(Long.parseLong(getId(i, j, k)));
						timeSlots.setFromTime(getTime(j, k));
						timeSlots.setToTime(getTime(j, k = k + jobConfig.getBotExecutionTime()));
						timeSlots.setDay(i);
						timeSlotsRepository.save(timeSlots);
					}
				}
			}
		}
	}

	private String getId(int day, int hr, int fromTime) {
		String strhr = "";
		String reqTime = "";
		if (fromTime == 0) {
			if (hr < 10) {
				strhr = "0" + hr;
			} else {
				strhr = hr + "";
			}
			reqTime = strhr + fromTime + "0";
		} else if (fromTime == 5) {
			if (hr < 10) {
				strhr = "0" + hr;
			} else {
				strhr = hr + "";
			}
			reqTime = strhr + "0" + fromTime;
		} else {
			if (hr < 10) {
				strhr = "0" + hr;
			} else {
				strhr = hr + "";
			}
			reqTime = strhr + fromTime;
		}
		String id = day + reqTime;
		return id;
	}

	private String getTime(int hr, int reqTime) {
		String timestr = "";
		String strhr = "";
		if (reqTime == 0) {
			if (hr < 10) {
				strhr = "0" + hr;
			} else {
				strhr = hr + "";
			}
			timestr = strhr + "_" + reqTime + "0";
		} else if (reqTime < 9) {
			if (hr < 10) {
				strhr = "0" + hr;
			} else {
				strhr = hr + "";
			}
			timestr = strhr + "_" + "0" + reqTime;
		} else {
			if (hr < 10) {
				strhr = "0" + hr;
			} else {
				strhr = hr + "";
			}
			timestr = strhr + "_" + reqTime;
		}
		return timestr;
	}

	public void getBookSlots(String startTime, int freq, int day, String jobId) {
		String dayPatterm = getDayPatterm(freq, day);
		String[] split = dayPatterm.split(",");
		for (String i : split) {
			String id = (i + startTime).replace("_", "");
			Optional<TimeSlots> existtimeSlots = timeSlotsRepository.findById(Long.parseLong(id));
			if (existtimeSlots.isPresent()) {
				existtimeSlots.get().setAllocated(true);
				existtimeSlots.get().setJobId(jobId);
				timeSlotsRepository.save(existtimeSlots.get());
			}
		}
	}

	public String getDayPatterm(int f, int day) {
		int a = 0;
		if (f == 2) {
			a = 14;
		}
		if (f == 3) {
			a = 10;
		}
		if (f == 4) {
			a = 7;
		}
		String resp = null;
		for (int i = 1; i <= f; i++) {
			if (resp == null) {
				resp = String.valueOf((a * i - a) + day);
			} else {
				resp = resp + "," + ((a * i - a) + day);
			}
		}
		return resp;
	}

	@Transactional
	public String creatTimeSlotsBySQLFunction() {
		return timeSlotsRepository.fn_create_timeslots();
	}

	public SystemUtilityDto getCountTimeslotsAndScheduledBots() {
		SystemUtilityDto dto = new SystemUtilityDto();
		dto.setTotalTimeSlots(timeSlotsRepository.count());
		dto.setTotalBookedTimeSlots(timeSlotsRepository.countByAllocated(true));
		dto.setTotalScheduleBots(robotRepository.countBySchedule(true));
		return dto;
	}

	public List<TimeSlotsCustom> intervalTimeSlots(String tz, String dateTime) {
		clientTz = tz;
		String strhr = "";
		String strhr2 = "";
		int day = 0;
		int hour=0;
		int hour2=0;
		if (clientTz != null && dateTime !=null&& StringUtils.isNotEmpty(dateTime)) {
			ZonedDateTime dt = GeneralUtil.getFromDate(dateTime, tz);
			day =dt.getDayOfMonth();
			hour=dt.getHour();
		}else {
			ZonedDateTime now = ZonedDateTime.now();
			 hour = now.getHour();
			 day = now.getDayOfMonth();
		}	
		hour2=hour+1;
		if (hour < 10) {
			strhr = "0" + hour + "_";
		} else {
			strhr = hour + "_";
		}
		
		if (hour2 < 10) {
			strhr2 = "0" + hour2 + "_";
		} else {
			strhr2 = hour2 + "_";
		}
		
		return timeSlotsRepository.findByHourAndDay(strhr,strhr2, day).stream().map(this::setCustomData)
				.collect(Collectors.toList());
	}

	private TimeSlotsCustom setCustomData(TimeSlotsInf inf) {
		TimeSlotsCustom custom = new TimeSlotsCustom(inf);
		if (custom.getJenkinsCommand() != null) {
			custom.setNextExecution(getnextExecution(custom.getJenkinsCommand()));
		}
		return custom;
	}

	private ZonedDateTime getnextExecution(String pattern) {
		try {
			pattern = "* " + pattern;
			CronExpression cronTrigger = CronExpression.parse(pattern);
			LocalDateTime next = cronTrigger.next(LocalDateTime.now());
			if (!StringUtils.isEmpty(clientTz)) {
				return ZonedDateTime.of(next, ZoneId.of(clientTz));
			}
			return ZonedDateTime.of(next, ZonedDateTime.now().getZone());
		} catch (Exception e) {
			return null;
		}
	}

}
