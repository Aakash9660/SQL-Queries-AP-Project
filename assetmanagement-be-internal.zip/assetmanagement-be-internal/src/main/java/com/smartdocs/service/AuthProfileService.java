package com.smartdocs.service;


import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartdocs.mongo.collectionhelpers.Permission;
import com.smartdocs.mongo.collections.PermissionGroup;
import com.smartdocs.mongo.collections.User;
import com.smartdocs.mongo.repository.AuthProfileRepository;



@Service
public class AuthProfileService {

	@Autowired
	private AuthProfileRepository authProfileRepository;
	
	private static final Logger logger = LoggerFactory.getLogger(AuthProfileService.class);
	 

	public Map<String,Permission> getAllPermissionGroups(User  user) {
		logger.info("AuthProfileService -> getAllPermissionGroups for user: {}", user.getEmail());
   	 	Map<String,Permission> pg=new HashedMap<>();
      	 if(user.getAuthPermissionGroups()!=null) {
      		List<PermissionGroup> allPrmission = authProfileRepository.findByGroupIdIn(user.getAuthPermissionGroups());
      		if(allPrmission!=null) {
        		 for(PermissionGroup permissionG:allPrmission) {
        			 if(permissionG.getPermissions()!=null) {
        				 for(Permission permission:permissionG.getPermissions()) {
            				 if(pg.get(permission.getName())==null) {
            					 pg.put(permission.getName(), permission);
            				 }
            				 else
            				 {
            					if(permission.isEnabled())  pg.get(permission.getName()).setEnabled(true);
            					if(permission.getView())   pg.get(permission.getName()).setView(true);
            					if(permission.getEdit())  pg.get(permission.getName()).setEdit(true);
            					 
            				 }
                		 }
        			 }
        			
        		 }
      		}
      	 }
         return pg;
    }
}
