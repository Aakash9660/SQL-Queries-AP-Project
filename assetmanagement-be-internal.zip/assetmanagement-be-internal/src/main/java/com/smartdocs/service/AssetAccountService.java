package com.smartdocs.service;

import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.AssetAccountExcelRow;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.Vault;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.group.AssetAccountProjection;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.repository.AssetRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.VaultRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.service.util.ExcelToJsonService;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.service.util.HttpReqRespUtils;
import com.smartdocs.sql.dto.AccountCustomInf;

@Service
public class AssetAccountService {

	@Autowired
	private AssetService assetService;

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	private AssetAccountRepository assetAccountRepository;

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private VaultRepository vaultRepository;

	@Autowired
	private ExcelToJsonService excelToJsonService;

	@Autowired
	private SystemLogsRepository systemLogsRepository;

	@Autowired
	private ExceptionLogService exceptionLogService;

	public List<String> getAssetAccountNo(String accountNo) {
		if (StringUtils.isNoneBlank(accountNo)) {
			return assetAccountRepository.findByAccountNo(accountNo);
		}
		return Collections.emptyList();
	}

	public Page<AssetAccountProjection> getAssetAccountDetails(String vendorId, String assetQuery, String accountNo,
			String order, int page, int limit) {
		Pageable pageable = GeneralUtil.getSortPageRequest(order, page, limit);
		if (StringUtils.isBlank(assetQuery)) {
			assetQuery = null;
		} else {
			assetQuery = assetQuery.trim();
		}
		if (StringUtils.isBlank(accountNo)) {
			accountNo = null;
		} else {
			accountNo = accountNo.trim();
		}
		return assetAccountRepository.findAssetAccountData(assetQuery, accountNo, vendorId, pageable);
	}

	public JsonResponse convertExceltoJson(InputStream inputStream) {
		try {
			List<AssetAccountExcelRow> assetRows = excelToJsonService.convertAssetAccountDataToJson(inputStream, 0);
			return new JsonResponse(assetRows, JsonResponse.RESULT_SUCCESS, "Excel data.", JsonResponse.STATUS_200);
		} catch (Exception ex) {
			System.out.println("Ex:" + ex.getMessage());
			// ex.printStackTrace();
			exceptionLogService.addLog(ex, "/assetAccount/upload-asset-account/jsonData", null, null);
			return new JsonResponse("", JsonResponse.RESULT_FAILED, "Ex:" + ex.getMessage(), JsonResponse.STATUS_500);
		}
	}

	public JsonResponse validateAllAssetAccountExcelRow(List<AssetAccountExcelRow> assetRows) {
		try {
			if (assetRows != null) {
				for (AssetAccountExcelRow row : assetRows) {
					createAssetAccount(row, true);
				}
			}
			return new JsonResponse(assetRows, JsonResponse.RESULT_SUCCESS, "Validate recodrs.",
					JsonResponse.STATUS_200);

		} catch (Exception ex) {
			System.out.println("Ex:" + ex.getMessage());
			ex.printStackTrace();
			return new JsonResponse("", JsonResponse.RESULT_FAILED, "Ex:" + ex.getMessage(), JsonResponse.STATUS_500);
		}
	}

	public JsonResponse saveAllAssetAccountExcelRow(List<AssetAccountExcelRow> assetRows) {
		try {
			if (assetRows != null) {
				for (AssetAccountExcelRow row : assetRows) {
					createAssetAccount(row, false);
					if (AssetAccountExcelRow.STATUS_ERROR.equalsIgnoreCase(row.getStatus())) {
						SystemLogs systemLogs = new SystemLogs("Asset Account Upload Failed", row.getMessage(),
								ZonedDateTime.now(), null, SystemLogs.SYSTEM_TYPE_AUTOPILOT,
								SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_AP, "", null, row.getAccountNo(),
								row.getVendorId(), row.getAssetCode(),
								HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), "");
						systemLogsRepository.save(systemLogs);
					}
				}
			}
			return new JsonResponse(assetRows, JsonResponse.RESULT_SUCCESS, "Save Asset Account data.",
					JsonResponse.STATUS_200);
		} catch (Exception ex) {
			System.out.println("Ex:" + ex.getMessage());
			ex.printStackTrace();
			return new JsonResponse("", JsonResponse.RESULT_FAILED, "Ex:" + ex.getMessage(), JsonResponse.STATUS_500);
		}
	}

	public AssetAccountExcelRow createAssetAccount(AssetAccountExcelRow row, boolean isValidate) {
		Optional<Asset> asset = assetRepository.findOneByAssetCode(row.getAssetCode());
		Optional<Vendor> vendor = vendorRepository.findOneByVendorId(row.getVendorId());

		if (asset.isPresent() && vendor.isPresent()) {
			Vault vault = vaultRepository.findOneByName(row.getVault());
			boolean isExist = false;
			if (asset.get().getAccounts() != null && asset.get().getAccounts().size() > 0) {
				for (AssetAccount account : asset.get().getAccounts()) {
					if (account.getAccountNumber().equalsIgnoreCase(row.getAccountNo())
							&& account.getVendorId().equalsIgnoreCase(row.getVendorId())) {
						isExist = true;
						break;
					}
				}
			}
			if (!isExist) {
				if (isValidate) {
					row.setStatus(AssetAccountExcelRow.STATUS_SUCCESS);
				} else {
					// if account is null then initialize.
					if (asset.get().getAccounts() == null) {
						asset.get().setAccounts(new ArrayList<>());
					}
					// Add Asset Account and save.
					AssetAccount account = new AssetAccount(row, vault == null ? null : vault.getId());
					asset.get().getAccounts().add(account);
					assetRepository.save(asset.get());

					int bot_status = assetService.createRobot(row.getAssetCode(), account);
					row.setMessage("Asset Account Successfully Created." + bot_status);
				}
				row.setStatus(AssetAccountExcelRow.STATUS_SUCCESS);
				if (vault == null && AssetAccount.CHANNEL_AUTOPILOT.equals(row.getChannel())) {
					row.setMessage("Invalid Vault");
					row.setStatus(AssetAccountExcelRow.STATUS_WARNING);
				}
			} else {
				row.setStatus(AssetAccountExcelRow.STATUS_WARNING);
				row.setMessage("Asset Account already present.");
			}

		} else {
			row.setStatus(AssetAccountExcelRow.STATUS_ERROR);
			if (!asset.isPresent()) {
				row.setMessage("Invalid Asset Code");
			} else if (!vendor.isPresent()) {
				row.setMessage("Invalid Vendor Id");
			}
		}
		return row;
	}

	public List<AccountCustomInf> getAccountDetails(String assetCode, String channel, String vendorQuery) {
		if (StringUtils.isBlank(channel)) {
			channel = null;
		} else {
			channel = channel.trim();
		}
		if (StringUtils.isBlank(vendorQuery)) {
			vendorQuery = null;
		} else {
			vendorQuery = vendorQuery.trim();
		}
		return assetAccountRepository.findDetailsByAssetCode(assetCode, channel, vendorQuery);
	}

	public long getTotalAssetAccounts() {
		return assetAccountRepository.count();
	}

}
