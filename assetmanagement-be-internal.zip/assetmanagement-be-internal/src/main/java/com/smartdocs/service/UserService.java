package com.smartdocs.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartdocs.mongo.collections.User;
import com.smartdocs.mongo.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public User getUserById(String id) {
		Optional<User> dbUser = userRepository.findById(id);
		if (dbUser.isPresent()) {
			return dbUser.get();
		}
		return null;
	}

	public void saveOrUpdate(User user) {
		userRepository.save(user);
	}

	public User getUserByEmail(String email) {
		if (email != null) {
			email = email.toLowerCase();
		}
		return userRepository.findOneByEmail(email);
	}

}
