package com.smartdocs.service;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.UtilitySubmitRequest;
import com.smartdocs.model.BufferDocument;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.BufferDocumentRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.HttpReqRespUtils;

@Service
public class DocumentProcessorService extends JsonResponse {

	@Autowired
	private AdminService adminService;

	@Autowired
	private BufferDocumentRepository bufferDocumentRepo;

	@Autowired
	private DocumentUploadService documentService;

	@Autowired
	private SystemLogsRepository systemLogsRepository;

	@Autowired
	private InvoiceProcessorService invoiceProcessorService;
	
	@Autowired
	private VendorRepository vendorRepository;

	public JsonResponse process(UtilitySubmitRequest data, String txid, Authentication authentication,Boolean isDupCheckRequire) {

		SystemLogs systemLogs = new SystemLogs();
		systemLogs.setSystemTag(SystemLogs.SYSTEM_TAG_AP);
		systemLogs.setSystemType(SystemLogs.SYSTEM_TYPE_AUTOPILOT);
		systemLogs.setAccountNo(data.getAccountno());
		systemLogs.setAssetId(data.getAssetId());
		systemLogs.setVendorid(data.getVendorId());
		systemLogs.setTxId(txid);
		systemLogs.setAgentType(SystemLogs.SYSTEM);
		systemLogs.setAgentId("");
		systemLogs.setTitle("Process Uploaded File");
		systemLogs.setIp(HttpReqRespUtils.getClientIpAddressIfServletRequestExist());
		// systemLogs.setUserName(user.getName());

		String documentid = RandomStringUtils.randomAlphanumeric(32).toUpperCase();

		String fileName = data.getFile().getOriginalFilename();
		String fileArray[] = fileName.split("\\\\");
		fileName = fileArray[fileArray.length - 1];
		String url = documentService.buildURL(adminService.getSmartStoreConfig().get(0), documentid, "create",
				fileName);
		String fileType = "";
		if (fileName != null) {
			fileType = fileName.substring(fileName.lastIndexOf(".") + 1);
		}
		String contentType = data.getFile().getContentType();
		InputStream in = null;

		try {
			in = data.getFile().getInputStream();
			byte[] b = new byte[1024];
			int size = -1;
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			while ((size = in.read(b)) != -1) {
				out.write(b, 0, size);
			}
			in.close();

			// ====================
			systemLogs.setDescription("Autopilot Uploaded file Successfully");
			systemLogs.setStatus(SystemLogs.SYSTEM_TYPE_SUCCESS);
			systemLogs.setDateTime(ZonedDateTime.now());
			systemLogsRepository.save(systemLogs);

			// ================
			int respoonceCode = documentService.uploadFile(url, out, contentType);
			if (respoonceCode == 201) {
				BufferDocument bd = new BufferDocument();
				bd.setTxId(txid);
				bd.setFilename(fileName);
				bd.setDocid(documentid);
				bd.setFiletype(fileType);
				bd.setUploadedDate(ZonedDateTime.now());
				bd.setArid(adminService.getSmartStoreConfig().get(0).getContRep());
				bd.setAccountNumber(data.getAccountno());
				bd.setVendorId(data.getVendorId());
				if(data.getVendorId()!=null) {
				 Vendor vendorDetails=vendorRepository.findFirstByVendorId(data.getVendorId());
				 if(vendorDetails!=null && vendorDetails.getClassifications().size()!=0) {
					 bd.setUtilityType(vendorDetails.getClassifications().get(0));
				 }
				}
				bd.setAssetCode(data.getAssetId());
				bd.setJobId(data.getJobId());
				UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
				if (logedInUser != null) {
					bd.setUploadedBy(logedInUser.getEmail());
				}
				if (data.getDueDate() != null) {
					String pattern = determineDateFormat(data.getDueDate());
					if (pattern != null) {
						DateTimeFormatter Parser = DateTimeFormatter.ofPattern(pattern).withZone(ZoneId.of("UTC"));
						try {
							bd.setDueDate(ZonedDateTime.parse(data.getDueDate(), Parser));
						} catch (Exception e) {
							DateTimeFormatter Format = DateTimeFormatter.ofPattern(pattern);
							bd.setDueDate(LocalDate.parse(data.getDueDate(), Format).atStartOfDay(ZoneOffset.UTC));
						}
					}
				}
				if (data.getBillAmount() != null) {
					bd.setBillAmount(Double.valueOf(data.getBillAmount()));
				} else {
					bd.setBillAmount(Double.valueOf(0));
				}
				bd = bufferDocumentRepo.save(bd);
				JsonResponse jsonResponse = invoiceProcessorService.init(bd, txid,isDupCheckRequire);
				return jsonResponse;
			} else {

				systemLogs.setDescription("Error while uploading file.");
				systemLogs.setStatus(SystemLogs.SYSTEM_TYPE_FAIL);
				systemLogs.setDateTime(ZonedDateTime.now());

				systemLogsRepository.save(systemLogs);
				System.out.println("Error while uploading file.");
				return new JsonResponse(RESULT_FAILED, "Error while uploading file.", STATUS_500);
			}

		} catch (Exception e) {

			systemLogs.setDescription(e.getLocalizedMessage());
			systemLogs.setStatus(SystemLogs.SYSTEM_TYPE_ERROR);
			systemLogs.setDateTime(ZonedDateTime.now());
			systemLogsRepository.save(systemLogs);
			e.printStackTrace();
			return new JsonResponse(RESULT_FAILED, e.getMessage(), STATUS_500);
		}
	}

	private static final Map<String, String> DATE_FORMAT_REGEXPS = new HashMap<String, String>() {
		{
			put("^\\d{8}$", "yyyyMMdd");
			put("^\\d{1,2}-\\d{1,2}-\\d{4}$", "dd-MM-yyyy");
			put("^\\d{1,2}/\\d{1,2}/\\d{4}$", "dd/MM/yyyy");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}$", "yyyy-MM-dd");
			put("^\\d{1,2}/\\d{1,2}/\\d{4}$", "MM/dd/yyyy");
			put("^\\d{4}/\\d{1,2}/\\d{1,2}$", "yyyy/MM/dd");
			put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}$", "dd MMM yyyy");
			// put("^\\s\\d[a-z]{3}\\d{1,2}\\s\\d{4}$", "MMM dd yyyy");
			put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}$", "dd MMMM yyyy");
			put("^\\d{12}$", "yyyyMMddHHmm");
			put("^\\d{8}\\s\\d{4}$", "yyyyMMdd HHmm");
			put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}$", "dd-MM-yyyy HH:mm");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy-MM-dd HH:mm");
			put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}$", "MM/dd/yyyy HH:mm");
			put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}$", "yyyy/MM/dd HH:mm");
			put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMM yyyy HH:mm");
			put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}$", "dd MMMM yyyy HH:mm");
			put("^\\d{14}$", "yyyyMMddHHmmss");
			put("^\\d{8}\\s\\d{6}$", "yyyyMMdd HHmmss");
			put("^\\d{1,2}-\\d{1,2}-\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd-MM-yyyy HH:mm:ss");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy-MM-dd HH:mm:ss");
			put("^\\d{1,2}/\\d{1,2}/\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MM/dd/yyyy HH:mm:ss");
			put("^\\d{4}/\\d{1,2}/\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}$", "yyyy/MM/dd HH:mm:ss");

			put("^\\d[a-z]{3}\\s\\d{1,2}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "MMM dd yyyy HH:mm:ss");

			put("^\\d{1,2}\\s[a-z]{3}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{2}$", "dd MMM yyyy HH:mm:ss");
			put("^\\d{1,2}\\s[a-z]{4,}\\s\\d{4}\\s\\d{1,2}:\\d{2}:\\d{4}$", "dd MMMM yyyy HH:mm:ss.SSSS");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}$", "yyyy-MM-dd");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}.\\d{1}$", "yyyy-MM-dd HH:mm:ss.S");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}.\\d{2}$", "yyyy-MM-dd HH:mm:ss.SS");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}.\\d{3}$", "yyyy-MM-dd HH:mm:ss.SSS");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}.\\d{4}$", "yyyy-MM-dd HH:mm:ss.SSSS");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}.\\d{5}$", "yyyy-MM-dd HH:mm:ss.SSSSS");
			put("^\\d{4}-\\d{1,2}-\\d{1,2}\\s\\d{1,2}:\\d{2}:\\d{2}.\\d{6}$", "yyyy-MM-dd HH:mm:ss.SSSSSS");

		}
	};

	public static String determineDateFormat(String dateString) {
		for (String regexp : DATE_FORMAT_REGEXPS.keySet()) {
			if (dateString.toLowerCase().matches(regexp)) {
				return DATE_FORMAT_REGEXPS.get(regexp);
			}
		}
		return null; // Unknown format.
	}
}
