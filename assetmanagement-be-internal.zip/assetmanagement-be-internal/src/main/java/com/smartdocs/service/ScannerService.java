package com.smartdocs.service;


import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.CustomDto;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.mongo.collectionhelpers.UtilityInvoiceData;
import com.smartdocs.mongo.collections.DataField;
import com.smartdocs.mongo.collections.DocumentHelper;
import com.smartdocs.mongo.collections.EmailChannels;
import com.smartdocs.mongo.collections.InvoiceBuffer;
import com.smartdocs.mongo.repository.EmailChannelsRepository;
import com.smartdocs.mongo.repository.InvoiceBufferRepository;


@Service
public class ScannerService {

	
	@Autowired
	private InvoiceBufferRepository invoiceBufferRepository;
	
	@Autowired
	private EmailChannelsRepository emailChannelsRepository;
	
	
	public JsonResponse submitscannedDocument(CustomDto data,String fromUser,String txId) {
		//String logicalSystem="";
		EmailChannels ocrChannel = emailChannelsRepository.findByUsername(data.getOcrProfile());
		if(ocrChannel!=null) {
			List<DocumentHelper> docs=new ArrayList<>();
			if(data.getFile()!=null) {
				data.getFile().setDocumentType("Invoice");
				data.getFile().setPrimaryDoc(true);
				docs.add(data.getFile());
			}
			if(data.getSupportingDoc()!=null && !data.getSupportingDoc().isEmpty()) {
				for(DocumentHelper file:data.getSupportingDoc()) {
					file.setDocumentType("Other");
					file.setPrimaryDoc(false);
					docs.add(file);
				}
			}
			InvoiceBuffer invbuffer = new InvoiceBuffer(fromUser, ocrChannel.getUsername(),
					"INIT", 1,docs,  txId, ocrChannel.getChannelCode(), ocrChannel.getOcrMappingProfile(), ocrChannel.getOcrProfile());
			invbuffer.setUtility(true);
			invbuffer.setCompanyCode(txId);
			
			try {
				if (ocrChannel.getFieldsConfig() != null) {
					for (DataField field : ocrChannel.getFieldsConfig()) {
						String value = null;
						if (field.getType().equals(DataField.TYPE_FIXED)) {
							value = field.getValue();
						} 
						if (value != null) {
							try {
								PropertyDescriptor pd = new PropertyDescriptor(
										field.getField(), invbuffer.getClass());
								Method setter = pd.getWriteMethod();
								setter.invoke(invbuffer, value);

							} catch (IllegalAccessException | IllegalArgumentException
									| InvocationTargetException
									| IntrospectionException e) {
								e.printStackTrace();

							}
						}

					}
				} 
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			
			if(data.getFile()!=null)
				invbuffer.setInvoiceDocId( data.getFile().getDocumentid());
			invbuffer.setPoNumber(data.getPoNumber());
			invbuffer.setGlAccount(data.getGlAccount());
			invbuffer.setCostCenter(data.getCostCenter());
			invbuffer.setSupplierId(data.getVendorId());
			invbuffer.setCreator(fromUser);
			invbuffer.setAccountNo(data.getAccountNo());
			invbuffer.setUtilityData(new UtilityInvoiceData(data));
			invoiceBufferRepository.save(invbuffer);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS,"Submitted Successfully",JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED,"Invalid User Profile",JsonResponse.STATUS_500);
	}
	
}
