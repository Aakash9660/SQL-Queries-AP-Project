package com.smartdocs.service;

import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.Robot;
import com.smartdocs.model.TaskStatus;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.repository.RobotRepository;
import com.smartdocs.repository.TaskStatusRepository;

@Service
public class TaskExeutionService {

	@Autowired
	private TaskStatusRepository taskStatusRepository;
	
	@Autowired
	private AssetAccountRepository assetAccountRepository;

	@Autowired
	private MissingBillsService missingBillsServices;
	
	@Autowired
	private JenkinsLogService jenkinsLogService;
	
	@Autowired
	private TimeSlotsService timeSlotsService;
	
	@Autowired
	private RobotRepository robotRepository;
	
	@Autowired
	private RobotService robotService;
	
	@Autowired
	private JenkinsService1 jenkinsService;
	
	@Autowired
	private JenkinsService2 jenkinsService2;


	@Async
	public void executeMissingRepotCreate(TaskStatus task,int gracePeriod,int startMonth) 
	{
		missingBillsServices.deleteAllRecords();
		startTask(task);
		int recordProcessed=0;
		List<AssetAccount> assetAccounts=assetAccountRepository.findAll();
		if(assetAccounts!=null) {
			task.setTotalDataToProcees(assetAccounts.size());
			for(AssetAccount asset:assetAccounts) {
				System.out.println("Running missing billd for :"+asset.getAssetAccountId());
				missingBillsServices.updateMissingInvoiceRecord(asset,gracePeriod,startMonth);
				recordProcessed++;
				task.setRecorProcessed(""+recordProcessed);
				updateTask(task);
			}
		}
		endTask(task);
	}
	
	@Async
	public void executeJenkinsSyncLog(TaskStatus task) 
	{
		startTask(task);
		//int recordProcessed=0;
		jenkinsLogService.syncLog(task );
		
		endTask(task);
	}
	
	@Async
	public void executeResetTimeSlot(TaskStatus task) 
	{
		startTask(task);
		timeSlotsService.creatTimeSlotsBySQLFunction();
		endTask(task);
	}
	@Async
	public void unScheduleAllJobs(TaskStatus task) {
		startTask(task);
		
		List<Robot> robots = robotRepository.findAll();
		if (robots!=null) 
		{
			 task.setTotalDataToProcees(3);
			 robotService.unScheduleAllJobs(robots);
			 task.setRecorProcessed(""+1);
			 updateTask(task);
			 timeSlotsService.creatTimeSlotsBySQLFunction();
			 task.setRecorProcessed(""+2);
			 updateTask(task);
			 robotRepository.unPublishAllRobots();
			 task.setRecorProcessed(""+3);
			 updateTask(task);
			
		} 
		endTask(task);
		 
	}
	@Async
	public void scheduleAllPublishedJobs(TaskStatus task) {
		startTask(task);
		int recordProcessed=0;
		List<Robot> robots = robotRepository.findByStatusAndSchedule(Robot.STATUS_PUBLISHED,false);
		if (robots!=null) 
		{
			task.setTotalDataToProcees(robots.size());
			 for(Robot robot:robots) {
				 robotService.publishingJob(robot, true);
				 recordProcessed++;
				 task.setRecorProcessed(""+recordProcessed);
				 updateTask(task);
			 }
		}
		endTask(task);
		 
	}
	@Async
	public void publishAllBots(TaskStatus task) {
		startTask(task);
		int recordProcessed=0;
		List<Robot> robots = robotRepository.findByStatusNot(Robot.STATUS_PUBLISHED);
		if (robots!=null) 
		{
			 task.setTotalDataToProcees(robots.size());
			 for(Robot robot:robots) {
				 robotService.publishRobot(robot);
				 recordProcessed++;
				 task.setRecorProcessed(""+recordProcessed);
				 updateTask(task);
			 }
		}
		endTask(task);
		 
	}
	@Async
	public void unpublishAllBots(TaskStatus task) {
		startTask(task);
		 jenkinsService.deleteAllJobsInJenkinsServer();
		 jenkinsService2.deleteAllJobsInJenkinsServer(); 
		 timeSlotsService.creatTimeSlotsBySQLFunction();
		 robotRepository.unPublishAllRobots();
		endTask(task);
		 
	}
	private void startTask(TaskStatus task) {
		task.setExecutionNumber(task.getExecutionNumber()+1);
		task.setEndTime(null);
		task.setStartTime(ZonedDateTime.now());
		task.setState(TaskStatus.STATE_RUNNING);
		task.setRecorProcessed("0");
		task.setTotalDataToProcees(0);
		taskStatusRepository.save(task);
	}
	
	public void endTask(TaskStatus task) {
		task.setEndTime(ZonedDateTime.now());
		task.setState(TaskStatus.STATE_STOPED);
		task.setTotalDataToProcees(0);
		task.setLastExCompletionDate(ZonedDateTime.now());
		 Duration duration = Duration.between(
				 task.getStartTime(), 
				 task.getEndTime() 
	                );
		task.setLastExecutedTime(duration.toSeconds()); 
		taskStatusRepository.save(task);
		
		
	}
	
	private void updateTask(TaskStatus task) {
		taskStatusRepository.save(task);
	}
}
