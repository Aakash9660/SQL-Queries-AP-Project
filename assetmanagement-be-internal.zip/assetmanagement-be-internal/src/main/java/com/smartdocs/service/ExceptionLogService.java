package com.smartdocs.service;

 
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartdocs.mongo.collections.ExceptionLog;
import com.smartdocs.mongo.collections.ExceptionLogDetail;
import com.smartdocs.mongo.repository.ExceptionLogDetailRepository;
import com.smartdocs.mongo.repository.ExceptionLogRepository;



@Service
public class ExceptionLogService {

	private static final Logger log = LoggerFactory.getLogger(ExceptionLogService.class);
	
	
	@Autowired
	private ExceptionLogRepository exceptionLogRepository;
	
	@Autowired
	private ExceptionLogDetailRepository exceptionLogDetailRepository;
	
	public String addLog(Exception exe, String uri,String request,String erorCode) {
		
		UUID uuid = UUID.randomUUID();
		String txId = uuid.toString();
		try {
			
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			exe.printStackTrace(pw);
			
			String errorLog = sw.toString();
			ExceptionLog exLog=new ExceptionLog();
			exLog.setTitle(exe.getMessage());
			exLog.setTxId(txId);
			exLog.setUri(uri);
			exLog.setErrorCode(erorCode);
			exceptionLogRepository.save(exLog);
			
			ExceptionLogDetail logDetail = new ExceptionLogDetail(txId, request, errorLog);
			exceptionLogDetailRepository.save(logDetail);
		}
		catch(Exception ex) {
			log.error("Tx Id: {}", txId);
			log.error("request: {}", request);
			log.error("Exception in addLog: {}", ex.getMessage());
		}
		return txId;
	}

	public String addLog(String title,String uri,String request,String erorCode,String errorLog) {
		
		UUID uuid = UUID.randomUUID();
		String txId ="AP-"+ uuid.toString();
		try {
			
			ExceptionLog exLog=new ExceptionLog();
			exLog.setTitle(title);
			exLog.setTxId(txId);
			exLog.setUri(uri);
			exLog.setErrorCode(erorCode);
			exceptionLogRepository.save(exLog);
			
			ExceptionLogDetail logDetail = new ExceptionLogDetail(txId, request, errorLog);
			exceptionLogDetailRepository.save(logDetail);
		}
		catch(Exception ex) {
			log.error("Tx Id: {}", txId);
			log.error("request: {}", request);
			log.error("errorLog: {}", errorLog);
			log.error("Exception: {}", ex.getMessage());
		}
		return txId;
	}
	

	
}
