package com.smartdocs.service;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.SystemConfig;
import com.smartdocs.model.TaskStatus;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.SystemConfigRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.TaskStatusRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.HttpReqRespUtils;

@Service
public class SystemConfigService {

	@Autowired
	private SystemConfigRepository systemConfigRepository;
	
	@Autowired
	private TaskStatusRepository taskStatusRepository;
	
	@Autowired
	private TaskExeutionService taskExeutionService;
	
	@Autowired
	private SystemLogsRepository systemLogsRepository;
	
	public JsonResponse updateConfiguartion(String config,SystemConfig systemConfig) {
		Optional<SystemConfig> existConfig = systemConfigRepository.findByConfig(config);
		if(existConfig.isPresent()) {
			systemConfig.setConfig(config);
			systemConfigRepository.save(systemConfig);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Configuration update successfully", JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Configuration "+config+" can't find", JsonResponse.STATUS_500);
	}
	
	public JsonResponse getConfiguartion(String config) {
		Optional<SystemConfig> existConfig = systemConfigRepository.findByConfig(config);
		if(existConfig.isPresent()) {
			return new JsonResponse(existConfig.get(),JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Configuration "+config+" can't find", JsonResponse.STATUS_500);
	}
	
	public String getConfigValue(String config) {
		Optional<SystemConfig> existConfig = systemConfigRepository.findByConfig(config);
		if(existConfig.isPresent()) {
			return existConfig.get().getValue();
		}
		else {
			if(SystemConfig.DUP_CHECK.equals(config)) 
			{
				return "false";
			}
			else if(SystemConfig.MISSING_BILL_GRACE_PERIOD.equals(config)) {
				return "10";
			}
			return "";
		}
		
	}
	
	public List<TaskStatus> listTask(){
		return taskStatusRepository.findAll(Sort.by("name"));
	}
	public TaskStatus getTask(String taskId){
		Optional<TaskStatus> task= taskStatusRepository.findById(taskId);
		if(task.isPresent()) {
			return task.get();
		}return null;
	}
	public JsonResponse execute(UserPrincipal logedInUser,String taskId){
		Optional<TaskStatus> task= taskStatusRepository.findById(taskId);
		if(task.isPresent()) {
			if(task.get().getState()==TaskStatus.STATE_RUNNING) {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "This task is already running.", JsonResponse.STATUS_500);
			}
			else {
				
				String message="";
				boolean isValid=false;
				if(TaskStatus.MISSING_BILL_RECORD_CREATE.equalsIgnoreCase(task.get().getTaskId())) {
					message="Missing bill report sync.";
					String value =getConfigValue(SystemConfig.MISSING_BILL_GRACE_PERIOD);
					String startMonth =getConfigValue(SystemConfig.START_MONTH);
					int gracePeriod=10;
					int startMonths=6;
					try {
						gracePeriod=Integer.valueOf(value);
						startMonths=Integer.valueOf(startMonth);
					}catch(Exception e) {} 
					taskExeutionService.executeMissingRepotCreate(task.get(),gracePeriod,startMonths);
					isValid=true;
				}
				else if(TaskStatus.JK_SYNC_LOG.equalsIgnoreCase(task.get().getTaskId())) {
					message="failed bot data sync.";
					taskExeutionService.executeJenkinsSyncLog(task.get());
					isValid=true;
				}
				else if(TaskStatus.RESET_TIME_SLOT.equalsIgnoreCase(task.get().getTaskId())) {
					message="reset scheduled time slot.";
					taskExeutionService.executeResetTimeSlot(task.get());
					isValid=true;
				}
				
				else if(TaskStatus.PUBLISH_ALL_BOTS.equalsIgnoreCase(task.get().getTaskId())) {
					message="publish all bots.";
					taskExeutionService.publishAllBots(task.get());
					isValid=true;
				}
				else if(TaskStatus.SCHEDULE_ALL_BOTS.equalsIgnoreCase(task.get().getTaskId())) {
					message="schedule all bots.";
					isValid=true;
					taskExeutionService.scheduleAllPublishedJobs(task.get());
				}
				else if(TaskStatus.UNSCHEDULE_ALL_BOTS.equalsIgnoreCase(task.get().getTaskId())) {
					message="un-schedule all bots.";
					taskExeutionService.unScheduleAllJobs(task.get());
					isValid=true;
				}
				
				
				else if(TaskStatus.UNPUBLISH_ALL_BOTS.equalsIgnoreCase(task.get().getTaskId())) {
					message="un-publish all bots.";
					taskExeutionService.unpublishAllBots(task.get());
					isValid=true;
				}
				if(isValid) {
					SystemLogs systemLogs = new SystemLogs(
							message+"",
							message+" task Started ",
							ZonedDateTime.now(),
							UUID.randomUUID().toString(), SystemLogs.SYSTEM_TYPE_AUTOPILOT,
							SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_AP,
							logedInUser==null?"":logedInUser.getEmail(),
							task.get().getTaskId(),HttpReqRespUtils.getClientIpAddressIfServletRequestExist());
					systemLogsRepository.save(systemLogs);
					return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Task execution stated, It will take few min", JsonResponse.STATUS_200);
				}
				else {
					return new JsonResponse(JsonResponse.RESULT_FAILED, "Invalid Task", JsonResponse.STATUS_200);	
				}
				
			}
			
		}else return new JsonResponse(JsonResponse.RESULT_FAILED, "Invalid Task", JsonResponse.STATUS_500);
		
	}
}
