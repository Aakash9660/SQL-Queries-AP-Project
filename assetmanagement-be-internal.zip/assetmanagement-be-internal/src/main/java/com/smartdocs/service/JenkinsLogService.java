package com.smartdocs.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartdocs.dto.JKCreadentials;
import com.smartdocs.jenkins.dto.FreeStyleProject;
import com.smartdocs.jenkins.dto.Hudson;
import com.smartdocs.model.Robot;
import com.smartdocs.model.RobotLog;
import com.smartdocs.model.RobotLogActivityDetail;
import com.smartdocs.model.TaskStatus;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.mongo.collections.PermissionGroup;
import com.smartdocs.mongo.collections.User;
import com.smartdocs.mongo.repository.PermissionGroupDao;
import com.smartdocs.mongo.repository.UserRepository;
import com.smartdocs.repository.RobotLogActivityDetailRepository;
import com.smartdocs.repository.RobotLogRepository;
import com.smartdocs.repository.RobotRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class JenkinsLogService {
	
	
	@Value("${jenkinsUsername1}")
	private String jenkinsServerUsername;

	@Value("${jenkinsPassword1}")
	private String jenkinsServerPassword;

	@Value("${jenkinsUrl1}")
	private String jenkinsServerUrl;
	
	private String sid="1";
	
	@Autowired
	private RobotLogRepository robotLogRepository;
	
	@Autowired
	private RobotRepository robotRepository;
	
	@Autowired
	private FailedBotNotificationService failedBotNotificationService;

	@Autowired
	private RobotLogActivityDetailRepository rladRepository;

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PermissionGroupDao permissionGroupDao;
	
	@Autowired
	private SystemLogsRepository systemLogsRepository;
	
	public boolean syncLog(TaskStatus task) {
		int count=0;
		JKCreadentials client=new JKCreadentials(jenkinsServerUrl,jenkinsServerUsername,jenkinsServerPassword);
		Hudson serverlog=getJenkinsServerJobLog(task.getTaskId(),client,5);
		boolean status=false;
		if(serverlog!=null && serverlog.getJobs()!=null) 
		{
			
			List<PermissionGroup> permissions= permissionGroupDao.findEditPermissions("AP_FailedBotL1");
			List<String> permissionss=null;
			if(permissions!=null && permissions.size()>0) {
				permissionss=new ArrayList<String>();
				for(PermissionGroup  permission:permissions) {
					permissionss.add(permission.getGroupId());
				}
			}
			System.out.println("L1 Permissions "+permissionss);
			
			//1. get list of Roles from permission group.
			List<User> users=userRepository.findAllByAuthPermissionGroupsIn(permissionss);
			
			System.out.println("Server log not null");
			for(FreeStyleProject project:serverlog.getJobs()) 
			{
				System.out.println("Project :"+project.getName());
				if(project.getBuilds()!=null)
				{
				
					String jobId=project.getName();
					for (count = project.getBuilds().size() - 1; count >= 0; count--) {
						
						if(!project.getBuilds().get(count).isInProgress() && !project.getBuilds().get(count).isBuilding()) 
						{
							String id=project.getName()+"_"+sid+"_"+project.getBuilds().get(count).getNumber();
							Optional<RobotLog> rbotLog =robotLogRepository.findById(id);
							if(!rbotLog.isPresent()) {
								
								Optional<Robot> rpbot=robotRepository.findByJobId(jobId);
								if(rpbot.isPresent()) {
									RobotLog botLog=new RobotLog(project.getName(),sid,rpbot.get(),project.getBuilds().get(count));
									if(project.getBuilds().get(count).getTimestamp()>rpbot.get().getLastExecutedms()) {
										rpbot.get().setLastExecutedms(project.getBuilds().get(count).getTimestamp());
										rpbot.get().setLastExecuted(GeneralUtil.toDate(project.getBuilds().get(count).getTimestamp()));
										rpbot.get().setExecutedStatus(project.getBuilds().get(count).getResult());
										rpbot.get().setLeLogId(botLog.getId()); 
										robotRepository.save(rpbot.get());
									}
									
									if("FAILURE".equalsIgnoreCase(botLog.getBuildStatus())) {
										failedBotNotificationService.sendL1FailedBotNotification(botLog,users);
										robotLogRepository.save(botLog);
									}
									else {
										robotLogRepository.save(botLog);
									}
									
								}
							}
						}
						
					}
					
				}
			}
			status=true;
		}
		return status;
	}
	
	

	public Hudson getJenkinsServerJobLog(String jobId,JKCreadentials client,int noOfLogs) {
		System.out.println("Ex:");
		Hudson resp = null;
		try {
			String api="api/json?tree=jobs[name,builds[number,url,inProgress,estimatedDuration,duration,keepLog,building,id,timestamp,queueId,result]{0,"+noOfLogs+"}]&pretty=true";
			URL url = new URL(client.getServerURL()+api); 
			StringBuilder body = null;
			String line = "";
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("Authorization", client.getAuth());
			if (connection.getResponseCode() == 200) {
				InputStream content = connection.getInputStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(content));
				body = new StringBuilder();
				while ((line = br.readLine()) != null) {
					body.append(line);
				}
				connection.disconnect();
				ObjectMapper mapper = new ObjectMapper();
				resp = mapper.readValue(body.toString(), Hudson.class);
				System.out.println("getJenkinsServerJobLog Response :"+connection.getResponseCode());
				
			}else {
				System.out.println("getJenkinsServerJobLog Response :"+connection.getResponseCode());
				SystemLogs systemLogs = new SystemLogs(
						"Sync Jenkins Server Log",
						"Response:"+connection.getResponseCode(),
						ZonedDateTime.now(),
						UUID.randomUUID().toString(), SystemLogs.SYSTEM_TYPE_JENKINS,
						SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK,
						SystemLogs.USER,
						jobId);
				systemLogsRepository.save(systemLogs);
			}
		} catch (Exception e) {
			//TODO : Log  this activity. 
			
			System.out.println("getJenkinsServerJobLog Ex:"+e.getMessage());
			
			SystemLogs systemLogs = new SystemLogs(
					"Sync Jenkins Server Log",
					e.getLocalizedMessage(),
					ZonedDateTime.now(),
					UUID.randomUUID().toString(), SystemLogs.SYSTEM_TYPE_JENKINS,
					SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK,
					SystemLogs.USER,
					jobId);
			systemLogsRepository.save(systemLogs);
			
			e.printStackTrace();
		}
		return resp;
	}
	
	
}
