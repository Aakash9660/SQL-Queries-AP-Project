package com.smartdocs.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.BillDocumentRequest;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.UpdateActionRequest;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.BillDocument;
import com.smartdocs.model.ManageBillsLog;
import com.smartdocs.model.MissingBills;
import com.smartdocs.model.SystemConfig;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.repository.BillDocumentRepository;
import com.smartdocs.repository.ManageBillsLogRepository;
import com.smartdocs.repository.MissingBillsRepository;
import com.smartdocs.repository.SystemConfigRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.sql.dto.ManageBillsLogInf;
import com.smartdocs.sql.dto.MissingBillInf;

@Service
public class MissingBillsService {

	@Autowired
	private MissingBillsRepository missingBillsRepository;

	@Autowired
	private AssetAccountRepository assetAccountRepository;

	@Autowired
	private BillDocumentRepository billDocumentRepository;

	@Autowired
	private SystemConfigRepository systemConfigRepository;

	@Autowired
	private ExcelGeneratorService excelGeneratorService;

	@Autowired
	private ManageBillsLogRepository manageBillsLogRepository;

	public JsonResponse missingInvoicesReport(String asset, String accountNo, String vendorId) {
		System.out.println("missingInvoicesReport");
		AssetAccount assetAccoounts = assetAccountRepository.findOneByAssetCodeAndAccountNumberAndVendorId(asset,
				accountNo, vendorId);
		if (assetAccoounts != null) {
			System.out.println("assetAccoounts found");
			assetAccoounts.setLmdChecked(null);
			assetAccountRepository.setlmdCheckedNull(asset, accountNo, vendorId);
			missingBillsRepository.deleteByAssetCodeAndAccountNoAndVendorId(asset, accountNo, vendorId);
			updateMissingInvoiceRecord(assetAccoounts);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Missing bill updated or already Present ",
					JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Records not found as missing bills",
				JsonResponse.STATUS_500);
	}

	public void updateMissingInvoiceRecord(AssetAccount assetAccount) {
		String value = getConfigValue(SystemConfig.MISSING_BILL_GRACE_PERIOD);
		String pointer = getConfigValue(SystemConfig.START_MONTH);
		int gracePeriod = 10;
		int startMonth = 6;
		try {
			gracePeriod = Integer.valueOf(value);
			startMonth = Integer.valueOf(pointer);

		} catch (Exception e) {
		}
		updateMissingInvoiceRecord(assetAccount, gracePeriod, startMonth);
	}

	public boolean updateMissingInvoiceRecord(AssetAccount assetAccount, int gracePeriodDays, int startMonth) {
		System.out.println("updateMissingInvoiceRecord");
		ZonedDateTime defaultDate = ZonedDateTime.now().minusMonths(startMonth);

		ZonedDateTime datePointer = assetAccount.getLmdChecked();
		if (datePointer == null) {
			if (assetAccount.getStartDate() != null && assetAccount.getStartDate().isAfter(defaultDate)) {
				ZonedDateTime startDate = assetAccount.getStartDate().plusMonths(1);
				datePointer = startDate.with(TemporalAdjusters.firstDayOfMonth());
			} else {
				datePointer = defaultDate.with(TemporalAdjusters.firstDayOfMonth());
			}
		}
		System.out.print("datePointer : " + datePointer);
		ZonedDateTime startDate = datePointer;
		int frequency = 1;
		try {
			frequency = Integer.parseInt(assetAccount.getFrequency());
		} catch (Exception e) {
		}
		if (frequency < 1) {
			frequency = 1;
		}
		boolean isPresent = true;
		boolean response = false;
		while (isPresent) {
			System.out.println("Inside while frequency" + frequency);
			// dt+freqMonth < now 
			ZonedDateTime plusMonths = startDate.plusMonths(frequency);
			System.out.println("plusmonth:-" + plusMonths);
			System.out.println("startDate:-" + startDate);
			ZonedDateTime now = ZonedDateTime.now().minusDays(gracePeriodDays);
			if (plusMonths.isBefore(now)) {
				System.out.println(plusMonths + " isBefore " + now);
				String period = getPeriodFromStartDate(startDate, frequency);
				if (isThisPeriodBillExist(assetAccount, startDate, plusMonths)) {
					// bill exist that means not missing.
				} else {
					// bill is missing.
					if (createMissingBillsRecord(assetAccount, period)) {
						response = true;
					}
				}
				// update pointer
				startDate = plusMonths;
				assetAccount.setLmdChecked(startDate);
				assetAccountRepository.save(assetAccount);
				System.out.println("Saved asset account with date " + startDate);
			} else {
				isPresent = false;
				System.out.println("Exit");
			}
		}
		System.out.println("========ended====");
		return response;
	}

	private boolean createMissingBillsRecord(AssetAccount assetAccount, String period) {
		MissingBills missingBills = new MissingBills(assetAccount);
		missingBills.setPeriod(period);
		System.out.println(period);
		String id = missingBills.getAssetCode() + "-" + missingBills.getAccountNo() + "-" + missingBills.getVendorId()
				+ "-" + period;
		if (!missingBillsRepository.existsById(id)) {
			missingBills.setId(id);
			missingBills.setStatus(MissingBills.STATUS_NEW);
			missingBills.setCreatedDate(ZonedDateTime.now());
			missingBills.setLastUpdated(ZonedDateTime.now());
			missingBillsRepository.save(missingBills);
			return true;
		}
		return false;
	}

	private static String getPeriodFromStartDate(ZonedDateTime startDateTime, int freq) {
		List<String> months = new ArrayList<>();
		for (int i = 0; i < freq; i++) {
			ZonedDateTime dt = startDateTime.plusMonths(i);
			String month = DateTimeFormatter.ofPattern("MMMyy").format(dt);
			months.add(month);
		}
		return months.stream().map(Object::toString).collect(Collectors.joining(","));
	}

	private boolean isThisPeriodBillExist(AssetAccount assetAccount, ZonedDateTime startDate, ZonedDateTime plusMonth) {
		boolean isPresent = false;
		if (billDocumentRepository.isBillsPresent(assetAccount.getAssetCode(), assetAccount.getAccountNumber(),
				assetAccount.getVendorId(), plusMonth, startDate)) {
			isPresent = true;
		}
		return isPresent;
	}

	private String getConfigValue(String config) {
		Optional<SystemConfig> existConfig = systemConfigRepository.findByConfig(config);
		if (existConfig.isPresent()) {
			return existConfig.get().getValue();
		} else {
			if (SystemConfig.DUP_CHECK.equals(config)) {
				return "false";
			} else if (SystemConfig.MISSING_BILL_GRACE_PERIOD.equals(config)) {
				return "10";
			} else if (SystemConfig.START_MONTH.equals(config)) {
				return "6";
			}
			return "";
		}

	}

	public Page<MissingBillInf> searchMissingBills(Boolean manualIntervention, String status, int page, int size,
			String order, String assetCode, String vendorId, String channel, String accountNo, String period) {
		Pageable sortPageRequest = GeneralUtil.getSortPageRequest(order, page, size);
		if (StringUtils.isBlank(status)) {
			status = null;
		}
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(channel)) {
			channel = null;
		} else {
			channel = channel.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(accountNo)) {
			accountNo = null;
		} else {
			accountNo = accountNo.trim();
		}
		if (StringUtils.isBlank(period)) {
			period = null;
		} else {
			period = period.trim();
		}
		if (manualIntervention == null) {
			manualIntervention = false;
		}
		return missingBillsRepository.searchMissingBillsByNativeQuery(manualIntervention, status, period, assetCode,
				accountNo, vendorId, channel, sortPageRequest);
	}

	public ByteArrayInputStream getMissingBillsDownLoad(Boolean manualIntervention, String status, String assetCode,
			String vendorId, String channel, String accountNo, String period) throws IOException {
		if (StringUtils.isBlank(status)) {
			status = null;
		}
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(channel)) {
			channel = null;
		} else {
			channel = channel.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(accountNo)) {
			accountNo = null;
		} else {
			accountNo = accountNo.trim();
		}
		if (StringUtils.isBlank(period)) {
			period = null;
		} else {
			period = period.trim();
		}
		if (manualIntervention == null) {
			manualIntervention = false;
		}
		List<MissingBillInf> missingBillsList = missingBillsRepository.searchMissingBillsList(manualIntervention,
				status, period, assetCode, accountNo, vendorId, channel);
		return excelGeneratorService.missingBillsReportToExcel(missingBillsList);
	}

	public JsonResponse updateStatus(UpdateActionRequest actionRequest) {
		if (actionRequest != null) {
			Optional<MissingBills> optionalmissingBill = missingBillsRepository.findById(actionRequest.getId());
			if (optionalmissingBill.isPresent()) {
				optionalmissingBill.get().setStatus(actionRequest.getStatus());
				optionalmissingBill.get().setComments(actionRequest.getComment());
				optionalmissingBill.get().setLastUpdated(ZonedDateTime.now());
				missingBillsRepository.save(optionalmissingBill.get());
				return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Action Performed Successfully",
						JsonResponse.STATUS_200);
			}
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't find bill", JsonResponse.STATUS_500);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Update request is absent", JsonResponse.STATUS_500);
	}

	public JsonResponse updateActionOnManageBills(UpdateActionRequest actionRequest, UserPrincipal logedInUser) {
		if (actionRequest != null) {
			ManageBillsLog log = new ManageBillsLog(actionRequest, logedInUser);
			if (ManageBillsLog.ACTIVITY_ADDING_NOTES.equals(actionRequest.getActivityCode())) {
				log.setActivityCode(ManageBillsLog.ACTIVITY_ADDING_NOTES);
				log.setActivityDesc("Added Notes");
				log.setComments(actionRequest.getNotes());
				AssetAccount assetAccount = assetAccountRepository.findOneByAssetCodeAndAccountNumberAndVendorId(
						actionRequest.getAssetCode(), actionRequest.getAccountNo(), actionRequest.getVendorId());
				assetAccount.setNotes(actionRequest.getNotes());
				assetAccountRepository.save(assetAccount);
			} else {
				log.setActivityCode(ManageBillsLog.ACTIVITY_SYSTEM_BILLS);
				log.setActivityDesc("Added bill");
			}
			manageBillsLogRepository.save(log);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Action Performed Successfully",
					JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Update Request is absent", JsonResponse.STATUS_500);
	}

	public void actionOnManageBillsForEmailInvoices(BillDocument billDocument) {
		try {
			ManageBillsLog log = new ManageBillsLog(billDocument);
			log.setActivityCode(ManageBillsLog.ACTIVITY_EMAIL_BILLS);
			log.setActivityDesc("Bill received from Email");
			manageBillsLogRepository.save(log);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<ManageBillsLogInf> getManageBills(String assetCode, String vendorId, String accountNo) {
		List<ManageBillsLogInf> logInf = new ArrayList<>();
		List<ManageBillsLogInf> logs = manageBillsLogRepository.findManageBillsLog(vendorId, accountNo, assetCode);
		for (ManageBillsLogInf inf : logs) {
			if (ManageBillsLog.ACTIVITY_ADDING_NOTES.equals(inf.getActicityCode())) {
				logInf.add(inf);
			} else if (!ManageBillsLog.ACTIVITY_ADDING_NOTES.equals(inf.getActicityCode()) && inf.getBillMonth() != null) {
				logInf.add(inf);
			}
		}
		return logInf;
	}

	public JsonResponse updateMissingBillsData(BillDocumentRequest actionRequest) {
		if (actionRequest != null) {
			Optional<MissingBills> optional = missingBillsRepository.findById(actionRequest.getMissingBillId());
			if (optional.isPresent()) {
				MissingBills missingBills = new MissingBills();
				BeanUtils.copyProperties(optional.get(), missingBills);
				missingBills.setStatus(actionRequest.getStatus());
				missingBills.setLastUpdated(ZonedDateTime.now());
				missingBillsRepository.save(missingBills);
				return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Action taken successfully",
						JsonResponse.STATUS_200);
			}
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't find request ", JsonResponse.STATUS_500);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Update Request is absent", JsonResponse.STATUS_500);
	}

	@Transactional
	public void deleteAllRecords() {
		missingBillsRepository.deleteAllRecords();
		assetAccountRepository.setlmdCheckedNullWherelmdCheckedNotNull();
	}

	@Transactional
	public void setToObsoleteRecords(List<String> ids, String comments) {
		missingBillsRepository.setObsoleteByIds(ids, comments);
	}

}
