package com.smartdocs.service;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartdocs.dto.CustomDto;
import com.smartdocs.dto.FilesCompareRequestDTO;
import com.smartdocs.dto.FilesCompareResponseDTO;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.BillDocument;
import com.smartdocs.model.BillDocumentLog;
import com.smartdocs.model.BufferDocument;
import com.smartdocs.model.SystemConfig;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.dto.DCMProcessRequest;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.mongo.collections.DocumentHelper;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.repository.AssetRepository;
import com.smartdocs.repository.BillDocumentLogRepository;
import com.smartdocs.repository.BillDocumentRepository;
import com.smartdocs.repository.BufferDocumentRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.service.util.CleanPDFFileService;
import com.smartdocs.service.util.HttpReqRespUtils;
import com.smartdocs.service.util.OauthResponseHandler;

@Service
public class InvoiceProcessorService {

	final static Logger logger = LoggerFactory.getLogger(InvoiceProcessorService.class);
	@Autowired
	private BufferDocumentRepository bufferDocumentRepo;

	@Autowired
	private BillDocumentRepository billDocumentRepository;

	@Autowired
	private AssetAccountRepository assetAccountRepository;

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	private SystemLogsRepository systemLogsRepository;

	@Autowired
	private ScannerService scannerService;

	@Autowired
	private BillDocumentLogRepository billDocumentLogRepository;

	@Value("${duplicateFileCheckUrl}")
	private String duplicateFileCheckUrl;

	@Autowired
	private SystemConfigService systemConfigSerice;

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private CleanPDFFileService cleanPDFFileService;

//	private final RestTemplate restTemplate = new RestTemplate();

	public JsonResponse init(BufferDocument bd, String txtId, Boolean isDupCheckRequire)
			throws ClientProtocolException, IOException {
		logger.info("Init {}", bd.getTxId());

		List<BillDocument> oldBillds = billDocumentRepository
				.findByAssetCodeAndAccountNumberAndVendorId(bd.getAssetCode(), bd.getAccountNumber(), bd.getVendorId());
		if (oldBillds != null && oldBillds.size() > 0) {
			String inProcessDocId = bd.getDocid();
			List<String> processedDocIds = new ArrayList<String>();
			for (BillDocument oldBil : oldBillds) {
				// if (!"CANCELED".equals(oldBil.getStatus()))
				processedDocIds.add(oldBil.getDocid());
			}
			if (isDupCheckRequire == null) {
				isDupCheckRequire = true;
			}
			String value = systemConfigSerice.getConfigValue(SystemConfig.DUP_CHECK);
			if (value != null && "true".equalsIgnoreCase(value) && isDupCheckRequire) {
				String dupId = duplicateCheckService(txtId, bd, bd.getTxId(), inProcessDocId, processedDocIds);
				if (!dupId.equals("Exception")) {
					if (dupId.equals("-1")) {
						return processForBillDocument(bd, txtId);
					} else {
						bd.setDuplicatedocId(dupId);
						bd.setStatus(BufferDocument.STATUS_DUPLICATE);
						bufferDocumentRepo.save(bd);
						return new JsonResponse(JsonResponse.RESULT_FAILED, "Bill Document is duplicated",
								JsonResponse.STATUS_500);
					}
				} else {
					return new JsonResponse(JsonResponse.RESULT_FAILED, "Duplicate Check getting Exception",
							JsonResponse.STATUS_500);
				}
			} else {
				return processForBillDocument(bd, txtId);
			}
		} else {
			// LOg txId.
			logger.info("TX:{} There is no existing invoice with for AssetCode:{}, Account Number:{},Vendor Id: {}",
					bd.getTxId(), bd.getAssetCode(), bd.getAccountNumber(), bd.getVendorId());
			JsonResponse jsonResponse = processForBillDocument(bd, txtId);

			return jsonResponse;
		}
	}

	public JsonResponse processInvoice(DCMProcessRequest request) {

		BufferDocument bd = bufferDocumentRepo.findOneByTxId(request.getTxId());
		if (bd != null) {
			if (request.isDuplicate()) {

			} else {
				processForBillDocument(bd, request.getTxId());
			}

		}
		return null;
	}

	public JsonResponse processForBillDocument(BufferDocument bd, String txtId) {
		JsonResponse response = null;
		String docid = null;
		if (bd != null) {
			AssetAccount assetAccount = assetAccountRepository.findOneByAssetCodeAndAccountNumberAndVendorId(
					bd.getAssetCode(), bd.getAccountNumber(), bd.getVendorId());
			Asset asset = assetRepository.findOneByAssetCode(bd.getAssetCode()).get();
			BillDocument billDoc = new BillDocument(bd, assetAccount, asset);
			billDoc.setStatus(BillDocument.STATUS_NEW);
			billDoc = billDocumentRepository.save(billDoc);
			billDocumentLogRepository.save(new BillDocumentLog(billDoc.getId(), BillDocumentLog.DIRECTION_CREATE,
					"Bill created in AP system", BillDocumentLog.STATUS_SUCCESS));

			// Send to CleanPDFFileService
			try {
				Vendor vendor = vendorRepository.findFirstByVendorId(billDoc.getVendorId());
				if (vendor != null && vendor.isCleanupInvoice()) {
					docid = cleanPDFFileService.clean(billDoc.getDocid(), billDoc.getFilename());
					if (docid != null) {
						billDoc.setDocid(docid);
						billDocumentRepository.save(billDoc);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			// SENDto S1
			// Long id = billDoc.getId();
			JsonResponse jsonResponse = invoiceProcessingInPortal(billDoc);
			// JsonResponse jsonResponse = sendDataToPortal(id, txtId);
			bd.setStatus(BufferDocument.STATUS_PROCESSED);
			if(docid!=null) {
				bd.setDocid(docid);
			}
			bufferDocumentRepo.save(bd);
			if (JsonResponse.STATUS_200.equals(jsonResponse.getStatusCode())) {
				billDocumentLogRepository.save(new BillDocumentLog(billDoc.getId(), BillDocumentLog.DIRECTION_AP_TO_S1,
						"Bill send to the portal", BillDocumentLog.STATUS_SUCCESS));
				response = new JsonResponse(JsonResponse.RESULT_SUCCESS,
						"Bill Document is submitted sucessfully to portal.", JsonResponse.STATUS_200);
				response.setResult(billDoc);
			} else {
				billDocumentLogRepository.save(new BillDocumentLog(billDoc.getId(), BillDocumentLog.DIRECTION_AP_TO_S1,
						"Can't send the bill to the portal.", BillDocumentLog.STATUS_FAIL));
				response = new JsonResponse(JsonResponse.RESULT_SUCCESS, "Bill Document can't able send to portal.",
						JsonResponse.STATUS_500);

			}

		}
		return response;
	}

	private String duplicateCheckService(String txtId, BufferDocument bd, String txId, String inProcessDocId,
			List<String> processedDocIds) throws ClientProtocolException, IOException {
		String checkContentIsSame = "";

		logger.info(
				"duplicateCheckService TX:{} There is no existing invoice with for AssetCode:{}, Account Number:{},Vendor Id: {}",
				txId);
		logger.info("Inptocess docId {}", inProcessDocId);
		logger.info("processedDocIds docId {}", processedDocIds);
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPost post = new HttpPost(duplicateFileCheckUrl);
		FilesCompareRequestDTO fileCompare = new FilesCompareRequestDTO();
		fileCompare.setInProcessDocId(inProcessDocId);
		fileCompare.setProcessedDocIds(processedDocIds);
		ObjectMapper objectMapper = new ObjectMapper();
		String stringValue = objectMapper.writeValueAsString(fileCompare);
		ByteArrayEntity byteArrayEntity = new ByteArrayEntity(stringValue.getBytes(), ContentType.APPLICATION_JSON);
		post.setEntity(byteArrayEntity);
		try {
			String rawResponse = httpClient.execute(post, new OauthResponseHandler());
			logger.info("Raw Response {}", rawResponse);
			ObjectMapper mapper = new ObjectMapper();
			mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
			FilesCompareResponseDTO resp = mapper.readValue(rawResponse, FilesCompareResponseDTO.class);

			if (!resp.isContentSame()) {
				checkContentIsSame = "-1";

				SystemLogs systemLogs = new SystemLogs(SystemLogs.SYSTEM_TYPE_DUPLICATECHECK,
						SystemLogs.CONTENT_IS_NOT_SAME, ZonedDateTime.now(), txId, SystemLogs.SYSTEM_TYPE_AUTOPILOT,
						SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_AP, "", SystemLogs.SYSTEM,
						bd.getAccountNumber(), bd.getVendorId(), bd.getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), "");

				systemLogsRepository.save(systemLogs);
			} else if (resp.getProcessedDocIds() != null) {
				checkContentIsSame = resp.getProcessedDocIds().get(0);

				SystemLogs systemLogs = new SystemLogs(SystemLogs.SYSTEM_TYPE_DUPLICATECHECK,
						SystemLogs.CONTENT_IS_SAME, ZonedDateTime.now(), txId, SystemLogs.SYSTEM_TYPE_AUTOPILOT,
						SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_AP, "", SystemLogs.SYSTEM,
						bd.getAccountNumber(), bd.getVendorId(), bd.getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), "");

				systemLogsRepository.save(systemLogs);
			}
			return checkContentIsSame;
		} catch (Exception e) {

			SystemLogs systemLogs = new SystemLogs(SystemLogs.SYSTEM_TYPE_DUPLICATECHECK, "", ZonedDateTime.now(), txId,
					SystemLogs.SYSTEM_TYPE_AUTOPILOT, SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_AP, "",
					SystemLogs.SYSTEM, bd.getAccountNumber(), bd.getVendorId(), bd.getAssetCode(),
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), "");

			checkContentIsSame = "Exception";
			systemLogsRepository.save(systemLogs);
			return checkContentIsSame;
		}
	}

	private JsonResponse invoiceProcessingInPortal(BillDocument billDocument) {
		DocumentHelper attachment = new DocumentHelper(billDocument);
		CustomDto customDto = new CustomDto(billDocument);
		customDto.setFile(attachment);
		billDocument.setS1Sync(true);
		return scannerService.submitscannedDocument(customDto, "", billDocument.getTxId());
	}

//	private JsonResponse sendDataToPortal(long id, String txtId) {
//		SystemLogs systemLogs = new SystemLogs();
//		systemLogs.setSystemTag(SystemLogs.SYSTEM_TAG_AP);
//		systemLogs.setSystemType(SystemLogs.SYSTEM_TYPE_AUTOPILOT);
//		systemLogs.setTitle("send Data To Portal");
//		systemLogs.setTxId(txtId);
//		systemLogs.setAgentType(SystemLogs.SYSTEM);
//		systemLogs.setAgentId("");
//		systemLogs.setIp(HttpReqRespUtils.getClientIpAddressIfServletRequestExist());
//
//		String externalServerUrl = url + "/microservices/extinvoice/upload";
//		Optional<BillDocument> existBufferDocument = billDocumentRepository.findById(id);
//		if (existBufferDocument.isPresent()) {
//			BillDocument bd = existBufferDocument.get();
//			systemLogs.setAccountNo(bd.getAccountNumber());
//			systemLogs.setAssetId(bd.getAssetCode());
//			systemLogs.setVendorid(bd.getVendorId());
//			CustomDto customDto = new CustomDto(bd);
//			DocumentHelper attachment = new DocumentHelper(bd);
//			customDto.setFile(attachment);
//			bd.setS1Sync(true);
//			billDocumentRepository.save(bd);
//			try {
//				HttpHeaders headers = new HttpHeaders();
//				headers.setContentType(MediaType.APPLICATION_JSON);
//				HttpEntity<CustomDto> entity = new HttpEntity<CustomDto>(customDto, headers);
//				ResponseEntity<JsonResponse> responseEntity = restTemplate.exchange(externalServerUrl, HttpMethod.POST,
//						entity, JsonResponse.class);
//				JsonResponse jsonResponse = responseEntity.getBody();
//
//				if (STATUS_200.equals(jsonResponse.getStatusCode())) {
//					systemLogs.setStatus(SystemLogs.SYSTEM_TYPE_SUCCESS);
//					systemLogs.setDescription("Successfully Sync to S1");
//					systemLogs.setDateTime(ZonedDateTime.now());
//					systemLogsRepository.save(systemLogs);
//				} else {
//					systemLogs.setStatus(SystemLogs.SYSTEM_TYPE_FAIL);
//					systemLogs.setDescription("Failed Sync to S1");
//					systemLogs.setDateTime(ZonedDateTime.now());
//					systemLogsRepository.save(systemLogs);
//				}
//				return jsonResponse;
//			} catch (Exception e) {
//				systemLogs.setStatus(SystemLogs.SYSTEM_TYPE_ERROR);
//				systemLogs.setDescription(e.getLocalizedMessage());
//				systemLogs.setDateTime(ZonedDateTime.now());
//				systemLogsRepository.save(systemLogs);
//				return new JsonResponse(RESULT_FAILED, e.getMessage(), STATUS_500);
//			}
//		} else {
//			systemLogs.setStatus(SystemLogs.SYSTEM_TYPE_FAIL);
//			systemLogs.setDescription("Bill Document is Does not exist ");
//			systemLogs.setDateTime(ZonedDateTime.now());
//			systemLogsRepository.save(systemLogs);
//			return new JsonResponse(RESULT_FAILED, "Bill Document is not exist ", STATUS_500);
//		}
//	}

}
