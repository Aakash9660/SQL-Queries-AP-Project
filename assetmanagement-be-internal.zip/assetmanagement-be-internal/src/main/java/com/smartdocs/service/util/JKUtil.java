package com.smartdocs.service.util;

import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.Robot;

public class JKUtil {

	public static String getScriptFileName(String assetCode,String vendorId,String accountNo) {
		String fileName= assetCode + "__" + vendorId + "__"
				+ accountNo + ".test.ts";
		fileName=fileName.replace(" ", "");
		return fileName;
		
	}
	public static String getScriptFileName(AssetAccount assetAccount) {
		
		return getScriptFileName(assetAccount.getAssetCode(), assetAccount.getVendorId(), assetAccount.getAccountNumber());
		
	}
	public static String getScriptFileName(Robot robot) {
		
		return getScriptFileName(robot.getAssetCode(), robot.getVendorId(), robot.getAccountNo());
		
	}
}
