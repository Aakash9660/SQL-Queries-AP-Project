package com.smartdocs.service;


import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.model.BufferDocument;
import com.smartdocs.repository.BufferDocumentRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class BufferDocumentService {

	@Autowired
	private BufferDocumentRepository bufferDocumentRepository;

	public Page<BufferDocument> search(String assetCode, String vendorId, String accountNumber, String jobId,
			String txId,Integer status, int pageIndex, int size, String orderBy) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(jobId)) {
			jobId = null;
		} else {
			jobId = jobId.trim();
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}
		if (StringUtils.isBlank(txId)) {
			txId = null;
		} else {
			txId = txId.trim();
		}

		return bufferDocumentRepository.serachPage(assetCode, vendorId, accountNumber, jobId, txId,status, page);
	}
}
