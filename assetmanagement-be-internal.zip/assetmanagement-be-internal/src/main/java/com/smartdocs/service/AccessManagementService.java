package com.smartdocs.service;

import java.time.ZonedDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;


import org.apache.commons.lang3.StringUtils;
import org.json.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartdocs.dto.AccessManagementDto;
import com.smartdocs.dto.AppAccessDto;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.JwtResponse;
import com.smartdocs.exception.AccountNotExistException;
import com.smartdocs.model.AccessManagement;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.mongo.collectionhelpers.Permission;
import com.smartdocs.mongo.collections.User;
import com.smartdocs.mongo.repository.UserRepository;
import com.smartdocs.repository.AccessManagementRepository;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.security.jwt.JwtProvider;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.EncryptionDecryption;
import com.smartdocs.service.util.HttpReqRespUtils;

@Service
public class AccessManagementService {

	@Autowired
	private AccessManagementRepository accessManagementRepository;

	@Autowired
	private JwtProvider jwtProvider;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AssetAccountRepository assetAccountRepository;
	
	@Autowired
	private AuthProfileService authProfileService;


	private Random rand = new Random();

	public JsonResponse createAppAccess(UserPrincipal logedInUser, AccessManagementDto accessManagementDto) {

		if (logedInUser != null && accessManagementDto != null) {
			AccessManagement accessManagement = new AccessManagement();
			accessManagement.setAppName(accessManagementDto.getAppName());
			accessManagement.setAppId(UUID.randomUUID().toString());
			accessManagement.setAppSecret(getRandomHexString(50));
			accessManagement.setCreatedDate(ZonedDateTime.now());
			accessManagement.setUserEmail(logedInUser.getEmail());
			accessManagementRepository.save(accessManagement);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "App Access is save sucessfully ",
					JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "App Access is null ", JsonResponse.STATUS_500);
		}
	}

	private String getRandomHexString(int numchars) {

		StringBuffer sb = new StringBuffer();
		while (sb.length() < numchars) {
			sb.append(Integer.toHexString(rand.nextInt()));
		}
		return sb.toString().substring(0, numchars);
	}

	@Transactional
	public JsonResponse revokeAppAccess(String appId, UserPrincipal logedInUser) {
		Optional<AccessManagement> existAccessManagement = accessManagementRepository
				.findOneByAppIdIgnoreCaseAndUserEmail(appId, logedInUser.getEmail());
		if (existAccessManagement.isPresent()) {
			accessManagementRepository.deleteById(existAccessManagement.get().getId());
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Sucessfully deleted ", JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't delete from " + appId, JsonResponse.STATUS_500);
		}
	}

	public List<AccessManagement> getListOfAppAccess(UserPrincipal logedInUser) {
		return accessManagementRepository.findByUserEmail(logedInUser.getEmail());
	}

	public JsonResponse getAppAccessDetails(Long id, UserPrincipal logedInUser) {
		Optional<AccessManagement> existAccessManagement = accessManagementRepository.findByIdAndUserEmail(id,
				logedInUser.getEmail());
		if (existAccessManagement.isPresent()) {
			return new JsonResponse(existAccessManagement.get(), JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't Find from " + id, JsonResponse.STATUS_500);
		}
	}

	public ResponseEntity<JwtResponse> authenticatitaion(AppAccessDto appAccessDto) throws BadCredentialsException {
		try {
			String jwt = "";
			Optional<AccessManagement> accessManagement = accessManagementRepository
					.findByAppIdAndAppSecret(appAccessDto.getAppId(), appAccessDto.getAppSecret());
			if (accessManagement.isPresent()) {
				User existuser = userRepository.findByEmailIgnoreCase(accessManagement.get().getUserEmail()).get();
				Map<String,Permission> pg= null;
				 if(existuser.getRole().equals("CompanyUser")) {
					 pg= authProfileService.getAllPermissionGroups(existuser);
				}
				 
				UserPrincipal userPrincipal = UserPrincipal.build(existuser,pg);
				jwt = jwtProvider.generateJwtToken(userPrincipal,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist());
				accessManagement.get().setLastAccessed(ZonedDateTime.now());
				accessManagementRepository.save(accessManagement.get());

				if (existuser.getInvalidPasswordAttempts() > 0) {
					existuser.setInvalidPasswordAttempts(0);
				}
				existuser.setAppAccessToken(jwt);
				existuser.setLastLogin(ZonedDateTime.now());
				existuser.setLastActivity(ZonedDateTime.now());
				userRepository.save(existuser);
				return ResponseEntity.ok(new JwtResponse(jwt, userPrincipal, JwtResponse.LOGIN_BASIC_UP));
			}
			return ResponseEntity.ok(new JwtResponse(jwt, null, JwtResponse.LOGIN_BASIC_UP));
		}

		catch (BadCredentialsException ex) {
			Optional<AccessManagement> accessManagement = accessManagementRepository
					.findByAppIdAndAppSecret(appAccessDto.getAppId(), appAccessDto.getAppSecret());
			if (accessManagement.isPresent()) {
				Optional<User> user = userRepository.findByEmailIgnoreCase(appAccessDto.getAppId());
				System.out.println(user.get().getEmail());
				if (user.isPresent()) {
					user.get().addInvalidPasswordAttempt();
					userRepository.save(user.get());
					throw new BadCredentialsException(
							"INCORRECT_LOGIN_DETAIL___" + (7 - user.get().getInvalidPasswordAttempts()));
				} else {
					throw new BadCredentialsException("INCORRECT_LOGIN_DETAIL");
				}
			} else {
				throw new BadCredentialsException("INCORRECT_App_DETAIL");
			}
		}
	}

	@Deprecated
	public boolean giveExceptions(String vendorId) throws AccountNotExistException {
		boolean assetAccountOrVendorScriptExists = assetAccountRepository
				.isAssetAccountOrVendorScriptExistsforVendor(vendorId, AssetAccount.CHANNEL_AUTOPILOT);
		if (assetAccountOrVendorScriptExists) {
			return assetAccountOrVendorScriptExists;
		} else {
			throw new AccountNotExistException("Asset Account did not exists for this vendor");
		}

	}

	@Deprecated
	public String validateToken(String reqToken) {
		String emcrypt = new EncryptionDecryption().encrypt(reqToken);
		String decryptToken = EncryptionDecryption.decrypt(emcrypt);
		String jwt = "";
		if (decryptToken != null && jwtProvider.validateJwtToken(decryptToken,
				HttpReqRespUtils.getClientIpAddressIfServletRequestExist())) {
			String[] split = StringUtils.split(decryptToken, '.');
			String splitToken = split[1];
			byte[] bytes = Base64.getDecoder().decode(splitToken);
			String str = new String(bytes);
			JSONObject jsonObject = new JSONObject(str);
			String email = jsonObject.getString("email");
			Optional<User> existuser = userRepository.findByEmailIgnoreCase(email);
			if (existuser.isPresent()) {
				Map<String,Permission> pg= null;
				 if(existuser.get().getRole().equals("CompanyUser")) {
					 pg= authProfileService.getAllPermissionGroups(existuser.get());
				}
				UserPrincipal userPrincipal = UserPrincipal.build(existuser.get(),pg);
				jwt = jwtProvider.generateJwtToken(userPrincipal,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist());
				existuser.get().setAppAccessToken(jwt);
				existuser.get().setLastLogin(ZonedDateTime.now());
				existuser.get().setLastActivity(ZonedDateTime.now());
				userRepository.save(existuser.get());
			}
		}
		return jwt;
	}
}
