package com.smartdocs.service;

import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.AssetAccountDetails;
import com.smartdocs.dto.AssetAccountExcelRow;
import com.smartdocs.dto.AssetGeoData;
import com.smartdocs.dto.AssetVendorDto;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.UtilAssetDto;
import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.AssetType;
import com.smartdocs.model.JobConfigModel;
import com.smartdocs.model.Manager;
import com.smartdocs.model.Robot;
import com.smartdocs.model.Vault;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.VendorScript;
import com.smartdocs.model.dto.AssetDto;
import com.smartdocs.model.group.AssetData;
import com.smartdocs.model.group.AssetRequireData;
import com.smartdocs.model.log.ApplicationLog;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.ApplicationLogRepository;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.repository.AssetRepository;
import com.smartdocs.repository.AssetTypeRepository;
import com.smartdocs.repository.ManagerRepository;
import com.smartdocs.repository.RobotRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.VaultRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.repository.VendorScriptRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.Constants;
import com.smartdocs.service.util.ExcelToJsonService;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.service.util.HttpReqRespUtils;
import com.smartdocs.service.util.JKUtil;
import com.smartdocs.sql.dto.AssetCustom;
import com.smartdocs.sql.dto.AssetCustomInf;
import com.smartdocs.sql.dto.AssetDataInf;

@Service
public class AssetService {

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	private RobotRepository robotRepository;

	@Autowired
	private AssetAccountRepository assetAccountRepository;

	@Autowired
	private VendorScriptRepository vendorScriptRepository;

	@Autowired
	private AssetTypeRepository assetTypeRepository;

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private JenkinsService1 jenkinsService1;

	@Autowired
	private JenkinsService2 jenkinsService2;

	@Autowired
	private VaultRepository vaultRepository;

	@Autowired
	private ManagerRepository managerRepository;

	@Autowired
	private SystemLogsRepository systemLogsRepository;

	@Autowired
	private ApplicationLogRepository applicationLogRepository;

	@Autowired
	private ExcelToJsonService excelToJsonService;

	@Autowired
	private JobConfigService jobConfigService;

	public JsonResponse createAsset(AssetDto assetDto) throws DataIntegrityViolationException {

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		Asset asset = new Asset();
		BeanUtils.copyProperties(assetDto, asset);
		asset.setCreatedDate(ZonedDateTime.now());
		asset.setLastUpdated(ZonedDateTime.now());
		if (assetDto.getAccounts() != null && !assetDto.getAccounts().isEmpty()) {
			asset.setAccounts(new ArrayList<AssetAccount>());
			addAssetAccountToAsset(assetDto, asset);
		}
		if (assetDto.getManagers() != null) {
			asset.setManagersIds(assetDto.getManagers().stream().map(this::createManager)
					.collect(Collectors.toList()));
		}
		try {
			 this.assetRepository.save(asset);
//			createRobot(asset);

			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_ASSET_CREATION, user.getEmail(), user.getName(), null, null,
					user.getName() + " Asset created successfully", "", "AssetRestAPIs:createAsset()", "/asset",
					user.getRole()));

			return new JsonResponse(JsonResponse.STATUS_200, "Asset create successfully ", JsonResponse.STATUS_200);
		} catch (DataIntegrityViolationException e) {

			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_ASSET_CREATION, user.getEmail(), user.getName(), null, null,
					user.getName() + "Asset Code " + assetDto.getAssetCode() + " is duplicate", "",
					"AssetRestAPIs:createAsset()", "/asset", user.getRole()));

			throw new DataIntegrityViolationException("Asset Code " + assetDto.getAssetCode() + " is duplicate");
		}
	}

	private long createManager(Manager manager) {
		Manager managerDetails=new Manager();
		Optional<Manager> existManager = managerRepository.findOneByEmailIgnoreCase(manager.getEmail());
		if (existManager.isEmpty()) {
			//manager.setId(manager);
			managerDetails=managerRepository.save(manager);
			return managerDetails.getId();
		}
		return existManager.get().getId();
	}

//	private void createRobot(Asset asset) {
//		if (asset != null && asset.getAccounts() != null) {
//			for (AssetAccount assetAccount : asset.getAccounts()) {
//				if (AssetAccount.CHANNEL_AUTOPILOT.equals(assetAccount.getChannel())) {
//					Optional<Robot> eixstrobot = robotRepository.findById(asset.getAssetCode() + "-"
//							+ assetAccount.getVendorId() + "-" + assetAccount.getAccountNumber());
//					if (eixstrobot.isEmpty()) {
//						Robot robot = new Robot();
//						robot.setAccountNo(assetAccount.getAccountNumber());
//						robot.setAssetCode(assetAccount.getAssetCode());
//						robot.setVendorId(assetAccount.getVendorId());
//						robot.setFrequency(assetAccount.getFrequency());
//						robot.setStatus(Robot.STATUS_NEW);
//						robot.setId(asset.getAssetCode() + "-" + assetAccount.getVendorId() + "-"
//								+ assetAccount.getAccountNumber());
//						robot.setJobId(asset.getAssetCode() + "-" + assetAccount.getVendorId() + "-"
//								+ assetAccount.getAccountNumber());
//						robot.setLastUpdated(ZonedDateTime.now());
//						robotRepository.save(robot);
//					}
//				}
//			}
//		}
//	}

	public int createRobot(String assetCode, AssetAccount assetAccount) {
		if (AssetAccount.CHANNEL_AUTOPILOT.equals(assetAccount.getChannel())) {
			Optional<Robot> eixstrobot = robotRepository
					.findById(assetCode + "-" + assetAccount.getVendorId() + "-" + assetAccount.getAccountNumber());
			Vendor vendor = vendorRepository.findFirstByVendorId(assetAccount.getVendorId());
			if (eixstrobot.isEmpty()&&vendor!=null&&!vendor.isManualIntervention()) {
				Robot robot = new Robot();
				robot.setAccountNo(assetAccount.getAccountNumber());
				robot.setAssetCode(assetAccount.getAssetCode());
				robot.setVendorId(assetAccount.getVendorId());
				robot.setFrequency(assetAccount.getFrequency());
				robot.setStatus(Robot.STATUS_NEW);
				robot.setId(assetCode + "-" + assetAccount.getVendorId() + "-" + assetAccount.getAccountNumber());
				robot.setJobId(assetCode + "-" + assetAccount.getVendorId() + "-" + assetAccount.getAccountNumber());
				robot.setLastUpdated(ZonedDateTime.now());
				robotRepository.save(robot);
				return 1;
			}
			return 0;
		}
		return -1;
	}

	private void addAssetAccountToAsset(AssetDto assetDto, Asset asset) {
		List<AssetAccount> assetAccounts = new ArrayList<>();
		if (assetDto.getAccounts() != null && !assetDto.getAccounts().isEmpty()) {
			for (AssetAccount assetAccount : assetDto.getAccounts()) {
				assetAccount.setAssetCode(assetDto.getAssetCode());
				assetAccounts.add(assetAccount);
				createRobot(asset.getAssetCode(),assetAccount);
			}
			asset.setAccounts(assetAccounts);
		}
	}

	public JsonResponse updateAsset(AssetDto assetDto, Long id) {

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		Asset asset = new Asset();
		BeanUtils.copyProperties(assetDto, asset);
		Optional<Asset> exiAsset = assetRepository.findById(id);
		if (exiAsset.isPresent()) {
			asset.setId(exiAsset.get().getId());
			asset.setCreatedDate(exiAsset.get().getCreatedDate());
			asset.setLastUpdated(ZonedDateTime.now());
			if (assetDto.getAccounts() != null && !assetDto.getAccounts().isEmpty()) {
				asset.setAccounts(new ArrayList<AssetAccount>());
				addAssetAccountToAsset(assetDto, asset);
			}
			if (assetDto.getManagers() != null) {
				asset.setManagersIds(assetDto.getManagers().stream().map(this::createManager)
						.collect(Collectors.toList()));
			}
			assetRepository.save(asset);
//			createRobot(asset);

			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_ASSET_UPDATION, user.getEmail(), user.getName(), null, null,
					user.getName() + " Asset Updated successfully", "", "AssetRestAPIs:updateAsset()", "/asset/{id}",
					user.getRole()));

			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Updated successfully", JsonResponse.STATUS_200);
		}

		applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
				Constants.ACTIVITY_TYPE_ASSET_UPDATION, user.getEmail(), user.getName(), null, null,
				user.getName() + " Asset does not exist with " + id, "", "AssetRestAPIs:updateAsset()", "/asset/{id}",
				user.getRole()));

		return new JsonResponse(JsonResponse.RESULT_FAILED, "Asset does not exist with " + id, JsonResponse.STATUS_404);
	}

	public AssetAccountDetails findAssetCodeDetails(String assetCode, Boolean isDetail) {
		AssetRequireData asset = assetRepository.findAssetRequireDataByAssetCode(assetCode);
		AssetAccountDetails assetdto = new AssetAccountDetails();
		if (asset != null) {
			if (isDetail != null && isDetail.booleanValue()) {
				List<AssetCustomInf> test = assetRepository.findAssetAccountDeatils(assetCode);
				List<AssetCustom> assetCustomDtos = new ArrayList<>();
				for (AssetCustomInf assetCustomDtoInf : test) {
					AssetCustom assetCustomDto = new AssetCustom(assetCustomDtoInf);
					assetCustomDtos.add(assetCustomDto);
				}
				assetdto.setAccounts(assetCustomDtos);
				assetdto.setAsset(asset);
				List<Manager> managers = managerRepository.findManagersByAssetId(asset.getId());
				assetdto.setManagers(managers);
			} else {
				assetdto.setAsset(asset);
			}
		}
		return assetdto;
	}

	public List<AssetGeoData> getGeoAssetList() {
		List<Asset> assets = assetRepository.findAll();
		List<AssetGeoData> geoDatas = new ArrayList<>();
		for (Asset asset : assets) {
			AssetGeoData geoData = new AssetGeoData();
			geoData.setAddress(asset.getAddress());
			geoData.setId(asset.getId());
			geoData.setAssetCode(asset.getAssetCode());
			geoData.setLatitude(asset.getLatitude());
			geoData.setLongitude(asset.getLongitude());
			geoData.setAssetName(asset.getName());
			geoDatas.add(geoData);
		}
		return geoDatas;
	}

	public Page<AssetVendorDto> getUitlityVendors(String assetCode, String frquency, String channel, String vendorId,
			String accountNumber, String utilityType, String order, int pageIndex, int size) {
		Pageable sortPageRequest = GeneralUtil.getSortPageRequest(order, pageIndex, size);
		return assetRepository.fetchAssetAccountDetails(assetCode, frquency, channel, vendorId, accountNumber,
				utilityType, sortPageRequest).map(this::setCustomData);
	}

	public AssetVendorDto setCustomData(AssetData assetData) {
		return new AssetVendorDto(assetData);
	}

	public UtilAssetDto getAssetTypeCount() {
		UtilAssetDto assetDto = new UtilAssetDto();
		assetDto.setTotalAssets(assetRepository.count());
		assetDto.setMapList(assetRepository.getAssetTypeCount());
		return assetDto;
	}

	public List<Map<String, Object>> getAssetDetails(String vendorId) {
		List<AssetAccount> assetAccounts = assetAccountRepository.findByVendorId(vendorId);
		return assetAccounts.stream().map(this::setAccountAccountData).collect(Collectors.toList());
	}

	private Map<String, Object> setAccountAccountData(AssetAccount assetAccount) {
		JSONObject jsonObject = new JSONObject();
		Optional<Asset> existAsset = assetRepository.findOneByAssetCode(assetAccount.getAssetCode());
		if (existAsset.isPresent()) {
			jsonObject.put("assetName", existAsset.get().getName());
			jsonObject.put("assetType", existAsset.get().getAssetType());
			jsonObject.put("assetCode", existAsset.get().getAssetCode());
			jsonObject.put("assetId", existAsset.get().getId());
		}
		jsonObject.put("accountNo", assetAccount.getAccountNumber());
		jsonObject.put("channel", assetAccount.getChannel());
		jsonObject.put("frequency", assetAccount.getFrequency());
		return jsonObject.toMap();
	}

	public Page<Asset> findByAssetCodeAndAssetName(String query, int page, int size) {
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {

			query = query.trim();
		}
		return assetRepository.findAssetByAssetCodeOrAssetName(query, PageRequest.of(page, size));
	}

	public List<Vendor> getVendorsFromAsset(String assetCode) {
		return assetRepository.findVendorsByAssetCode(assetCode);
	}

	public void deleteAsset(Long id) {
		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		String txId = UUID.randomUUID().toString();
		JsonResponse jsonResponse = null;
		Optional<Asset> existAsset = assetRepository.findById(id);
		if (existAsset.isPresent()) {
			for (AssetAccount assetAccount : existAsset.get().getAccounts()) {
				jsonResponse = unPublishAssetAccount(assetAccount, txId);
				if (jsonResponse.getStatusCode().equals(JsonResponse.STATUS_200)) {
					robotRepository.deleteById(existAsset.get().getAssetCode() + "-" + assetAccount.getVendorId() + "-"
							+ assetAccount.getAccountNumber());
				}
			}

			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_ASSET_DELETION, user.getEmail(), user.getName(), null, null,
					user.getName() + " Asset is Deleted Successfully", "", "AssetRestAPIs:deleteAsset()", "/asset/{id}",
					user.getRole()));

			this.assetRepository.deleteById(id);
		}
	}

	public Set<String> getListOfAssetTypeFromAsset() {
		return assetRepository.getDistinctAssetTypes();
	}

	// -------------------------------Asset Type CRUD ------------------------//

	public JsonResponse createAssetType(AssetType assetType) {
		if (assetType != null && assetType.getName() != "" && assetType.getName() != null) {
			Optional<AssetType> existassetType = assetTypeRepository.findOneByNameIgnoreCase(assetType.getName());
			if (existassetType.isPresent()) {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Asset Type is already exist",
						JsonResponse.STATUS_400);
			}
			return new JsonResponse(assetTypeRepository.save(assetType), JsonResponse.RESULT_SUCCESS,
					"New Asset type created", JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "AssetType or Asset Type name is empty",
					JsonResponse.STATUS_400);

		}

	}

	public JsonResponse getAssetType(String name) {
		Optional<AssetType> existassetType = assetTypeRepository.findOneByNameIgnoreCase(name);
		if (existassetType.isPresent()) {
			return new JsonResponse(existassetType.get(), JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't get Asset Type from " + name,
					JsonResponse.STATUS_404);
		}
	}

	public List<AssetType> getAssetTypeList() {
		return assetTypeRepository.findAll();
	}

	public Page<AssetType> getAssetTypePage(String query, int pageIndex, int size, String orderBy) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		try {
			return assetTypeRepository.getPage(query, page);
		} catch (Exception e) {
			page = PageRequest.of(pageIndex, size);
			return assetTypeRepository.getPage(query, page);
		}
	}

	@Transactional
	public JsonResponse deleteAssetType(String name) {
		Optional<AssetType> existassetType = assetTypeRepository.findOneByNameIgnoreCase(name);
		if (existassetType.isPresent()) {
			assetTypeRepository.deleteByNameIgnoreCase(name);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Sucessfully deleted " + name,
					JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't get Asset Type from " + name,
					JsonResponse.STATUS_404);
		}
	}

	public JsonResponse updateAssetType(AssetType assetType) {
		if (assetType != null && assetType.getName().equals("") && assetType.getName() != null) {
			Optional<AssetType> existassetType = assetTypeRepository.findOneByNameIgnoreCase(assetType.getName());
			if (existassetType.isPresent()) {
				existassetType.get().setName(existassetType.get().getName());
				existassetType.get().setDescription(assetType.getDescription());
				return new JsonResponse(assetTypeRepository.save(existassetType.get()), JsonResponse.RESULT_SUCCESS,
						"Update sucessfully", JsonResponse.STATUS_200);
			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, " Asset Type name can't update",
						JsonResponse.STATUS_404);
			}
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Asset type or Asset type name is null or empty",
					JsonResponse.STATUS_404);
		}
	}

	// ----------------------- Jenkins --------------------- //
	public JsonResponse publishAsset(String assetCode, String accountNo) {

		JobConfigModel jcm = jobConfigService.getJobConfig();
		// String txId = UUID.randomUUID().toString();
		JsonResponse response = new JsonResponse();
		Optional<Asset> existasset = assetRepository.findOneByAssetCode(assetCode);
		if (existasset.isPresent()) {
			List<AssetAccount> assetAccounts = assetAccountRepository
					.findAllByAssetCodeAndAccountNumber(existasset.get().getAssetCode(), accountNo);
			if (assetAccounts != null && !assetAccounts.isEmpty()) {
				for (AssetAccount assetAccount : assetAccounts) {
					response = publishAssetAccount(jcm, assetAccount);
				}
			}
		} else {
			response = new JsonResponse(JsonResponse.RESULT_FAILED, "Incorrect Asset Code ", JsonResponse.STATUS_404);
		}
		return response;
	}

	private JsonResponse publishAssetAccount(JobConfigModel config, AssetAccount assetAccount) {

		String txId = UUID.randomUUID().toString();
		JsonResponse response = null;
		
		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		System.out.println("assetAccount.getAcccode:" + assetAccount.getAccountNumber());
		VendorScript vendorScript = vendorScriptRepository.findByVendorId(assetAccount.getVendorId());

		String id = assetAccount.getAssetCode() + "-" + assetAccount.getVendorId() + "-"
				+ assetAccount.getAccountNumber();
		Optional<Robot> rbot = robotRepository.findById(id);

		String fileName =JKUtil.getScriptFileName(assetAccount);

		Robot robot = null;
		if (rbot.isPresent()) {
			robot = rbot.get();
		} else {
			robot = new Robot(assetAccount);
		}
		if (vendorScript != null) {
			if ((jenkinsService1.createFileToFTP(txId, assetAccount, fileName, id, vendorScript))
					&& (jenkinsService2.createFileToFTP(txId, assetAccount, fileName, id, vendorScript))) {
				robot.setScriptVersion(vendorScript.getVersion());
				try {
					if ((jenkinsService1.createUpdateJob(config,robot, txId, assetAccount, id, "", fileName))
							&& (jenkinsService2.createUpdateJob(txId, assetAccount, id, "", fileName))) {
						robot.setStatus(Robot.STATUS_PUBLISHED);
						robot.setJobId(id);
						response = new JsonResponse(JsonResponse.RESULT_SUCCESS, "Successfully Published ",
								JsonResponse.STATUS_200);
					} else {
						response = new JsonResponse(JsonResponse.RESULT_FAILED, "Error Jenkins: Job updation failed ",
								JsonResponse.STATUS_500);
						System.out.println("Error Jenkins: Job updation failed");
					}
				} catch (TransformerConfigurationException e) {
					response = new JsonResponse(JsonResponse.RESULT_FAILED, "Error: " + e.getMessage(),
							JsonResponse.STATUS_500);
					e.printStackTrace();
				} catch (ParserConfigurationException e) {
					response = new JsonResponse(JsonResponse.RESULT_FAILED, "Error: " + e.getMessage(),
							JsonResponse.STATUS_500);
					e.printStackTrace();
				}
			} else {
				System.out.println("FTP Script failed");
				response = new JsonResponse(JsonResponse.RESULT_FAILED, "FTP Script failed ", JsonResponse.STATUS_500);
			}
		} else {

			SystemLogs systemLogs = new SystemLogs("publish api", "Vendor Script not available", ZonedDateTime.now(),
					txId, SystemLogs.SYSTEM_TYPE_AUTOPILOT, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_AP,
					user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
					assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					user.getName());

			systemLogsRepository.save(systemLogs);
			response = new JsonResponse(JsonResponse.RESULT_FAILED, "Vendor Script not available ",
					JsonResponse.STATUS_404);
		}
		robotRepository.save(robot);
		return response;

	}

	private JsonResponse unPublishAssetAccount(AssetAccount assetAccount, String txtId) {
		JsonResponse response = null;

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		System.out.println("assetAccount.getAcccode:" + assetAccount.getAccountNumber());
		VendorScript vendorScript = vendorScriptRepository.findByVendorId(assetAccount.getVendorId());

		String id = assetAccount.getAssetCode() + "-" + assetAccount.getVendorId() + "-"
				+ assetAccount.getAccountNumber();
		Optional<Robot> rbot = robotRepository.findById(id);


		Robot robot = null;
		if (rbot.isPresent()) {
			robot = rbot.get();
		} else {
			robot = new Robot(assetAccount);
		}
		if (vendorScript != null) {

			
			 
				try {
					if ((jenkinsService1.deleteJenkinsJob(txtId, assetAccount, id))
							&& (jenkinsService2.deleteJenkinsJob(txtId, assetAccount, id))) {
						
						robot.setStatus(Robot.STATUS_PAUSED);
						robot.setJenkinsCommand(null);
						robot.setSchedule(false);
						robotRepository.save(robot);
						response = new JsonResponse(JsonResponse.RESULT_SUCCESS, "Successfully Paused ",
								JsonResponse.STATUS_200);
					} else {
						response = new JsonResponse(JsonResponse.RESULT_FAILED,
								"Error Jenkins: Job Unpublished failed ", JsonResponse.STATUS_500);
						System.out.println("Error Jenkins: Job Unpublished failed");
					}
				} catch (Exception e) {
					response = new JsonResponse(JsonResponse.RESULT_FAILED, "Error: " + e.getMessage(),
							JsonResponse.STATUS_500);
					e.printStackTrace();
				}
			
		} else {

			SystemLogs systemLogs = new SystemLogs("unPublish api", "Vendor Script not available", ZonedDateTime.now(),
					txtId, SystemLogs.SYSTEM_TYPE_AUTOPILOT, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_AP,
					user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
					assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					user.getName());

			systemLogsRepository.save(systemLogs);
			response = new JsonResponse(JsonResponse.RESULT_FAILED, "Vendor Script not available ",
					JsonResponse.STATUS_404);
		}

		return response;

	}

	public JsonResponse unPublishAsset(String assetId, String accountId, String txtId) {
		JsonResponse response = new JsonResponse();
		Optional<Asset> existasset = assetRepository.findOneByAssetCode(assetId);
		if (existasset.isPresent()) {
			List<AssetAccount> assetAccounts = assetAccountRepository
					.findAllByAssetCodeAndAccountNumber(existasset.get().getAssetCode(), accountId);
			if (assetAccounts != null && assetAccounts.size() > 0) {
				for (AssetAccount assetAccount : assetAccounts) {
					response = unPublishAssetAccount(assetAccount, txtId);
				}
			}
		} else {
			response = new JsonResponse(JsonResponse.RESULT_FAILED, "Incorrect Asset Code ", JsonResponse.STATUS_404);
		}
		return response;
	}

	
	public JsonResponse processAssetAccountUpload(InputStream inputStream) {
		try {
			List<AssetAccountExcelRow> assetRows = excelToJsonService.convertAssetAccountDataToJson(inputStream, 0);
			if (assetRows != null) {
				for (AssetAccountExcelRow row : assetRows) {
					createAssetAccount(row);
				}
			}
			return new JsonResponse(assetRows, JsonResponse.RESULT_SUCCESS, "Uploaded Success.",
					JsonResponse.STATUS_200);
		} catch (Exception ex) {
			System.out.println("Ex:" + ex.getMessage());
			ex.printStackTrace();
			return new JsonResponse("", JsonResponse.RESULT_FAILED, "Ex:" + ex.getMessage(), JsonResponse.STATUS_500);
		}
	}

	private AssetAccountExcelRow createAssetAccount(AssetAccountExcelRow row) {
		Optional<Asset> asset = assetRepository.findOneByAssetCode(row.getAssetCode());
		Optional<Vendor> vendor = vendorRepository.findOneByVendorId(row.getVendorId());

		if (asset.isPresent() && vendor.isPresent()) {
			Vault vault = vaultRepository.findOneByName(row.getVault());
			boolean isExist = false;
			if (asset.get().getAccounts() != null && asset.get().getAccounts().size() > 0) {
				for (AssetAccount account : asset.get().getAccounts()) {
					if (account.getAccountNumber().equalsIgnoreCase(row.getAccountNo())) {
						isExist = true;
						break;
					}
				}
			}
			if (!isExist) {
				// if account is null then initialize.
				if (asset.get().getAccounts() == null) {
					asset.get().setAccounts(new ArrayList<>());
				}
				// Add Asset Account and save.
				AssetAccount account = new AssetAccount(row, vault == null ? null : vault.getId());
				asset.get().getAccounts().add(account);

				assetRepository.save(asset.get());
				row.setStatus("SUCCESS");

				int bot_status = createRobot(row.getAssetCode(), account);
				row.setMessage("Asset Account Successfully Created." + bot_status);
			} else {
				row.setStatus("WARNING");
				row.setMessage("Asset Account already present.");
			}
			if (vault == null) {
				row.setMessage("Invalid Vault");
				row.setStatus("WARNING");
			}
		} else {
			row.setStatus("ERROR");
			if (asset.isEmpty()) {
				row.setMessage("Invalid AssetId");
			} else if (vendor.isEmpty()) {
				row.setMessage("Invalid Vendor Id");
			}
		}
		return row;
	}

	public List<Map<String, Integer>> getAssetNameByAssetCodeOrName(String query) {
		return assetRepository.findAssetNameByAssetCodeOrName(query);
	}

	public Page<AssetDataInf> getAssetPage(String vendorQuery, String assetType, String assetQuery, int page, int limit,
			String order) {
		if (StringUtils.isBlank(assetType)) {
			assetType = null;
		} else {
			assetType = assetType.trim();
		}
		if (StringUtils.isBlank(assetQuery)) {
			assetQuery = null;
		} else {
			assetQuery = assetQuery.trim();
		}
		if (StringUtils.isBlank(assetType)) {
			assetType = null;
		} else {
			assetType = assetType.trim();
		}
		return assetRepository.findAssetsByNativeQuery(vendorQuery, assetType, assetQuery,
				GeneralUtil.getSortPageRequest(order, page, limit));
	}

	public long getTotalAssets() {
		return assetRepository.count();
	}
	
	

}
