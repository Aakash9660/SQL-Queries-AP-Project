package com.smartdocs.service.util;

public class Constants {

	public static final String ACTIVITY_TYPE_USER_SIGNIN="SignIn";
	public static final String ACTIVITY_TYPE_DELETION="Deletion";
	public static final String ACTIVITY_TYPE_ASSET_CREATION="Asset Creation";
	public static final String ACTIVITY_TYPE_ASSET_UPDATION="Asset Updation";
	public static final String ACTIVITY_TYPE_ASSET_DELETION="Asset Deletion";
	public static final String ACTIVITY_TYPE_CREATE_VENDOR_SCRIPT="Vendor Script Creation";
	public static final String ACTIVITY_TYPE_UPLOAD_VENDOR_SCRIPT="Vendor Script Upload";
	public static final String ACTIVITY_TYPE_UPDATE_VENDOR_SCRIPT="Vendor Script Updation";
	public static final String ACTIVITY_TYPE_DELETE_VENDOR_SCRIPT="Vendor Script Deletion";
	public static final String ACTIVITY_TYPE_VAULT_CREATION="Vault Creation";
	public static final String ACTIVITY_TYPE_VAULT_UPDATION="Vault Updation";
	public static final String ACTIVITY_TYPE_VAULT_DELETION="Vault Deletion";

	public static final String ACTIVITY_TYPE_MANAGER_UPDATION="Manager Updation";
	public static final String ACTIVITY_TYPE_MANAGER_DELETION="Manager Deletion";
	
	public static final String STATUS_DRAFT="DRAFT";
	public static final String STATUS_NEW="NEW";
	
	public static final String STATUS_ACTIVE="Active";
	public static final String STATUS_INACTIVE="In Active";
	
	
	public static final String ACTIVITY_SUBMIT="Submit";
	
	public static final String DATE_FORMAT = "yyyy-MM-dd";

}
