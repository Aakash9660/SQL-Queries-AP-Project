package com.smartdocs.service;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.CostCenter;
import com.smartdocs.model.dto.CostCenterDto;
import com.smartdocs.repository.CostCenterRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class CostCenterService {

	@Autowired
	private CostCenterRepository costCenterRepository;

	public JsonResponse createCostCenter(CostCenter costCenter) {
			costCenterRepository.save(costCenter);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Cost center save successfully", JsonResponse.STATUS_200);
	}

	public JsonResponse updateCostCenter(CostCenterDto costCenterDto, String id) {
		CostCenter costCenter = new CostCenter();
		BeanUtils.copyProperties(costCenterDto, costCenter);
		Optional<CostCenter> existCostCen = this.costCenterRepository.findById(id);
		if (existCostCen.isPresent()) {
			costCenter.setId(existCostCen.get().getId());
			costCenterRepository.save(costCenter);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS,
					"Updated successfully", JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Costcenter does not exist with " + id,
				JsonResponse.STATUS_404);
	}

	public CostCenter getCostCenter(String id) {
		Optional<CostCenter> costCenter = costCenterRepository.findById(id);
		if (costCenter.isPresent()) {
			return costCenter.get();
		} else {
			return null;
		}
	}

	public JsonResponse deleteCostCenter(String id) {
		Optional<CostCenter> existCostCen = this.costCenterRepository.findById(id);
		if (existCostCen.isPresent()) {
			costCenterRepository.delete(existCostCen.get());
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Cost center deleted ", JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Cost center can't deleted", JsonResponse.STATUS_400);
		}
	}

	public Page<CostCenter> getCostCenterPage(String query, String orderBy, int pageIndex, int size) {
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		return this.costCenterRepository.getCostCenterPage(query, page);
	}

	public void saveAllCostCenter(List<CostCenter> costCenters) {
		this.costCenterRepository.saveAll(costCenters);
	}
}
