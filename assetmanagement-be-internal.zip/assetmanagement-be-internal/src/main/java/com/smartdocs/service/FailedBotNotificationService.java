package com.smartdocs.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.smartdocs.model.RobotLog;
import com.smartdocs.mongo.collections.PermissionGroup;
import com.smartdocs.mongo.collections.User;
import com.smartdocs.mongo.repository.PermissionGroupDao;
import com.smartdocs.mongo.repository.UserRepository;

@Service
public class FailedBotNotificationService {
	
	@Autowired
	private SendEmailService sendEmailService;
	
	
	@Autowired
	private UserRepository userRepository;
	

	@Autowired
	private PermissionGroupDao permissionGroupDao;
	
	@Async
	public void sendL1FailedBotNotification(RobotLog botLog) {
		System.out.println("sendL1FailedBotNotification");
		
		List<PermissionGroup> permissions= permissionGroupDao.findEditPermissions("AP_FailedBotL1");
		List<String> permissionss=null;
		if(permissions!=null && permissions.size()>0) {
			permissionss=new ArrayList<String>();
			for(PermissionGroup  permission:permissions) {
				permissionss.add(permission.getGroupId());
			}
		}
		System.out.println("L1 Permissions "+permissionss);
		
		
		//1. get list of Roles from permission group.
		List<User> users=userRepository.findAllByAuthPermissionGroupsIn(permissionss);
		if(users!=null) {
			System.out.println("Users not null..."+users.size());
			for(User user:users) {
				sendEmailService.sendL1ReviewNotification(user.getName(), Arrays.asList(user.getEmail()),
						botLog.getAssetCode(),botLog.getVendorId(),botLog.getAccountNo(),botLog.getComments()
						);
			}
		}
		else {
			System.out.println("No User found.");
		}
	}
	
	@Async
	public void sendL1FailedBotNotification(RobotLog botLog,List<User> users) {
		System.out.println("sendL1FailedBotNotification");
		if(users!=null) {
			System.out.println("Users not null..."+users.size());
			for(User user:users) {
				sendEmailService.sendL1ReviewNotification(user.getName(), Arrays.asList(user.getEmail()),
						botLog.getAssetCode(),botLog.getVendorId(),botLog.getAccountNo(),botLog.getComments()
						);
			}
		}
		else {
			System.out.println("No User found.");
		}
	}
	
	@Async
	public void sendL2FailedBotNotification(RobotLog botLog) {
		//1. get list of Roles from permission group.
		List<PermissionGroup> permissions= permissionGroupDao.findEditPermissions("AP_FailedBotL2");
		List<String> permissionss=null;
		if(permissions!=null && permissions.size()>0) {
			permissionss=new ArrayList<String>();
			for(PermissionGroup  permission:permissions) {
				permissionss.add(permission.getGroupId());
			}
		}
		System.out.println("L2 Permissions "+permissionss);
		List<User> users=userRepository.findAllByAuthPermissionGroupsIn(permissionss);
		if(users!=null) {
			for(User user:users) {
				sendEmailService.sendL2ReviewNotification(user.getName(), Arrays.asList(user.getEmail()),
						botLog.getAssetCode(),botLog.getVendorId(),botLog.getAccountNo(),botLog.getComments()
						);
			}
		}
		else {
			System.out.println("No User found.");
		}
	}
}
