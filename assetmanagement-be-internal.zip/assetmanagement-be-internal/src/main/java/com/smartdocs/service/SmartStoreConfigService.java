package com.smartdocs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.JobConfigModel;
import com.smartdocs.model.SmartStoreConfigurator;
import com.smartdocs.model.dto.SmartStoreConfiguratorDTO;
import com.smartdocs.repository.SmartStoreConfiguratorRepository;

@Service
public class SmartStoreConfigService {
	
	@Autowired
	private SmartStoreConfiguratorRepository smartStoreConfiguratorRepository;
	
	public List<SmartStoreConfigurator> getSmartStoreConfig() {
		return smartStoreConfiguratorRepository.findAll();
	}
	
	public JsonResponse updateSmartStoreConfig(SmartStoreConfigurator smartStoreConfigurator) {
		
		if(smartStoreConfigurator!=null) {
			smartStoreConfigurator.setId(1L);
			smartStoreConfiguratorRepository.save(smartStoreConfigurator);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Smart Store Config Updated", JsonResponse.STATUS_200);
		}else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Smart Store Config Details Doesn't Exist", JsonResponse.STATUS_404);
		}
	}

	public JsonResponse deleteSmartStoreConfig(Long id) {
		smartStoreConfiguratorRepository.deleteById(id);
		return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Smart Store Configuration deleted Successfully",
				JsonResponse.STATUS_200);
	}

	public JsonResponse addSmartStoreConfig(SmartStoreConfiguratorDTO smartStoreConfiguratorDTO) {
		SmartStoreConfigurator smartStoreConfigurator = new SmartStoreConfigurator();
		BeanUtils.copyProperties(smartStoreConfiguratorDTO, smartStoreConfigurator);
		smartStoreConfiguratorRepository.save(smartStoreConfigurator);
		return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Smart Store Configuration added Successfully",
				JsonResponse.STATUS_200);
	}

	public SmartStoreConfigurator findSmartStoreConfigById() {
		Optional<SmartStoreConfigurator> smartStoreConfigurator=smartStoreConfiguratorRepository.findById(1L);
		if(smartStoreConfigurator.isPresent()) {
			return smartStoreConfigurator.get();
		}else {
			return null;
		}
	}

}
