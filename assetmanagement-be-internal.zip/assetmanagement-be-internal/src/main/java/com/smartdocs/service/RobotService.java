package com.smartdocs.service;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.BillDocumentRequest;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.RobotCustomData;
import com.smartdocs.dto.RobotReportDto;
import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.BillDocument;
import com.smartdocs.model.JobConfigModel;
import com.smartdocs.model.Robot;
import com.smartdocs.model.VendorScript;
import com.smartdocs.model.group.RobotData;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.repository.AssetRepository;
import com.smartdocs.repository.BillDocumentRepository;
import com.smartdocs.repository.JobConfigRepository;
import com.smartdocs.repository.RobotRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.repository.VendorScriptRepository;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.service.util.HttpReqRespUtils;
import com.smartdocs.service.util.JKUtil;
import com.smartdocs.sql.dto.RobotInf;

@Service
public class RobotService {

	@Autowired
	private RobotRepository robotRepository;

	@Autowired
	private VendorScriptRepository vendorScriptRepository;

	@Autowired
	private JenkinsService1 jenkinsService1;

	@Autowired
	private JenkinsService2 jenkinsService2;

	@Autowired
	private SystemLogsRepository systemLogsRepository;

	@Autowired
	private JobConfigRepository jobConfigRepository;

	@Autowired
	private AssetAccountRepository assetAccountRepository;

	@Autowired
	private BillDocumentRepository billDocumentRepository;

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	private VendorRepository vendorRepository;

	public Page<RobotCustomData> searchRobotPage(String assetQuery, String status, String query, String acccountNo,
			String id, int pageIndex, int pageSize, String orderBy) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, pageSize);
		if (StringUtils.isBlank(assetQuery)) {
			assetQuery = null;
		} else {
			assetQuery = assetQuery.trim();
		}
		if (StringUtils.isBlank(status)) {
			status = null;
		} else {
			status = status.trim();
		}
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		if (StringUtils.isBlank(id)) {
			id = null;
		} else {
			id = id.trim();
		}
		if (StringUtils.isBlank(acccountNo)) {
			acccountNo = null;
		} else {
			acccountNo = acccountNo.trim();
		}
		return robotRepository.getPage(assetQuery, status, query, acccountNo, id, AssetAccount.CHANNEL_AUTOPILOT, page)
				.map(this::getRobotData);
	}

	public Page<RobotInf> findRobots(String assetCode, String status, String frequency, String vendorId,
			String acccountNo, int pageIndex, int pageSize, String orderBy) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, pageSize);
		if (StringUtils.isBlank(status)) {
			status = null;
		} else {
			status = status.trim();
		}
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(frequency)) {
			frequency = null;
		} else {
			frequency = frequency.trim();
		}
		return robotRepository.findRobotsByPage(assetCode, status, frequency, vendorId, acccountNo, page);
	}

	private RobotCustomData getRobotData(RobotData robotData) {
		RobotCustomData robotCustomData = new RobotCustomData();
		if (robotData.getAsset() != null) {
			robotCustomData.setAssetCode(robotData.getAsset().getAssetCode());
			robotCustomData.setAssetId(robotData.getAsset().getId());
			robotCustomData.setAssetName(robotData.getAsset().getName());
		}
		if (robotData.getVendor() != null) {
			robotCustomData.setVendorId(robotData.getVendor().getVendorId());
			robotCustomData.setVendorName(robotData.getVendor().getName());

		}
		if (robotData.getAssetAccount() != null) {
			robotCustomData.setAccountNumber(robotData.getAssetAccount().getAccountNumber());
		}
		if (robotData.getRobot() != null) {
			robotCustomData.setLastUpdated(robotData.getRobot().getLastUpdated());
			robotCustomData.setId(robotData.getRobot().getId());
			robotCustomData.setFrequency(robotData.getRobot().getFrequency());
			robotCustomData.setJobId(robotData.getRobot().getJobId());
			robotCustomData.setStatus(robotData.getRobot().getStatus());
			robotCustomData.setLastExecuted(robotData.getRobot().getLastExecuted());
			robotCustomData.setExecutedStatus(robotData.getRobot().getExecutedStatus());
			robotCustomData.setNextExecution(robotData.getRobot().getNextExecution());
			robotCustomData.setSriptVersion(robotData.getRobot().getScriptVersion());
			robotCustomData.setSchedule(robotData.getRobot().isSchedule());
			robotCustomData.setLeLogId(robotData.getRobot().getLeLogId());
			robotCustomData.setJenkinsCommand(robotData.getRobot().getJenkinsCommand());
		}
		return robotCustomData;
	}

	public List<Robot> robotList(String assetCode, String status) {
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(status)) {
			status = null;
		} else {
			status = status.trim();
		}
		return robotRepository.findRobots(assetCode, status);
	}

	public List<Map<String, Object>> robotListOfVendor(String vendorId) {
		return robotRepository.findByVendorId(vendorId).stream().map(this::setVendorData).collect(Collectors.toList());
	}

	private Map<String, Object> setVendorData(Robot robot) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("robotName", robot.getId());
		jsonObject.put("lastExcution", robot.getLastExecuted());
		jsonObject.put("status", robot.getStatus());
		return jsonObject.toMap();
	}

	public List<ZonedDateTime> getExecution(String id) {
		return robotRepository.findAllNextExecutionById(id);
	}

	public JsonResponse publishingJob(String jobId, boolean schedule) {
		Optional<Robot> existRobot = robotRepository.findById(jobId);
		if (existRobot.isPresent()) {
			return publishingJob(existRobot.get(), schedule);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Bot is not exist ", JsonResponse.STATUS_500);
		}
	}

	public JsonResponse publishingJob(Robot robot, boolean schedule) {

		if (robot != null) {
			String fileName = JKUtil.getScriptFileName(robot);
			if (jenkinsService1.createUpdateAndScedulingJob(schedule, robot, fileName)) {

				robotRepository.save(robot);
				return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Successfully Published ",
						JsonResponse.STATUS_200);
			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Error Jenkins: Job updation failed ",
						JsonResponse.STATUS_500);
			}
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Bot is not exist ", JsonResponse.STATUS_500);
		}
	}

	public JsonResponse unScheduleAllJobs(Robot robot) {

		if (robot != null) {
			String fileName = JKUtil.getScriptFileName(robot);
			if (jenkinsService1.createUpdateAndScedulingJobUnscheduleAll(robot.getId(), fileName)) {
				return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Successfully Published ",
						JsonResponse.STATUS_200);
			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Error Jenkins: Job updation failed ",
						JsonResponse.STATUS_500);
			}
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Bot is not exist ", JsonResponse.STATUS_500);
		}
	}

	public boolean unScheduleAllJobs(List<Robot> robots) {
		return jenkinsService1.createUpdateAndScedulingJobUnscheduleAll(robots);
	}

	public JsonResponse publishRobot(String robotId) {

		Optional<Robot> robot = robotRepository.findById(robotId);
		if (robot.isPresent()) {
			publishRobot(robot.get());
		}
		return new JsonResponse();
	}

	public JsonResponse publishRobot(Robot robot) {

		AssetAccount assetAcc = assetAccountRepository.findOneByAssetCodeAndAccountNumberAndVendorId(
				robot.getAssetCode(), robot.getAccountNo(), robot.getVendorId());
		if (assetAcc != null) {
			publishRobot(robot, assetAcc);
		}
		return new JsonResponse();
	}

	private JsonResponse publishRobot(Robot robot, AssetAccount assetAccount) {

		String userName = "";
		String userEmail = "";
		String txId = UUID.randomUUID().toString();
		JsonResponse response = null;

		System.out.println("assetAccount.getAcccode:" + robot.getAccountNo());
		VendorScript vendorScript = vendorScriptRepository.findByVendorId(robot.getVendorId());

		String id = robot.getAssetCode() + "-" + robot.getVendorId() + "-" + robot.getAccountNo();
		String fileName = JKUtil.getScriptFileName(robot);
		if (vendorScript != null) {
			if (jenkinsService1.createFileToFTP(txId, assetAccount, fileName, id, vendorScript)) {
				jenkinsService1.publishBot(robot, txId, id, fileName, userName, userEmail);
				robot.setStatus(Robot.STATUS_PUBLISHED);
				robot.setSchedule(false);
				robot.setJobId(id);
			}
			if (jenkinsService2.createFileToFTP(txId, assetAccount, fileName, id, vendorScript)) {
				jenkinsService2.publishBot(robot, txId, id, fileName, userName, userEmail);
			}
			response = new JsonResponse(JsonResponse.RESULT_SUCCESS, "Successfully Published ",
					JsonResponse.STATUS_200);

			robot.setScriptVersion(vendorScript.getVersion());

		} else {

			SystemLogs systemLogs = new SystemLogs("publish api", "Vendor Script not available", ZonedDateTime.now(),
					txId, SystemLogs.SYSTEM_TYPE_AUTOPILOT, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_AP, "",
					SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
					assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), "");

			systemLogsRepository.save(systemLogs);
			response = new JsonResponse(JsonResponse.RESULT_FAILED, "Vendor Script not available ",
					JsonResponse.STATUS_404);
		}
		robotRepository.save(robot);
		return response;

	}

	public Page<RobotCustomData> getUpcomingRobots(String assetCode, String vendorId, String accountNumber,
			String fromDate, String clientTz, String toDate, String orderBy, int page, int size) {

		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}
		Pageable pageRequest = GeneralUtil.getSortPageRequest(orderBy, page, size);
		return robotRepository.findUpComingRobots(assetCode, vendorId, accountNumber, pageRequest)
				.map(this::setRobotCustomData);
	}

	private RobotCustomData setRobotCustomData(Robot robot) {
		RobotCustomData robotCustomData = new RobotCustomData(robot);
		BillDocument billDocument = billDocumentRepository.findByAccountNumberAndAssetCodeAndVendorId(
				robot.getAccountNo(), robot.getAssetCode(), robot.getVendorId());
		if (billDocument != null) {
			BillDocumentRequest billDocumentRequest = new BillDocumentRequest(billDocument);
			robotCustomData.setBillDocumentRequest(billDocumentRequest);
		}
		if (robot.getAssetCode() != null) {
			Asset asset = assetRepository.getNameByAssetCode(robot.getAssetCode());
			if (asset != null) {
				robotCustomData.setAssetName(asset.getName());
				robotCustomData.setAddress(asset.getAddress());
			}
		}
		if (robot.getVendorId() != null) {
			robotCustomData.setVendorName(vendorRepository.getNameByVendorId(robot.getVendorId()));
		}
		return robotCustomData;
	}

	public Page<RobotCustomData> getActiveRobots(String assetCode, String vendorId, String accountNumber,
			String fromDate, String clientTz, String toDate, String orderBy, int page, int size) {

		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}

		Pageable pageRequest = GeneralUtil.getSortPageRequest(orderBy, page, size);
		return robotRepository.findRobotsByTimeInterval(assetCode, vendorId, accountNumber, pageRequest)
				.map(this::setRobotCustomData);
	}

	public RobotReportDto getCurrentDayCountTimeSlots() {
		RobotReportDto dto = new RobotReportDto();
		dto.setPattern(currentDayPattern());
		dto.setTotalBots(robotRepository.countRobotsByPattern(dto.getPattern()));
		dto.setPassedBots(robotRepository.countRobotsByPatternAndStatus(dto.getPattern(), "SUCCESS"));
		dto.setUpComingBots(robotRepository.countUpComingRobotsByPattern(dto.getPattern()));
		dto.setFailedBots(robotRepository.countRobotsByPatternAndStatus(dto.getPattern(), "FAILURE"));
		dto.setMinusBots(dto.getTotalBots() - (dto.getPassedBots() + dto.getFailedBots() + dto.getUpComingBots()));
		return dto;
	}

	private String currentDayPattern() {
		String pattern = "";
		int day = ZonedDateTime.now().getDayOfMonth();
		int j = day % 7;
		if (j == 0) {
			j = 7;
		}
		Optional<JobConfigModel> existcfg = jobConfigRepository.findById(100L);
		if (existcfg.isPresent()) {
			pattern = getDayPatterm(existcfg.get().getFrequency(), j);
		}
		return pattern;
	}

	public String getDayPatterm(int f, int day) {
		int a = 0;
		if (f == 2) {
			a = 14;
		}
		if (f == 3) {
			a = 10;
		}
		if (f == 4) {
			a = 7;
		}
		String resp = null;
		for (int i = 1; i <= f; i++) {
			if (resp == null) {
				resp = String.valueOf((a * i - a) + day);
			} else {
				resp = resp + "," + ((a * i - a) + day);
			}
		}
		return resp;
	}

	public long getTotalARobots() {
		return robotRepository.count();
	}
	
	public Map<Long,Long> geTotalSuccessRobotInMonth() {
		String[] strs = robotRepository.totalSuccessRobotInMonth();
		return getStringArrayToMap(strs);
	}
	
	public Map<Long,Long> geTotalFailRobotInMonth() {
		String[] strs = robotRepository.totalFailRobotInMonth();
		return getStringArrayToMap(strs);
	}
	
	public Map<Long,Long> geTotalFailRobotInDay() {
		String[] strs = robotRepository.totalFailRobotInDay();
		return getStringArrayToMap(strs);
	}
	
	public Map<Long,Long> geTotalSuccessRobotInDay() {
		String[] strs = robotRepository.totalSuccessRobotInDay();
		return getStringArrayToMap(strs);
	}
	
	private Map<Long,Long> getStringArrayToMap(String[] strs) {
		Map<Long,Long> map=new HashMap<>();
		for(String str:strs) {
			String[] split = str.split("-");
			map.put(Long.parseLong(split[0]), Long.parseLong(split[1]));
		}
		return map;
	}
}
