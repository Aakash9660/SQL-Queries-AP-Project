package com.smartdocs.service;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.GLAccount;
import com.smartdocs.model.dto.GLAccountDto;
import com.smartdocs.repository.GLAccountRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class GLAccountService {

	@Autowired
	private GLAccountRepository glAccountRepository;

	public JsonResponse createGLAccount(GLAccount gLAccount) {
			glAccountRepository.save(gLAccount);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "GLAccount save successfully", JsonResponse.STATUS_200);
	}

	public JsonResponse updateGLAccount(GLAccountDto gLAccountDto, String id) {
		GLAccount gLAccount = new GLAccount();
		BeanUtils.copyProperties(gLAccountDto, gLAccount);
		Optional<GLAccount> existGLA = this.glAccountRepository.findById(id);
		if (existGLA.isPresent()) {
			gLAccount.setId(existGLA.get().getId());
			glAccountRepository.save(gLAccount);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS,
					"Updated successfully", JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Update does not exist with" + id,
				JsonResponse.STATUS_400);
	}

	public GLAccount getGLAccount(String id) {
		return this.glAccountRepository.findById(id).orElseThrow(null);
	}

	public JsonResponse deleteGLAccount(String id) {
		Optional<GLAccount> existGl = this.glAccountRepository.findById(id);
		if (existGl.isPresent()) {
			glAccountRepository.delete(existGl.get());
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "GLAccount deleted ", JsonResponse.STATUS_200);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "GLAccount can't deleted", JsonResponse.STATUS_400);
		}
	}

	public Page<GLAccount> getGLAccountPage(String query, String orderBy, int pageIndex, int size) {
		if (StringUtils.isBlank(query)) {
			query = null;
		} else {
			query = query.trim();
		}
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		return this.glAccountRepository.getGLAccountPage(query, page);
	}

}
