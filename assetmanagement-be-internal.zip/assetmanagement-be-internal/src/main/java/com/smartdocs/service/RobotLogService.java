package com.smartdocs.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.RobotFailedBotActionRequest;
import com.smartdocs.dto.UpdateActionRequest;
import com.smartdocs.model.RobotLog;
import com.smartdocs.model.RobotLogActivityDetail;
import com.smartdocs.model.group.RobotLogData;
import com.smartdocs.repository.RobotLogActivityDetailRepository;
import com.smartdocs.repository.RobotLogRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class RobotLogService {

	@Autowired
	private RobotLogRepository robotLogRepository;

	@Autowired
	private RobotLogActivityDetailRepository rladRepository;

	@Autowired
	private FailedBotNotificationService failedBotNotificationService;
	
	@Autowired
	private ExcelGeneratorService excelGeneratorService;
	

	public Page<RobotLogData> robotLogPage(String order, int page, int size, String botName, String assetCode,
			String vendorId, String accountNo, Integer stage, String buildStatus) {
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(accountNo)) {
			accountNo = null;
		} else {
			accountNo = accountNo.trim();
		}
		if (StringUtils.isBlank(buildStatus)) {
			buildStatus = null;
		} else {
			buildStatus = buildStatus.trim();
		}
		if (StringUtils.isBlank(botName)) {
			botName = null;
		} else {
			botName = botName.trim();
		}

		Pageable pageable = GeneralUtil.getSortPageRequest(order, page, size);
		return robotLogRepository.findRobotLogData(stage, botName, assetCode, vendorId, accountNo, buildStatus,
				pageable);
	}
	
	public ByteArrayInputStream robotLogPageDownload(String botName, String assetCode,
			String vendorId, String accountNo, Integer stage, String buildStatus) throws IOException {
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(accountNo)) {
			accountNo = null;
		} else {
			accountNo = accountNo.trim();
		}
		if (StringUtils.isBlank(buildStatus)) {
			buildStatus = null;
		} else {
			buildStatus = buildStatus.trim();
		}
		if (StringUtils.isBlank(botName)) {
			botName = null;
		} else {
			botName = botName.trim();
		}
		List<RobotLogData> robotLogData = robotLogRepository.findRobotLogData(stage, botName, assetCode, vendorId, accountNo, buildStatus);
		return excelGeneratorService.failedBotToExcel(robotLogData);
	}

	public Page<RobotLogData> robotReport(String order, int page, int size, String botName, String assetCode,
			String vendorId, String accountNo, Integer stage, String buildStatus, String status, String clientTz,
			String buildExTimeFrom, String buildExTimeTo) {
		if (StringUtils.isBlank(status)) {
			status = null;
		} else {
			status = status.trim();
		}
		if (StringUtils.isBlank(accountNo)) {
			accountNo = null;
		} else {
			accountNo = accountNo.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(botName)) {
			botName = null;
		} else {
			botName = botName.trim();
		}
		if (StringUtils.isBlank(buildStatus)) {
			buildStatus = null;
		} else {
			buildStatus = buildStatus.trim();
		}
		ZonedDateTime bdExTimeFrom = null;
		ZonedDateTime bldExTimeTo = null;
		if (!StringUtils.isBlank(buildExTimeFrom)) {
			bdExTimeFrom = GeneralUtil.getFromDate(buildExTimeFrom, clientTz);
		}
		if (!StringUtils.isBlank(buildExTimeTo)) {
			bldExTimeTo = GeneralUtil.getToDate(buildExTimeTo, clientTz);
		}
		Pageable pageable = GeneralUtil.getSortPageRequest(order, page, size);
		return robotLogRepository.findReport(stage, botName, assetCode, vendorId, accountNo, buildStatus, status,
				bdExTimeFrom, bldExTimeTo, pageable);
	}

	@Deprecated
	public JsonResponse updateAction(UpdateActionRequest actionRequest) {
		if (actionRequest != null) {
			Optional<RobotLog> logs = robotLogRepository.findById(actionRequest.getId());
			if (logs.isPresent()) {
				logs.get().setStage(actionRequest.getStage());
				robotLogRepository.save(logs.get());
				return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Action performed successfully",
						JsonResponse.STATUS_200);
			}
			return new JsonResponse(JsonResponse.RESULT_FAILED, " Can't find report ", JsonResponse.STATUS_500);

		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Update Request is absent", JsonResponse.STATUS_500);
	}

	public JsonResponse bulkUpdation(RobotFailedBotActionRequest actionRequest, UserPrincipal logedInUser) {
		if (actionRequest != null) {
			for (String id : actionRequest.getIds()) {
				actionRequest.setId(id);
				action(logedInUser, actionRequest);
			}
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Action performed successfully",
					JsonResponse.STATUS_200);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Update Request is absent", JsonResponse.STATUS_500);
	}

	public JsonResponse action(UserPrincipal logedInUser, RobotFailedBotActionRequest actionRequest) {
		if (actionRequest != null) {
			Optional<RobotLog> logs = robotLogRepository.findById(actionRequest.getId());
			if (logs.isPresent()) {

				RobotLogActivityDetail log = new RobotLogActivityDetail(logs.get().getId(), logs.get().getStage(),
						actionRequest.getComment(), logedInUser.getEmail(), logedInUser.getName(),
						actionRequest.getActivity(), actionRequest.getActivity(), actionRequest.getAttachment());

				if (RobotLog.ACTION_COMPLETE.equalsIgnoreCase(actionRequest.getActivity())) {
					if (actionRequest.getAttachment() != null) {
						logs.get().setStatus(RobotLog.STATUS_COMPLETE);
						logs.get().setLastUpdated(ZonedDateTime.now());
						log.setActivityDesc("Bill Uploaded");
					} else {
						logs.get().setStatus(RobotLog.STATUS_COMPLETE);
						logs.get().setLastUpdated(ZonedDateTime.now());
						log.setActivityDesc("Completed");
					}
				} else if (RobotLog.ACTION_OBSOLETE.equalsIgnoreCase(actionRequest.getActivity())) {
					logs.get().setStatus(RobotLog.STATUS_OBSOLETE);
					logs.get().setLastUpdated(ZonedDateTime.now());
					log.setActivityDesc("Set to Obselete");
				} else if (RobotLog.ACTION_SEND_TO_L1.equalsIgnoreCase(actionRequest.getActivity())) {
					logs.get().setStatus(RobotLog.STATUS_OPEN);
					logs.get().setLastUpdated(ZonedDateTime.now());
					logs.get().setStage(1);
					log.setActivityDesc("Sent to Level1 Reviewer");
					failedBotNotificationService.sendL1FailedBotNotification(logs.get());
				} else if (RobotLog.ACTION_SEND_TO_L2.equalsIgnoreCase(actionRequest.getActivity())) {
					logs.get().setStatus(RobotLog.STATUS_OPEN);
					logs.get().setLastUpdated(ZonedDateTime.now());
					logs.get().setStage(2);
					log.setActivityDesc("Sent to Level2 Reviewer");
					failedBotNotificationService.sendL2FailedBotNotification(logs.get());
				} else {

				}
				logs.get().setComments(actionRequest.getComment());
				rladRepository.save(log);
				robotLogRepository.save(logs.get());
				return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Action performed successfully",
						JsonResponse.STATUS_200);
			}
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't find report ", JsonResponse.STATUS_500);
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Update Request is absent", JsonResponse.STATUS_500);
	}

	public List<RobotLogActivityDetail> getLogs(String robotLogId) {
		return rladRepository.findByRobotLogIdOrderByIdDesc(robotLogId);
	}

	public long getTotalRobotsLogs() {
		return robotLogRepository.count();
	}

	public long getTotalRobotsLogsByStatus(String status) {
		return robotLogRepository.countByBuildStatus(status);
	}
	
	
}
