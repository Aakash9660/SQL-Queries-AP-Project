package com.smartdocs.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.model.log.ApplicationLog;
import com.smartdocs.repository.ApplicationLogRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class ApplicationLogsServices {
	
	@Autowired
	private ApplicationLogRepository applicationLogRepository;

	public Page<ApplicationLog> getAllApplicationLogs(String orderBy, int page, int size, String type, String ipAddress,
			String email, String date) {
		Pageable pageable = GeneralUtil.getSortPageRequest(orderBy, page, size);
		if (StringUtils.isBlank(type)) {
			type = null;
		} else {
			type = type.trim();
		}
		Page<ApplicationLog> details = null;
		try {
			details = applicationLogRepository.findByType(type,ipAddress,email,date, pageable);
		} catch (Exception e) {
			pageable = PageRequest.of(page, size);
			details = applicationLogRepository.findByType(type,ipAddress,email,date, pageable);
		}
		return details;
	

	}

}
