package com.smartdocs.service.util;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;

public class GeneralUtil {

	private static final String SAP_TIME_ANYTD = "America/New_York";
	private static final String DATE_FORMAT_YYYYMMDD = "yyyy-MM-dd";
	private static final String DATE_FORMAT_MMDDYYYY = "MMddyyyy";

	private static final Logger logger = LoggerFactory.getLogger(GeneralUtil.class);

	public static Pageable getSortPageRequest(String orderBy, int pageIndex, int size) {
		Pageable pageable = null;
		if (orderBy != null) {
			if (!orderBy.startsWith("-")) {
				pageable = PageRequest.of(pageIndex, size, Direction.ASC, orderBy);
			} else {
				orderBy = orderBy.replace("-", "");
				pageable = PageRequest.of(pageIndex, size, Direction.DESC, orderBy);
			}
		} else {
			pageable = PageRequest.of(pageIndex, size);
		}

		return pageable;
	}

	public static ZonedDateTime getMidDate(String month, String year) {
		ZonedDateTime fromdt = null;
		if (!StringUtils.isBlank(month) && !StringUtils.isBlank(year)) {
			try {
				String dateStr = "";
				int m = Integer.valueOf(month);
				m = m + 1;
				if (m < 10) {
					dateStr = 0 + "" + m + "" + 15 + "" + year;
				} else {
					dateStr = +m + "" + 15 + "" + year;
				}
				Date date = new SimpleDateFormat(DATE_FORMAT_MMDDYYYY).parse(dateStr);
				fromdt = date.toInstant().atZone(getZoneId(null));
			} catch (Exception ex) {
				logger.error("GetMidDate Ex", ex);

			}
		}
		return fromdt;
	}

	public static ZoneId getZoneId(String clientTz) {
		ZoneId clientZonedId;
		if (clientTz != null) {
			clientZonedId = ZoneId.of(clientTz);
		} else {
			clientZonedId = ZoneId.of(SAP_TIME_ANYTD);
		}
		return clientZonedId;
	}

	public static String mask(int start, int end, String unmaskableString) {
		String unmaskString = unmaskableString;
		int masklength = end - start;
		StringBuilder sb = new StringBuilder(masklength);
		for (int i = 0; i < masklength; i++)
			sb.append("*");
		return sb.toString() + unmaskString.substring(start + masklength);
	}

	public static String getName(String firstName, String lastName) {
		if (firstName != null && lastName != null) {
			return firstName + " " + lastName;
		} else if (firstName == null) {
			return " " + lastName;
		} else {
			return firstName + " ";
		}
	}

	public static ZonedDateTime getFromDate(String fromDateStr, String clientTz) {
		ZonedDateTime fromdt = null;
		if (fromDateStr != null && !StringUtils.isBlank(fromDateStr)) {
			try {
				Date date = new SimpleDateFormat(DATE_FORMAT_YYYYMMDD).parse(fromDateStr);
				fromdt = date.toInstant().atZone(getZoneId(clientTz));
			} catch (Exception ex) {
				logger.error("getFromDate Ex {}", ex.getMessage());
			}
		}
		return fromdt;
	}

	public static ZonedDateTime getToDate(String toDateStr, String clientTz) {
		ZonedDateTime todt = null;
		if (toDateStr!=null&&!StringUtils.isBlank(toDateStr) ) {
			try {
				Date todate = new SimpleDateFormat(DATE_FORMAT_YYYYMMDD).parse(toDateStr);
				todt = todate.toInstant().atZone(getZoneId(clientTz)).plusDays(1);
			} catch (Exception ex) {
				logger.error("getToDate Exception: {}", ex.getMessage());
			}
		}

		return todt;
	}
	
	public static ZonedDateTime getBillMonth(String toDateStr, String clientTz) {
		ZonedDateTime todt = null;
		if (toDateStr!=null&&!StringUtils.isBlank(toDateStr) ) {
			try {
				Date todate = new SimpleDateFormat("MMMyy").parse(toDateStr);
				todt = todate.toInstant().atZone(getZoneId(clientTz)).plusDays(1);
			} catch (Exception ex) {
				logger.error("getToDate Exception: {}", ex.getMessage());
			}
		}

		return todt;
	}

	public static String geStateCode(String gst) {
		if (StringUtils.isEmpty(gst))
			return "99";
		return firstTwo(gst);
	}

	public static String firstTwo(String str) {
		return str.length() < 2 ? str : str.substring(0, 2);
	}
	
	
	public static ZonedDateTime toDate(long miliseconds) {
		try{
			return  ZonedDateTime.ofInstant(Instant.ofEpochMilli(miliseconds), 
                    ZoneId.systemDefault());
		}catch(Exception ex) {
			return null;
		}
	}
}
