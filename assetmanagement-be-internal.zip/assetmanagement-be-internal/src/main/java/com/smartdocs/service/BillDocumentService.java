package com.smartdocs.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.BillAmountDTO;
import com.smartdocs.dto.InvoiceRequest;
import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.BillDocument;
import com.smartdocs.model.BillDocumentLog;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.dto.BillHistory;
import com.smartdocs.model.group.BillDataRequest;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.repository.AssetRepository;
import com.smartdocs.repository.BillDocumentLogRepository;
import com.smartdocs.repository.BillDocumentRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.service.util.HttpReqRespUtils;
import com.smartdocs.sql.dto.BillHistoryInf;
import com.smartdocs.sql.dto.ManageBills;
import com.smartdocs.sql.dto.ManageBillsInf;
import com.smartdocs.sql.dto.OneYearBillInf;

@Service
public class BillDocumentService {

	@Autowired
	private BillDocumentRepository billDocumentRepository;

	@Autowired
	private AdminService adminService;

	@Autowired
	private DocumentUploadService documentService;

	@Autowired
	private AssetAccountRepository assetAccountRepository;

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private ExcelGeneratorService excelGeneratorService;

	@Autowired
	private MissingBillsService missingBillsService;

	@Autowired
	private BillDocumentLogRepository billDocumentLogRepository;

	@Autowired
	private SystemLogsRepository systemLogsRepository;
	
	public Page<BillHistory> search(String notrequirestatus, String billfromDate, String billtoDate, String invfromDate,
			String clientTz, String invtoDate, String assetQuery, String vendorQuery, String accountNumber,
			String jobId, String txId, String invoiceNumber, String channel, int pageIndex, int size, String orderBy,
			String status, String billMonth) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		ZonedDateTime invbillFromDate = null;
		ZonedDateTime invbillToDateTime = null;
		ZonedDateTime billFromDate = null;
		ZonedDateTime billToDateTime = null;
		ZonedDateTime getBillMonth = null;
		int monthOfBillMonth = 0;
		int yearOfBillMonth = 0;

		if (StringUtils.isBlank(billMonth)) {
			getBillMonth = null;
		} else {
			getBillMonth = GeneralUtil.getBillMonth(billMonth, clientTz);
			if (getBillMonth != null) {
				monthOfBillMonth = getBillMonth.getMonthValue();
				yearOfBillMonth = getBillMonth.getYear();
			}
		}
		if (StringUtils.isBlank(assetQuery)) {
			assetQuery = null;
		} else {
			assetQuery = assetQuery.trim();
		}
		if (StringUtils.isBlank(channel)) {
			channel = null;
		} else {
			channel = channel.trim();
		}
		if (StringUtils.isBlank(status)) {
			status = null;
		} else {
			status = status.trim();
		}
		if (StringUtils.isBlank(vendorQuery)) {
			vendorQuery = null;
		} else {
			vendorQuery = vendorQuery.trim();
		}
		if (StringUtils.isBlank(jobId)) {
			jobId = null;
		} else {
			jobId = jobId.trim();
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}
		if (StringUtils.isBlank(txId)) {
			txId = null;
		} else {
			txId = txId.trim();
		}
		if (StringUtils.isBlank(invoiceNumber)) {
			invoiceNumber = null;
		} else {
			invoiceNumber = invoiceNumber.trim();
		}
		if (!StringUtils.isBlank(invfromDate)) {
			invbillFromDate = GeneralUtil.getFromDate(invfromDate, clientTz);
		}
		if (!StringUtils.isBlank(invtoDate)) {
			invbillToDateTime = GeneralUtil.getToDate(invtoDate, clientTz);
		}
		if (!StringUtils.isBlank(invfromDate)) {
			billFromDate = GeneralUtil.getFromDate(billfromDate, clientTz);
		}
		if (!StringUtils.isBlank(invtoDate)) {
			billToDateTime = GeneralUtil.getToDate(billtoDate, clientTz);
		}
		if (StringUtils.isBlank(notrequirestatus)) {
			notrequirestatus = null;
		} else {
			notrequirestatus = notrequirestatus.trim();
		}
		return billDocumentRepository.fetchDeatils(notrequirestatus, assetQuery, vendorQuery, accountNumber, jobId,
				invbillFromDate, invbillToDateTime, txId, invoiceNumber, billFromDate, billToDateTime, channel, page,
				status, monthOfBillMonth, yearOfBillMonth).map(this::mapBillDocumentToBillHistory);
	}

	private BillHistory mapBillDocumentToBillHistory(BillDataRequest billData) {
		BillHistory billHistory = new BillHistory(billData.getBillDocument());
		if (billData.getVendor() != null) {
			billHistory.setVendorId(billData.getVendor().getVendorId());
			billHistory.setVendorName(billData.getVendor().getName());
			billHistory.setClassifications(billData.getVendor().getClassifications());
		}
		if (billData.getCostCenter() != null) {
			billHistory.setCostCenter(billData.getCostCenter().getCode());
			billHistory.setCostCenterDesc(billData.getCostCenter().getDescription());
		}
		if (billData.getGlAccount() != null) {
			billHistory.setGlAccount(billData.getGlAccount().getCode());
			billHistory.setGlAccountDesc(billData.getGlAccount().getDescription());
		}
		if (billData.getAssetAccount() != null) {
			billHistory.setChannel(billData.getAssetAccount().getChannel());
		}
		if (billData.getAsset() != null) {
			billHistory.setAssetAddress(billData.getAsset().getAddress());
		}
		String url = documentService.buildURL(adminService.getSmartStoreConfig().get(0), billHistory.getDocId(), "get",
				billData.getBillDocument().getFilename());
		billHistory.setUrl(url);
		return billHistory;
	}

	public BillDocument registerInvoiceData(InvoiceRequest invoiceRequest) {
		
		int errorType=0;
		String message="";
		BillDocument billDocument=null;
		if (invoiceRequest != null) {
			
			AssetAccount assetAccount = null;
			try {
				assetAccount = assetAccountRepository.findOneByAccountNumberAndVendorId(
						invoiceRequest.getAccountNo(), invoiceRequest.getVendorId());
			} catch (Exception ex) {
				System.out.println(invoiceRequest.toString());
				ex.printStackTrace();
			}
			if(assetAccount!=null)
			{
				Optional<BillDocument> existBillDoc = null;
				try {
					existBillDoc = billDocumentRepository.findFirstByTxId(invoiceRequest.getTxId());
				} catch (Exception e) {
					e.printStackTrace();
				}
				if (existBillDoc.isPresent()) {
							billDocument = getUpdatedBillDocument(existBillDoc.get(), invoiceRequest,
								assetAccount);
				} else {
						billDocument= new BillDocument(invoiceRequest, assetAccount);
						// get the utility type with vendorid
						if (billDocument.getVendorId() != null) {
							Vendor vendorDetails = vendorRepository.findFirstByVendorId(billDocument.getVendorId());
							if (vendorDetails != null && vendorDetails.getClassifications().size() != 0) {
								billDocument.setUtilityType(vendorDetails.getClassifications().get(0));
							}
						}
				}
				Optional<Asset> asset = assetRepository.findOneByAssetCode(assetAccount.getAssetCode());
				if (asset.isPresent()) {
					billDocument.setAssetId(asset.get().getId());
					billDocument.setAssetName(asset.get().getName());
				}
				billDocument.setInvoiceNumber(invoiceRequest.getInvoiceNumber());
				billDocument.setInvoiceDate(invoiceRequest.getInvoiceDate());
				billDocument.setUploadedDate(ZonedDateTime.now());
				billDocument.setStatus(BillDocument.STATUS_INPROCESS);
				billDocumentRepository.save(billDocument);
			}
			else {
				 message="RegInv assetAccount not found acNo: "+invoiceRequest.getAccountNo()+" vendorid "+ invoiceRequest.getVendorId();
				errorType=2;
			}
			
		}
		if(billDocument!=null) {
			
			billDocumentLogRepository.save(new BillDocumentLog(billDocument.getId(), BillDocumentLog.DIRECTION_EMAIL_TO_AP,
					"Invoice Registered After OCR.", BillDocumentLog.STATUS_SUCCESS,invoiceRequest.getChannel()));
			
			try {
				missingBillsService.actionOnManageBillsForEmailInvoices(billDocument);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		else {
			SystemLogs systemLogs = new SystemLogs("RegisterInv api", message, ZonedDateTime.now(),
					UUID.randomUUID().toString(), SystemLogs.SYSTEM_TYPE_AUTOPILOT, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_AP,
					"", SystemLogs.USER, invoiceRequest.getAccountNo(), invoiceRequest.getVendorId(),
					null, HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					"");
			systemLogsRepository.save(systemLogs);
		}
		return billDocument;
	}

	public Page<BillDocument> searchBills(String assetCode, String accountNumber, String status, String billMonth,
			String fromDate, String clientTz, String toDate, String invoiceNumber, String vendorQuery, int pageIndex,
			int size, String orderBy) {
		ZonedDateTime billFromDate = null;
		ZonedDateTime billToDateTime = null;
		ZonedDateTime getBillMonth = null;
		int monthOfBillMonth = 0;
		int yearOfBillMonth = 0;

		if (StringUtils.isBlank(billMonth)) {
			getBillMonth = null;
		} else {
			getBillMonth = GeneralUtil.getBillMonth(billMonth, clientTz);
			if (getBillMonth != null) {
				monthOfBillMonth = getBillMonth.getMonthValue();
				yearOfBillMonth = getBillMonth.getYear();
			}
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(invoiceNumber)) {
			invoiceNumber = null;
		} else {
			invoiceNumber = invoiceNumber.trim();
		}
		if (!StringUtils.isBlank(fromDate)) {
			billFromDate = GeneralUtil.getFromDate(fromDate, clientTz);
		}
		if (!StringUtils.isBlank(toDate)) {
			billToDateTime = GeneralUtil.getToDate(toDate, clientTz);
		}
		if (StringUtils.isBlank(status)) {
			status = null;
		} else {
			status = status.trim();
		}
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		return billDocumentRepository.searchBillDeatils(assetCode, accountNumber, status, invoiceNumber, vendorQuery,
				billFromDate, billToDateTime, monthOfBillMonth, yearOfBillMonth, page);
	}

	
	public Page<BillDocument> getBills(String assetCode, String vendorId, String accountNumber, int page, int size,
			String orderBy) {
		Pageable sortPageRequest = GeneralUtil.getSortPageRequest(orderBy, page, size);
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}
		return billDocumentRepository.searchBills(accountNumber, assetCode, vendorId, sortPageRequest);
	}

	public BillAmountDTO getOneMonthBills(String assetCode, String status, String billMonth, String clientTz) {
		int monthOfBillMonth = 0;
		int yearOfBillMonth = 0;
		ZonedDateTime getBillMonth = null;
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(status)) {
			status = null;
		} else {
			status = status.trim();
		}
		if (StringUtils.isBlank(billMonth)) {
			getBillMonth = null;
		} else {
			getBillMonth = GeneralUtil.getBillMonth(billMonth, clientTz);
			if (getBillMonth != null) {
				monthOfBillMonth = getBillMonth.getMonthValue();
				yearOfBillMonth = getBillMonth.getYear();
			}
		}
		BillAmountDTO billAmountDTO = new BillAmountDTO();
		billAmountDTO.setTotalAmount(billDocumentRepository.getOneMonthBillsTotalAmount(assetCode, status,
				monthOfBillMonth, yearOfBillMonth));
		billAmountDTO.setUtilityType(
				billDocumentRepository.getOneMonthBills(assetCode, status, monthOfBillMonth, yearOfBillMonth));
		return billAmountDTO;
	}

	public List<OneYearBillInf> pastOneYearBillsData(String status) {
		if (StringUtils.isBlank(status)) {
			status = null;
		} else {
			status = status.trim();
		}
		// if (yearOfBillMonth==null) {
		// yearOfBillMonth=ZonedDateTime.now().getYear();
		// }
		return billDocumentRepository.findByNativeQueryOneYearBill(status);
	}

	public Page<BillHistoryInf> getPage(String utilityType, List<String> statuses, String billMonth, String invfromDate,
			String clientTz, String invtoDate, String assetQuery, String vendorQuery, String accountNumber,
			String invoiceNumber, String channel, int pageIndex, int size, String orderBy) {
		ZonedDateTime invbillFromDate = null;
		ZonedDateTime invbillToDateTime = null;
		ZonedDateTime getBillMonth = null;
		int monthOfBillMonth = 0;
		int yearOfBillMonth = 0;
		if (StringUtils.isBlank(billMonth)) {
			getBillMonth = null;
		} else {
			getBillMonth = GeneralUtil.getBillMonth(billMonth, clientTz);
			if (getBillMonth != null) {
				monthOfBillMonth = getBillMonth.getMonthValue();
				yearOfBillMonth = getBillMonth.getYear();
			}
		}
		if (!StringUtils.isBlank(invfromDate)) {
			invbillFromDate = GeneralUtil.getFromDate(invfromDate, clientTz);
		}
		if (!StringUtils.isBlank(invtoDate)) {
			invbillToDateTime = GeneralUtil.getToDate(invtoDate, clientTz);
		}
		if (StringUtils.isBlank(assetQuery)) {
			assetQuery = null;
		} else {
			assetQuery = assetQuery.trim();
		}
		if (StringUtils.isBlank(channel)) {
			channel = null;
		} else {
			channel = channel.trim();
		}
		if (StringUtils.isBlank(vendorQuery)) {
			vendorQuery = null;
		} else {
			vendorQuery = vendorQuery.trim();
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}
		if (StringUtils.isBlank(invoiceNumber)) {
			invoiceNumber = null;
		} else {
			invoiceNumber = invoiceNumber.trim();
		}
		if (!StringUtils.isBlank(invfromDate)) {
			invbillFromDate = GeneralUtil.getFromDate(invfromDate, clientTz);
		}
		if (!StringUtils.isBlank(invtoDate)) {
			invbillToDateTime = GeneralUtil.getToDate(invtoDate, clientTz);
		}
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		return billDocumentRepository.fetchDeatilsByNativeQuery(utilityType, statuses, assetQuery, vendorQuery,
				accountNumber, invoiceNumber, channel, invbillFromDate, invbillToDateTime, monthOfBillMonth,
				yearOfBillMonth, page);
	}

	public ByteArrayInputStream downloadBills(String utilityType, List<String> statuses, String billMonth,
			String invfromDate, String clientTz, String invtoDate, String assetQuery, String vendorQuery,
			String accountNumber, String invoiceNumber, String channel) throws IOException {
		ZonedDateTime invbillFromDate = null;
		ZonedDateTime invbillToDateTime = null;
		ZonedDateTime getBillMonth = null;
		int monthOfBillMonth = 0;
		int yearOfBillMonth = 0;
		if (StringUtils.isBlank(billMonth)) {
			getBillMonth = null;
		} else {
			getBillMonth = GeneralUtil.getBillMonth(billMonth, clientTz);
			if (getBillMonth != null) {
				monthOfBillMonth = getBillMonth.getMonthValue();
				yearOfBillMonth = getBillMonth.getYear();
			}
		}
		if (!StringUtils.isBlank(invfromDate)) {
			invbillFromDate = GeneralUtil.getFromDate(invfromDate, clientTz);
		}
		if (!StringUtils.isBlank(invtoDate)) {
			invbillToDateTime = GeneralUtil.getToDate(invtoDate, clientTz);
		}
		if (StringUtils.isBlank(assetQuery)) {
			assetQuery = null;
		} else {
			assetQuery = assetQuery.trim();
		}
		if (StringUtils.isBlank(channel)) {
			channel = null;
		} else {
			channel = channel.trim();
		}
		if (StringUtils.isBlank(vendorQuery)) {
			vendorQuery = null;
		} else {
			vendorQuery = vendorQuery.trim();
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}
		if (StringUtils.isBlank(invoiceNumber)) {
			invoiceNumber = null;
		} else {
			invoiceNumber = invoiceNumber.trim();
		}
		if (!StringUtils.isBlank(invfromDate)) {
			invbillFromDate = GeneralUtil.getFromDate(invfromDate, clientTz);
		}
		if (!StringUtils.isBlank(invtoDate)) {
			invbillToDateTime = GeneralUtil.getToDate(invtoDate, clientTz);
		}
		List<BillHistoryInf> inf = billDocumentRepository.fetchDeatilsByNativeQuery(utilityType, statuses, assetQuery,
				vendorQuery, accountNumber, invoiceNumber, channel, invbillFromDate, invbillToDateTime,
				monthOfBillMonth, yearOfBillMonth);
		return excelGeneratorService.billToExcel(inf);
	}

	public BillDocument getUpdatedBillDocument(BillDocument existBillDocument, InvoiceRequest invoiceRequest,
			AssetAccount assetAccount) {

		if (invoiceRequest.getDocumentInfo() != null) {
			existBillDocument.setDocid(invoiceRequest.getDocumentInfo().getDocumentid());
			existBillDocument.setFilename(invoiceRequest.getDocumentInfo().getFilename());
			existBillDocument.setFiletype(invoiceRequest.getDocumentInfo().getFiletype());
			existBillDocument.setAttid(invoiceRequest.getDocumentInfo().getAttid());
			existBillDocument.setArid(invoiceRequest.getDocumentInfo().getArid());
			existBillDocument.setUploadedBy(invoiceRequest.getDocumentInfo().getUploadedBy());
			existBillDocument.setUploadedDate(invoiceRequest.getDocumentInfo().getUploadedDate());
		}
		existBillDocument.setInvoiceNumber(invoiceRequest.getInvoiceNumber());
		existBillDocument.setVendorId(invoiceRequest.getVendorId());
		existBillDocument.setAccountNumber(invoiceRequest.getAccountNo());
		existBillDocument.setStatus(invoiceRequest.getStatus());
		existBillDocument.setAmount(invoiceRequest.getAmount());
		existBillDocument.setDueDate(invoiceRequest.getDueDate());
		existBillDocument.setTxId(invoiceRequest.getTxId());
		// this.txId = invoiceRequest.getTxId();
		existBillDocument.setInvoiceDate(invoiceRequest.getInvoiceDate());
		if (assetAccount != null) {
			existBillDocument.setAssetCode(assetAccount.getAssetCode());
			existBillDocument.setGlAccount(assetAccount.getGlAccount());
			existBillDocument.setCostCenter(assetAccount.getCostCenter());
		}
		return existBillDocument;
	}

	public Page<ManageBills> searchManageBills(String assetCode, String vendorId, String accountNumber,
			String frequency, String orderBy, int page, int size) {
		Pageable sortPageRequest = GeneralUtil.getSortPageRequest(orderBy, page, size);
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}
		if (StringUtils.isBlank(frequency)) {
			frequency = null;
		} else {
			frequency = frequency.trim();
		}
		return vendorRepository.findManageBills(vendorId, accountNumber, assetCode, frequency, sortPageRequest)
				.map(this::setDataInManageBills);
	}

	public ManageBills setDataInManageBills(ManageBillsInf inf) {
		ManageBills manageBills = null;
		if (inf != null) {
			Optional<BillDocument> content = billDocumentRepository.searchBills(inf.getAccountNo(), inf.getAssetCode(),
					inf.getVendorId());
			if (content.isPresent()) {
				manageBills = new ManageBills(inf, content.get());
			} else {
				manageBills = new ManageBills(inf);
			}
		}
		return manageBills;
	}

	public List<BillDocumentLog> getBillDocLogs(long id) {
		return billDocumentLogRepository.findByBillIdOrderByDateTimeDesc(id);
	}

	public ByteArrayInputStream downloadManageBills(String assetCode, String vendorId, String accountNumber)
			throws IOException {
		if (StringUtils.isBlank(assetCode)) {
			assetCode = null;
		} else {
			assetCode = assetCode.trim();
		}
		if (StringUtils.isBlank(vendorId)) {
			vendorId = null;
		} else {
			vendorId = vendorId.trim();
		}
		if (StringUtils.isBlank(accountNumber)) {
			accountNumber = null;
		} else {
			accountNumber = accountNumber.trim();
		}
		List<ManageBills> collect = vendorRepository.findManageBills(vendorId, accountNumber, assetCode).stream()
				.map(this::setDataInManageBills).collect(Collectors.toList());
		return excelGeneratorService.manageBillsToExcel(collect);
	}

}
