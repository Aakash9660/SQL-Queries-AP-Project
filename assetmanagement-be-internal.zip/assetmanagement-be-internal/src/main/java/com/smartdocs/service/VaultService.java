package com.smartdocs.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.VaultExcelRow;
import com.smartdocs.model.Vault;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.dto.VaultDto;
import com.smartdocs.model.log.ApplicationLog;
import com.smartdocs.repository.ApplicationLogRepository;
import com.smartdocs.repository.VaultRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.Constants;
import com.smartdocs.service.util.EncryptionDecryption;
import com.smartdocs.service.util.ExcelToJsonService;
import com.smartdocs.service.util.GeneralUtil;
import com.smartdocs.service.util.HttpReqRespUtils;

@Service
public class VaultService {

	EncryptionDecryption encryptionDecryption = new EncryptionDecryption();

	@Autowired
	private VaultRepository vaultRepository;

	@Autowired
	private ApplicationLogRepository applicationLogRepository;

	@Autowired
	private ExcelToJsonService excelToJsonService;

	@Autowired
	private ExcelGeneratorService excelGeneratorService;

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private VendorScriptService vendorScriptService;

	public JsonResponse createVault(VaultDto vaultDto) {
		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		Vault vault = new Vault();
		BeanUtils.copyProperties(vaultDto, vault);
		if (vaultDto.getPassword() != null && !vaultDto.getPassword().equals("")) {
			vault.setPassword(encryptionDecryption.encrypt(vaultDto.getPassword()));
		} else {
			vault.setPassword(null);
		}
		updateVersion(vault);
		vault.setToEmail(vaultDto.getUserId());
		vault.setUserId(vaultDto.getUserId());
		vault.setCreatedDate(ZonedDateTime.now());
		vault.setLastUpdated(ZonedDateTime.now());
		try {
			vaultRepository.save(vault);
			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_VAULT_CREATION, user.getEmail(), user.getName(), null, null,
					user.getName() + " Vault created successfully", "", "VaultRestAPIs:createVault()", "/vault",
					user.getRole()));
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Vault created successfully", JsonResponse.STATUS_200);
		} catch (DataIntegrityViolationException e) {
			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_ASSET_CREATION, user.getEmail(), user.getName(), null, null,
					user.getName() + "Secret Name " + vault.getName() + " is duplicate", "",
					"VaultRestAPIs:createVault()", "/vault", user.getRole()));
			throw new DataIntegrityViolationException("Secrete Name " + vault.getName() + " is duplicate");
		}
	}

	public JsonResponse updateVault(VaultDto vaultDto, Long id) {

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		Optional<Vault> existVault = vaultRepository.findById(id);
		if (existVault.isPresent()) {
			Vault vault = existVault.get();
			if (vaultDto.getPassword().equals("") || vaultDto.getPassword().equals("********")) {

			} else {
				vault.setPassword(encryptionDecryption.encrypt(vaultDto.getPassword()));
			}
			updateVersion(vault);
			vault.setLastUpdated(ZonedDateTime.now());
			vault.setName(vaultDto.getName());
			vault.setToEmail(vaultDto.getToEmail());
			vault.setUserId(vaultDto.getUserId());
			vault.setDescription(vaultDto.getDescription());
			vaultRepository.save(vault);
			//updateVaultInVendorScriptForAllBots(vault.getId());
			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					Constants.ACTIVITY_TYPE_VAULT_UPDATION, user.getEmail(), user.getName(), null, null,
					user.getName() + " Successfully updated with " + id, "", "VaultRestAPIs:updateVault()",
					"/vault/{id}", user.getRole()));

			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Vault Updated Successfully", JsonResponse.STATUS_200);
		}
		applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
				Constants.ACTIVITY_TYPE_VAULT_UPDATION, user.getEmail(), user.getName(), null, null,
				user.getName() + " Vault does not exist with " + id, "", "VaultRestAPIs:updateVault()", "/vault/{id}",
				user.getRole()));

		return new JsonResponse(JsonResponse.RESULT_FAILED, "Vault does not exist with " + id, JsonResponse.STATUS_500);

	}

	public Map<String, Object> getDecryptPassword(long id) {
		Optional<Vault> existVault = vaultRepository.findById(id);
		JSONObject jsonObject = new JSONObject();
		if (existVault.isPresent()) {
			jsonObject.put("password", EncryptionDecryption.decrypt(existVault.get().getPassword()));
			return jsonObject.toMap();
		}
		return jsonObject.toMap();
	}

	private void updateVersion(Vault vault) {
		try {
			if (vault.getVersion() == 0) {
				vault.setVersion(1);
			} else {
				vault.setVersion(vault.getVersion() + 1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Vault getVault(Long id) {
		Optional<Vault> existVault = vaultRepository.findById(id);
		if (existVault.isPresent()) {
			Vault vault = existVault.get();
			vault.setPassword(null);
			return vault;
		}
		return null;
	}
	
	public Vault getVaultWithDecryptPassword(String name) {
		Vault existVault = vaultRepository.findOneByName(name);
		if (existVault!=null) {
			try {
				existVault.setPassword(EncryptionDecryption.decrypt(existVault.getPassword()));
			}catch (Exception e) {
				existVault.setPassword(null);
				e.printStackTrace();
			}
			return existVault;
		}
		return null;
	}

	public Page<Vault> getVaultPages(String name, int pageIndex, int size, String orderBy) {
		Pageable page = GeneralUtil.getSortPageRequest(orderBy, pageIndex, size);
		Page<Vault> vaultPages = null;
		if (StringUtils.isBlank(name)) {
			name = null;
		} else {
			name = name.trim();
		}
		try {
			vaultPages = vaultRepository.findByName(name, page);
		} catch (Exception e) {
			page = PageRequest.of(pageIndex, size);
			vaultPages = vaultRepository.findByName(name, page);
		}
		for (Vault pageVault : vaultPages) {
			if (pageVault != null)
				pageVault.setPassword("********");
		}
		return vaultPages;
	}

	public void deleteVault(Long id) {

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
				Constants.ACTIVITY_TYPE_VAULT_DELETION, user.getEmail(), user.getName(), null, null,
				user.getName() + " Successfully Deleted", "", "VaultRestAPIs:deleteVault()", "/vault/{id}",
				user.getRole()));

		vaultRepository.deleteById(id);
	}

	public JsonResponse processVaultUpload(InputStream inputStream) {
		try {
			List<VaultExcelRow> vaultRows = excelToJsonService.convertVaultDataToJson(inputStream, 0);
			if (vaultRows != null) {
				for (VaultExcelRow row : vaultRows) {
					createVaultByExcel(row);
				}
			}
			return new JsonResponse(vaultRows, JsonResponse.RESULT_SUCCESS, "Uploaded Success.",
					JsonResponse.STATUS_200);
		} catch (Exception ex) {
			System.out.println("Ex:" + ex.getMessage());
			ex.printStackTrace();
			return new JsonResponse("", JsonResponse.RESULT_FAILED, "Ex:" + ex.getMessage(), JsonResponse.STATUS_500);
		}
	}

	private VaultExcelRow createVaultByExcel(VaultExcelRow row) {
		Vault existVault = vaultRepository.findOneByName(row.getName());
		if (existVault == null) {
			Vault vault = new Vault(row);
			if (row.getPassword() != null && !row.getPassword().equals("")) {
				vault.setPassword(encryptionDecryption.encrypt(row.getPassword()));
			}
			vaultRepository.save(vault);
		}
		return row;
	}

	public ByteArrayInputStream getVaultPagesDownload(String name) throws IOException {
		if (StringUtils.isBlank(name)) {
			name = null;
		} else {
			name = name.trim();
		}
		List<Vault> vaultPages = vaultRepository.findByName(name);
		return excelGeneratorService.vaultToExcel(vaultPages);
	}

	public List<Vault> getVaultByVendorId(String vendorId) {
		List<Vault> vaults = vaultRepository.findVaultByVendorId(vendorId);
		if (!vaults.isEmpty() && vaults != null) {
			for (Vault vault : vaults) {
				vault.setPassword(EncryptionDecryption.decrypt(vault.getPassword()));
			}
		}
		return vaultRepository.findVaultByVendorId(vendorId);
	}

	public VaultDto getVaultByAccountNo(String accountNo) {
		Vault vault = vaultRepository.findByAccountNumber(accountNo);
		VaultDto vaultDto = new VaultDto();
		if (vault != null) {
			vault.setPassword(EncryptionDecryption.decrypt(vault.getPassword()));
			BeanUtils.copyProperties(vault, vaultDto);
		}
		String url = vendorRepository.getURLByAccountNo(accountNo);
		vaultDto.setVendorURL(url);
		return vaultDto;
	}
	
	// ------ update vault on ftp
		@Async
		private void updateVaultInVendorScriptForAllBots(long id) {
			try {
				List<Vendor> vendors = vendorRepository.findVendorsByVaultId(id);
				for (Vendor vendor : vendors) {
					vendorScriptService.rePublishVendoScriptOnAllServers(vendor.getVendorId());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

}
