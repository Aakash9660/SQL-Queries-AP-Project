package com.smartdocs.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.EmailRequestDTO;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.EmailChannel;
import com.smartdocs.repository.EmailChannelRepository;

@Service
public class ReadEmailService {
	
	@Autowired
	private EmailChannelRepository emailChannelsRepository;
	
	@Autowired
	private GraphAPIReadEmailService graphAPIReadEmailService;
	
	private static final Logger logger = LoggerFactory.getLogger(ReadEmailService.class);
	
	public JsonResponse readEmail(EmailRequestDTO emailRequestDTO)  {
		logger.info("readEmail");
		JsonResponse readEmail = null;
		try {
			EmailChannel echannels=emailChannelsRepository.findOneBySharedEmail(emailRequestDTO.getTo());
			if(echannels!=null && echannels.isEnabled() && echannels.isSharedEmailId())
			{
				if(echannels.getAuthType().equals(EmailChannel.AUTH_TYPE_OAUTH)) {
				   readEmail = graphAPIReadEmailService.readEmailTest(echannels,emailRequestDTO);
					
			  }else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Channel auth type not found!", JsonResponse.STATUS_404);
			 }
			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "ToEmail is not exiting email config or ToEmail is not enable!", "");
			}
		}catch(Exception ex) {
			logger.error("Exception at readEmail came: {}", ex.getMessage());
			ex.printStackTrace();
		}
		return readEmail;
		
	}

	public JsonResponse readEmail(String to, String from) {
		logger.info("readEmail");
		JsonResponse readEmail = null;
		try {
			EmailChannel echannels=emailChannelsRepository.findOneBySharedEmail(to);
			if(echannels!=null && echannels.isEnabled())
			{
				if(echannels.getAuthType().equals(EmailChannel.AUTH_TYPE_OAUTH)) {
				   readEmail = graphAPIReadEmailService.readEmail(echannels,from,"Manula-");
					
			  }else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Channel auth type not found!", JsonResponse.STATUS_404);
			 }
			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "ToEmail is not exiting email config or ToEmail is not enable!");
			}
		}catch(Exception ex) {
			logger.error("Exception at readEmail came: {}", ex.getMessage());
			ex.printStackTrace();
		}
		return readEmail;
	}
	
	public JsonResponse readAttachment(String to, String from) {
		JsonResponse readEmail = null;
		try {
			EmailChannel echannels=emailChannelsRepository.findOneByEmail(to);
			if(echannels!=null && echannels.isEnabled())
			{
				if(echannels.getAuthType().equals(EmailChannel.AUTH_TYPE_OAUTH)) {
				   readEmail = graphAPIReadEmailService.getAttachment(echannels,from);
					
			  }else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "Channel auth type not found!", JsonResponse.STATUS_404);
			 }
			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "ToEmail is not exiting email config or ToEmail is not enable!");
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return readEmail;
	}
	
}
