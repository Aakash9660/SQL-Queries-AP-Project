package com.smartdocs.service.util;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class GLAccountGenerator implements IdentifierGenerator {
	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {
		String prefix = "GL_";
		String suffix = "";
		try {
			Connection connection = session.connection();
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select count(id) from glaccount");
			if (resultSet.next()) {
				Integer id = resultSet.getInt(1) + 1;
				suffix = id.toString();
				PreparedStatement preparedStatement = connection
						.prepareStatement("select * from glaccount where id = ?");
				preparedStatement.setString(1, suffix);
				resultSet = preparedStatement.executeQuery();
				if (resultSet.next()) {
					suffix = resultSet.getString(1);
					suffix = getNext(suffix);
					System.out.println(suffix);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prefix + suffix;
	}

	private String getNext(String id) {
		id = id.substring(4);
		return Integer.valueOf(id) + 1 + "";
	}
}
