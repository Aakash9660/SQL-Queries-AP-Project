package com.smartdocs.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;

import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.offbytwo.jenkins.JenkinsServer;
import com.offbytwo.jenkins.model.Build;
import com.offbytwo.jenkins.model.Job;
import com.offbytwo.jenkins.model.JobWithDetails;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.NextExecutionDTO;
import com.smartdocs.jenkins.dto.APBuild;
import com.smartdocs.jenkins.dto.APJobWithDetails;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.JobConfigModel;
import com.smartdocs.model.Robot;
import com.smartdocs.model.TimeSlots;
import com.smartdocs.model.Vault;
import com.smartdocs.model.VendorScript;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.RobotRepository;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.repository.TimeSlotsRepository;
import com.smartdocs.repository.VaultRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.EncryptionDecryption;
import com.smartdocs.service.util.HttpReqRespUtils;
import com.smartdocs.service.util.JKUtil;

@Service
public class JenkinsService1 {

	@Value("${jenkinsUsername1}")
	private String jenkinsServerUsername;

	@Value("${jenkinsPassword1}")
	private String jenkinsServerPassword;

	@Value("${jenkinsUrl1}")
	private String jenkinsServerUrl;

	@Value("${sftpeqactualpath1}")
	private String sftpeqactualpath;

	@Autowired
	private RobotRepository robotRepository;

	@Autowired
	private SystemLogsRepository systemLogsRepository;

	@Autowired
	private TimeSlotsRepository timeSlotsRepository;

	@Value("${sftpHost1}")
	private String sftpHost;

	@Value("${sftpPath1}")
	private String sftpPath;

	@Value("${sftpPort1}")
	private int sftpPort;

	@Value("${sftpUser1}")
	private String sftpUser;

	@Value("${sftpPassword1}")
	private String sftpPassword;

	@Value("${localPathToTransferFile}")
	private String localPathToTransferFile;

	@Value("${protocal1}")
	private String protocal;

	@Value("${baseURL}")
	private String baseURL;

	@Autowired
	private JobConfigService jobConfigService;

	@Autowired
	private VaultRepository vaultRepository;

	public boolean removeFileFromFTP(String txtId, AssetAccount assetAccount, String fileName, String id) {
		// ====================
		String vendorId = assetAccount.getVendorId();
		String accountNo = assetAccount.getAccountNumber();
		String assetCode = assetAccount.getAssetCode();

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		try {

			JSch jSch = new JSch();
			Session session = jSch.getSession(sftpUser, sftpHost, sftpPort);

			session.setConfig("StrictHostKeyChecking", "no");

			session.setPassword(sftpPassword);

			System.out.println("connecting");
			try {
				session.connect();

			} catch (Exception e) {
				SystemLogs systemLogs = new SystemLogs("unPublish file from sftp", e.getLocalizedMessage(),
						ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_ERROR,
						SystemLogs.SYSTEM_TAG_SFTP, user.getEmail(), SystemLogs.USER, accountNo, vendorId, assetCode,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());

				systemLogsRepository.save(systemLogs);
				return false;
			}
			System.out.println("connected");
			Channel channel = session.openChannel(protocal);

			ChannelSftp channelSftp = (ChannelSftp) channel;

			channelSftp.connect();
			System.out.println("remove files ");
			try {
				channelSftp.rm(sftpPath + "/" + fileName);
			} catch (Exception e) {
				SystemLogs systemLogs = new SystemLogs("unPublish file from sftp", e.getLocalizedMessage(),
						ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_ERROR,
						SystemLogs.SYSTEM_TAG_SFTP, user.getEmail(), SystemLogs.USER, accountNo, vendorId, assetCode,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());

				systemLogsRepository.save(systemLogs);
			} finally {
				if (channel != null) {
					Session sess = channel.getSession();
					channel.disconnect();
					sess.disconnect();
					System.out.println(channel.isConnected());
				}
			}

			System.out.println("removed files ");
			SystemLogs systemLogs = new SystemLogs("unPublish file from sftp", fileName + " removed successfully",
					ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_SUCCESS,
					SystemLogs.SYSTEM_TAG_SFTP, user.getEmail(), SystemLogs.USER, accountNo, vendorId, assetCode,
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());

			systemLogsRepository.save(systemLogs);
			return true;
		} catch (Exception e) {

			SystemLogs systemLogs = new SystemLogs("unPublish file from sftp", e.getLocalizedMessage(),
					ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_ERROR,
					SystemLogs.SYSTEM_TAG_SFTP, user.getEmail(), SystemLogs.USER, accountNo, vendorId, assetCode,
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());

			systemLogsRepository.save(systemLogs);
			return false;
		}
		// =============
	}

	public boolean createFileToFTP(String txId, AssetAccount assetAccount, String fileName, String jobId,
			VendorScript vendorScript) {

		String vendorId = assetAccount.getVendorId();
		String accountNo = assetAccount.getAccountNumber();
		String assetCode = assetAccount.getAssetCode();
		String userEmail = "";
		String userName = "";
		try {
			SecurityContext securityContext = SecurityContextHolder.getContext();
			Authentication authentication = securityContext.getAuthentication();
			UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());
			userEmail = user.getEmail();
			userName = user.getName();
		} catch (Exception ex) {

		}

		Long vaultId = assetAccount.getVaultId();
		File file = null;
		double kb = 0;
		try {

			String script = vendorScript.getCodeScript();

			if (script != null) {

				script = script.replace("{{Asset_Code}}", assetAccount.getAssetCode());
				script = script.replace("{{Vendor_ID}}", assetAccount.getVendorId());
				script = script.replace("{{Account_ID}}", assetAccount.getAccountNumber());
				script = script.replace("{{SecondaryAccountNo}}", assetAccount.getSecondaryAccountNumber());
				script = script.replace("{{JOB_ID}}", jobId);
				script = script.replace("{{BaseURL}}", baseURL);

				if (vaultId != null) {
					Optional<Vault> existVault = vaultRepository.findById(vaultId);
					if (existVault.isPresent()) {
						script = script.replace("{{LOGIN_ID}}", existVault.get().getUserId());
						if (existVault.get().getPassword() != null) {
							script = script.replace("{{LOGIN_PWD}}",
									EncryptionDecryption.decrypt(existVault.get().getPassword()));
						} else {
							script = script.replace("{{LOGIN_PWD}}", existVault.get().getPassword());
						}
					}
				}
			}

			String path = localPathToTransferFile + fileName;
			file = new File(path);

			// If file doesn't exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			if (script != null) {
				bw.write(script);
			}
			// Close connection
			bw.close();
			kb = (double) file.length() / 1024;

			if (kb != 0.0) {

				JSch jSch = new JSch();
				Session session = jSch.getSession(sftpUser, sftpHost, sftpPort);
				session.setConfig("StrictHostKeyChecking", "no");
				session.setPassword(sftpPassword);
				System.out.println("connecting");
				Channel channel = null;
				try {
					session.connect();
				} catch (Exception e) {

					SystemLogs systemLogs = new SystemLogs("transfer File To SFTP", e.getLocalizedMessage(),
							ZonedDateTime.now(), txId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_ERROR,
							SystemLogs.SYSTEM_TAG_SFTP, userEmail, SystemLogs.USER, accountNo, vendorId, assetCode,
							HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);
					systemLogsRepository.save(systemLogs);
					return false;
				}
				System.out.println("connected");
				try {

					channel = session.openChannel(protocal);
					ChannelSftp channelSftp = (ChannelSftp) channel;
					channelSftp.connect();
					System.out.println("send files ");

					channelSftp.put(localPathToTransferFile + "/" + file.getName(), sftpPath);
					System.out.println("sent files ");

					SystemLogs systemLogs = new SystemLogs("transfer File To SFTP",
							file.getName() + " file is sent successfully ", ZonedDateTime.now(), txId,
							SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_SFTP,
							userEmail, SystemLogs.USER, accountNo, vendorId, assetCode,
							HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);
					systemLogsRepository.save(systemLogs);
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (channel != null) {
						Session sess = channel.getSession();
						channel.disconnect();
						sess.disconnect();
						System.out.println(channel.isConnected());
					}
				}

				return true;
			} else {

				SystemLogs systemLogs = new SystemLogs("transfer File To SFTP",
						file.getName() + " file size is " + kb
								+ " KB couldn't able send to SFTP server please try again ",
						ZonedDateTime.now(), txId, SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_FAIL,
						SystemLogs.SYSTEM_TAG_SFTP, userEmail, SystemLogs.USER, accountNo, vendorId, assetCode,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);

				systemLogsRepository.save(systemLogs);
				return false;
			}

		} catch (Exception e) {

			SystemLogs systemLogs = new SystemLogs("transfer File To SFTP", e.getMessage(), ZonedDateTime.now(), txId,
					SystemLogs.SYSTEM_TYPE_SFTP, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_SFTP, userEmail,
					SystemLogs.USER, accountNo, vendorId, assetCode,
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);
			systemLogsRepository.save(systemLogs);
			return false;
		}
	}

	public JsonResponse deleteJob(String jobName) throws URISyntaxException, IOException {
		JsonResponse jsonResponse = new JsonResponse();
		JenkinsServer jenkinsServer1 = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
				jenkinsServerPassword);
		JobWithDetails jobWithDetails = jenkinsServer1.getJob(jobName);
		if (jobWithDetails != null) {
			jenkinsServer1.deleteJob(jobName);
			robotRepository.deleteById(jobName);
			jsonResponse.setMessage("Successfully Deleted Job");
			jsonResponse.setStatus(JsonResponse.RESULT_SUCCESS);
			jsonResponse.setStatusCode(JsonResponse.STATUS_200);
			return jsonResponse;
		} else {
			Optional<Robot> robot = robotRepository.findById(jobName);
			if (robot.isPresent()) {
				robotRepository.deleteById(jobName);
			}
			jsonResponse.setMessage("No Job Found");
			jsonResponse.setStatusCode(JsonResponse.STATUS_404);
			return jsonResponse;
		}

	}

	public boolean deleteJenkinsJob(String txtId, AssetAccount assetAccount, String id) {

		boolean isdeleteJob = false;

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		try {

			JenkinsServer jenkinsServer1 = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);

			// our XML file for this example
			JobWithDetails jobWithDetails = jenkinsServer1.getJob(id);
			JobConfigModel config = jobConfigService.getJobConfig();

			if (config != null && config.isSetupJobAuto()) {
				List<TimeSlots> getTimeSlotsOfEachBot = timeSlotsRepository.findByJobId(id);
				if (getTimeSlotsOfEachBot.size() != 0) {
					for (TimeSlots getEachTimeSlot : getTimeSlotsOfEachBot) {
						getEachTimeSlot.setLastExecuted(null);
						getEachTimeSlot.setServerId("");
						getEachTimeSlot.setAllocated(false);
						getEachTimeSlot.setJobId("");
						timeSlotsRepository.save(getEachTimeSlot);
					}
				}
			}
			if (jobWithDetails != null) {
				jenkinsServer1.deleteJob(id, true);

				SystemLogs systemLogs = new SystemLogs("delete Jenkins Job", id + " Job id successfully Deleted",
						ZonedDateTime.now(), txtId, SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_SUCCESS,
						SystemLogs.SYSTEM_TAG_JK, user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(),
						assetAccount.getVendorId(), assetAccount.getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());

				systemLogsRepository.save(systemLogs);
				isdeleteJob = true;

			} else {

				SystemLogs systemLogs = new SystemLogs("delete Jenkins Job",
						id + " Job id Does not exist please create again", ZonedDateTime.now(), txtId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
						assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
						user.getName());

				systemLogsRepository.save(systemLogs);
				isdeleteJob = false;
			}
			jenkinsServer1.close();
		} catch (Exception e) {
			e.printStackTrace();
			SystemLogs systemLogs = new SystemLogs("delete Jenkins Job", e.getLocalizedMessage(), ZonedDateTime.now(),
					txtId, SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK,
					user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
					assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					user.getName());

			systemLogsRepository.save(systemLogs);
			isdeleteJob = false;
		}

		return isdeleteJob;
	}

	public boolean createUpdateJob(JobConfigModel config, Robot robot, String txtId, AssetAccount assetAccount,
			String jobName, String description, String fileName)
			throws ParserConfigurationException, TransformerConfigurationException {
		// + fileName
		String command = "npx playwright test " + fileName + " --headed";
		boolean isCreateUpdateJob = false;

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		try {

			JenkinsServer jenkinsServer1 = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);

			// our XML file for this example
			JobWithDetails jobWithDetailsOfJenkinsServer1 = jenkinsServer1.getJob(jobName);
			String filePath = sftpeqactualpath;
			String jobXml = getXmLOfJenkinsServer();
			jobXml = jobXml.replace("{{customWorkspace}}", filePath);
			jobXml = jobXml.replace("{{command}}", command);
			jobXml = jobXml.replace("{{description}}", description);

//			if (config!=null && config.isSetupJobAuto()) {
//				// 1 get empty time slot.
//				// 2. occupy timeslot
//				List<TimeSlots> getTimeSlotsOfEachBot=timeSlotsRepository.findByJobId(jobName);
//				if(getTimeSlotsOfEachBot.size()!=0) {
//					for(TimeSlots getEachTimeSlot:getTimeSlotsOfEachBot) {
//						getEachTimeSlot.setLastExecuted(null);
//						getEachTimeSlot.setServerId("");
//						getEachTimeSlot.setAllocated(false);
//						getEachTimeSlot.setJobId("");
//						timeSlotsRepository.save(getEachTimeSlot);
//					}
//				}
//				
//				TimeSlots firstTimeSlot = timeSlotsRepository.findFirstOrderById();
//				
//				if (firstTimeSlot != null) {
//					int day = firstTimeSlot.getDay();
//					String cronPattern = getCronPattern(firstTimeSlot.getFromTime(), config.getFrequency(), day);
//					List<TimeSlots> timeSlots = getTimeSlots(firstTimeSlot.getFromTime(), config.getFrequency(), day);
//					for(TimeSlots tSlot:timeSlots) {
//						tSlot.setLastExecuted(ZonedDateTime.now());
//						tSlot.setServerId("1");
//						tSlot.setAllocated(true);
//						tSlot.setJobId(jobName);
//						timeSlotsRepository.save(tSlot);
//					}
//					jobXml=jobXml.replace("{{timeslot}}", cronPattern);
//					robot.setSchedule(true);
//					robot.setJenkinsCommand(cronPattern);
//				} else {
//					jobXml = jobXml.replace("{{timeslot}}", "");
//				}
// 
//			} else {

			jobXml = jobXml.replace("{{timeslot}}", "");
			// }

			System.out.println("jobXml " + jobXml);

			if (jobWithDetailsOfJenkinsServer1 != null) {
				jenkinsServer1.updateJob(jobName, jobXml, true);
				isCreateUpdateJob = true;

				SystemLogs systemLogs = new SystemLogs("Update Job in Jenkins server 1",
						jobName + " job is successfully updated", ZonedDateTime.now(), txtId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
						assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
						user.getName());
				systemLogsRepository.save(systemLogs);
			} else {
				jenkinsServer1.createJob(jobName, jobXml, true);
				isCreateUpdateJob = true;

				SystemLogs systemLogs = new SystemLogs("create Job in Jenkins server 1",
						jobName + " job is successfully created", ZonedDateTime.now(), txtId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
						assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
						user.getName());
				systemLogsRepository.save(systemLogs);
			}

			jenkinsServer1.close();

			return isCreateUpdateJob;
		} catch (Exception e) {
			e.printStackTrace();
			isCreateUpdateJob = false;

			SystemLogs systemLogs = new SystemLogs("create or Update Job", e.getMessage(), ZonedDateTime.now(), txtId,
					SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK,
					user.getEmail(), SystemLogs.USER, assetAccount.getAccountNumber(), assetAccount.getVendorId(),
					assetAccount.getAssetCode(), HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
					user.getName());

			systemLogsRepository.save(systemLogs);
			return isCreateUpdateJob;
		}

	}

	public JsonResponse run(String jobId, String txId) throws URISyntaxException, IOException, InterruptedException {
		System.out.println("get job detail");

		SecurityContext securityContext = SecurityContextHolder.getContext();
		Authentication authentication = securityContext.getAuthentication();
		UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());

		Optional<Robot> robotDetails = robotRepository.findById(jobId);

		JsonResponse jsonResponse = new JsonResponse();
		JobWithDetails jobWithDetails = null;

		try {
			JenkinsServer jenkins = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);

			jobWithDetails = jenkins.getJob(jobId);
			if (jobWithDetails != null) {
				jobWithDetails.build(true);
				System.out.println(jobWithDetails);
				Thread.sleep(30000);

				SystemLogs systemLogs = new SystemLogs("Run the job in JK1",
						"Build run status is " + jobWithDetails.getLastBuild().details().getResult().toString(),
						ZonedDateTime.now(), txId, SystemLogs.SYSTEM_TYPE_JENKINS,
						jobWithDetails.getLastBuild().details().getResult().toString(), SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, robotDetails.get().getAccountNo(),
						robotDetails.get().getVendorId(), robotDetails.get().getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());
				systemLogsRepository.save(systemLogs);
				jsonResponse.setResult(jobWithDetails.getLastBuild().details().getResult());
				if (jobWithDetails.getLastBuild().details().getResult() != null) {
					jsonResponse.setMessage(jobWithDetails.getLastBuild().details().getResult().toString());
				}
				jsonResponse.setStatusCode(JsonResponse.STATUS_200);
				return jsonResponse;
			} else {
				SystemLogs systemLogs = new SystemLogs("Run the job in JK1",
						jobId + " Job id doesn't exist please create a job", ZonedDateTime.now(), txId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_FAIL, SystemLogs.SYSTEM_TAG_JK,
						user.getEmail(), SystemLogs.USER, robotDetails.get().getAccountNo(),
						robotDetails.get().getVendorId(), robotDetails.get().getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());
				systemLogsRepository.save(systemLogs);
				jsonResponse.setMessage(jobId + " Job id doesn't exist please create a job");
				jsonResponse.setStatusCode(JsonResponse.STATUS_404);
				return jsonResponse;
			}
		} catch (Exception e) {
			SystemLogs systemLogs = new SystemLogs("Run the job in JK1", e.getLocalizedMessage(), ZonedDateTime.now(),
					txId, SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK,
					user.getEmail(), SystemLogs.USER, robotDetails.get().getAccountNo(),
					robotDetails.get().getVendorId(), robotDetails.get().getAssetCode(),
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), user.getName());
			systemLogsRepository.save(systemLogs);
			if (e.getLocalizedMessage() != null) {
				jsonResponse.setMessage(e.getLocalizedMessage());
			} else {
				jsonResponse.setMessage("Connection time out");
			}
			jsonResponse.setStatusCode(JsonResponse.STATUS_500);
			return jsonResponse;
		}
	}

	private String getDayPatterm(int f, int day) {
		int a = 0;
		if (f == 2) {
			a = 14;
		}
		if (f == 3) {
			a = 10;
		}
		if (f == 4) {
			a = 7;
		}

		String resp = null;
		for (int i = 1; i <= f; i++) {
			if (resp == null) {
				resp = String.valueOf((a * i - a) + day);
			} else {
				resp = resp + "," + ((a * i - a) + day);
			}
		}
		return resp;

	}

	public JobWithDetails getJobDetail(String jobId) {
		System.out.println("get job detail");
		JobWithDetails jobWithDetails = null;
		try {
			JenkinsServer jenkins = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);
			jobWithDetails = jenkins.getJob(jobId);
			System.out.println(jobWithDetails);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("good");
		return jobWithDetails;
	}

	public APJobWithDetails getJobHistoryDetails(String jobId) {
		APJobWithDetails resp = null;
		try {
			JenkinsServer jenkins = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);
			URL url = new URL(jenkinsServerUrl + "job/" + jobId + "/api/json");
			String authStr = jenkinsServerUsername + ":" + jenkinsServerPassword;
			String encoding = Base64.getEncoder().encodeToString(authStr.getBytes("utf-8"));

			StringBuilder body = null;
			String line = "";

			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestProperty("Authorization", "Basic " + encoding);
			if (connection.getResponseCode() == 200) {
				InputStream content = connection.getInputStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(content));
				body = new StringBuilder();
				while ((line = br.readLine()) != null) {
					System.out.println("line :" + line);
					body.append(line);
				}

				connection.disconnect();

				ObjectMapper mapper = new ObjectMapper();
				mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				resp = mapper.readValue(body.toString(), APJobWithDetails.class);
				JobWithDetails jobWithDetails = jenkins.getJob(jobId);
				if (jobWithDetails != null) {
					List<Build> builds = jobWithDetails.getAllBuilds();
					List<APBuild> apBuilds = resp.getBuilds();

					System.out.println(builds.size());
					Build build = builds.get(0);
					build.details().getResult();
					int count = 0;

					for (count = builds.size() - 1; count >= 0; count--) {
						try {
							apBuilds.get(count).setTimeStamp(new Timestamp(builds.get(count).details().getTimestamp()));
							apBuilds.get(count).setStatus(builds.get(count).details().getResult().toString());

						} catch (Exception e) {
							apBuilds.get(count).setStatus("Running");
						}
					}

					if (jobWithDetails.getFirstBuild().details().getTimestamp() != 0) {
						resp.getFirstBuild()
								.setTimeStamp(new Timestamp(jobWithDetails.getFirstBuild().details().getTimestamp()));
						try {
							resp.getFirstBuild()
									.setStatus(jobWithDetails.getFirstBuild().details().getResult().toString());
						} catch (Exception e) {
							resp.getFirstBuild().setStatus("Running");
						}
					}

					if (jobWithDetails.getLastCompletedBuild().details().getTimestamp() != 0) {
						resp.getLastCompletedBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastCompletedBuild().details().getTimestamp()));
						resp.getLastCompletedBuild()
								.setStatus(jobWithDetails.getLastCompletedBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastFailedBuild().details().getTimestamp() != 0) {
						resp.getLastFailedBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastFailedBuild().details().getTimestamp()));
						resp.getLastFailedBuild()
								.setStatus(jobWithDetails.getLastFailedBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastStableBuild().details().getTimestamp() != 0) {
						resp.getLastStableBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastStableBuild().details().getTimestamp()));
						resp.getLastStableBuild()
								.setStatus(jobWithDetails.getLastStableBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastSuccessfulBuild().details().getTimestamp() != 0) {
						resp.getLastSuccessfulBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastSuccessfulBuild().details().getTimestamp()));
						resp.getLastSuccessfulBuild()
								.setStatus(jobWithDetails.getLastSuccessfulBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastUnstableBuild().details().getTimestamp() != 0) {
						resp.getLastUnstableBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastUnstableBuild().details().getTimestamp()));
						resp.getLastUnstableBuild()
								.setStatus(jobWithDetails.getLastUnstableBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastUnsuccessfulBuild().details().getTimestamp() != 0) {
						resp.getLastUnsuccessfulBuild().setTimeStamp(
								new Timestamp(jobWithDetails.getLastUnsuccessfulBuild().details().getTimestamp()));
						resp.getLastUnsuccessfulBuild()
								.setStatus(jobWithDetails.getLastUnsuccessfulBuild().details().getResult().toString());
					}
					if (jobWithDetails.getLastBuild().details().getTimestamp() != 0) {
						resp.getLastBuild()
								.setTimeStamp(new Timestamp(jobWithDetails.getLastBuild().details().getTimestamp()));
						try {
							resp.getLastBuild()
									.setStatus(jobWithDetails.getLastBuild().details().getResult().toString());
						} catch (Exception e) {
							resp.getLastBuild().setStatus("Running");
						}
					}
				}
				System.out.println(resp);

			}
		} catch (Exception e) {

			// TODO: handle exception
		}

		return resp;
	}

	public String getBuildConsole(int buildId, String jobId) throws URISyntaxException, IOException {
		String jsonResponse = null;
		JenkinsServer jenkins = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
				jenkinsServerPassword);
		JobWithDetails jobWithDetails = jenkins.getJob(jobId);
		if (jobWithDetails != null) {
			Build build = jobWithDetails.getBuildByNumber(buildId);
			if (build != null) {
				jsonResponse = build.details().getConsoleOutputText();

			}
		}
		return jsonResponse;
	}

	private String getCronPattern(String startTime, int freq, int day) {
		String time[] = startTime.split("_");
		return time[1] + " " + time[0] + " " + getDayPatterm(freq, day) + " * *";
	}

	private String getXmLOfJenkinsServer() {
		String configXML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><project>\r\n"
				+ "<actions/>\r\n" + "<description>{{description}}</description>n"
				+ "<keepDependencies>false</keepDependencies>\r\n" + "<properties/>\r\n"
				+ "<scm class=\"hudson.scm.NullSCM\"/>\r\n" + "<canRoam>true</canRoam>\r\n"
				+ "<disabled>false</disabled>\r\n"
				+ "<blockBuildWhenDownstreamBuilding>false</blockBuildWhenDownstreamBuilding>\r\n"
				+ "<blockBuildWhenUpstreamBuilding>false</blockBuildWhenUpstreamBuilding>\r\n" + "{{triggerXML}}"
				+ "<triggers>\r\n" + "<hudson.triggers.TimerTrigger>\r\n" + "<spec>{{timeslot}}</spec>\r\n"// 15 16
																											// 8-14,22-28
																											// * 1
				+ "</hudson.triggers.TimerTrigger>\r\n" + "</triggers>\r\n"
				+ "<concurrentBuild>false</concurrentBuild>\r\n"
				+ "<customWorkspace>{{customWorkspace}}</customWorkspace>\r\n" + "<builders>\r\n"
				+ "<hudson.tasks.BatchFile>\r\n" + "<command>{{command}}</command>\r\n" + "<configuredLocalRules/>\r\n"
				+ "</hudson.tasks.BatchFile>\r\n" + "</builders>\r\n" + "<publishers/>\r\n" + "<buildWrappers/>\r\n"
				+ "\r\n" + "</project>";

		return configXML;
	}

	public String getJobDuration(String jobId) throws URISyntaxException, IOException {

		URL url = new URL(jenkinsServerUrl + "job/" + jobId + "/lastBuild/api/json?pretty=true"); // Jenkins URL
		String authStr = jenkinsServerUsername + ":" + jenkinsServerPassword;
		String encoding = Base64.getEncoder().encodeToString(authStr.getBytes("utf-8"));

		StringBuilder body = null;
		String line = "";

		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestProperty("Authorization", "Basic " + encoding);
		if (connection.getResponseCode() == 200) {
			InputStream content = connection.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(content));
			body = new StringBuilder();
			while ((line = br.readLine()) != null) {
				System.out.println("line :" + line);
				body.append(line);
			}

			connection.disconnect();
			JSONObject jsonObject = new JSONObject(body.toString());

			int getDurationTIme = (int) jsonObject.get("duration");

			Duration duration = Duration.ofMillis(getDurationTIme);
			String executionTime = String.format("%02d:%02d:%02d", duration.getSeconds() / 3600,
					((duration.getSeconds()) % 3600) / 60, ((duration.getSeconds()) % 60));
			return executionTime;
		} else {
			return jobId + " job haven't executed till now";
		}
	}

	public JsonResponse getRobot(String assetCode, String accountNumber, String vendorId)
			throws URISyntaxException, IOException {

		Robot robot = robotRepository.findOneByAssetCodeAndAccountNumberAndVendorId(assetCode, accountNumber, vendorId);
		try {
			if (robot != null) {
				String botName = robot.getId();// assetCode + "-" + vendorId + "-"+ accountNumber;
				JenkinsServer jenkins = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
						jenkinsServerPassword);
				JobWithDetails jobWithDetails = jenkins.getJob(botName);
				if (jobWithDetails != null) {
					return new JsonResponse(robot, JsonResponse.RESULT_SUCCESS, "Bot exist", JsonResponse.STATUS_200);
				} else {
					return new JsonResponse(JsonResponse.RESULT_FAILED, "Bot doesn't exist", JsonResponse.STATUS_404);
				}

			}
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Bot details not found", JsonResponse.STATUS_404);

		} catch (Exception e) {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Connection time out", JsonResponse.STATUS_500);
		}
	}

	public void deleteAllJobsInJenkinsServer() {
		try {
			JenkinsServer jenkinsServer1 = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);

			Map<String, Job> getJobsFromJenkinsServer1 = jenkinsServer1.getJobs();
			for (Map.Entry<String, Job> entry : getJobsFromJenkinsServer1.entrySet()) {
				jenkinsServer1.deleteJob(entry.getKey(), true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String getJenkinsURL() {
		return jenkinsServerUrl;
	}

	private List<TimeSlots> getTimeSlots(String startTime, int freq, int day) {
		// String time[] = startTime.split("_");
		String dayPatterm = getDayPatterm(freq, day);
		String[] split = dayPatterm.split(",");
		List<Long> slots = new ArrayList<>();

		for (String i : split) {
			slots.add(Long.parseLong((i + startTime).replace("_", "")));
		}
		return timeSlotsRepository.findByIdIn(slots);
	}

	public boolean createUpdateAndScedulingJob(boolean schedule, Robot robot, String fileName) {
		String command = "npx playwright test " + fileName + " --headed";
		boolean isCreateUpdateJob = false;
		try {
			JenkinsServer jenkinsServer1 = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);
			JobWithDetails jobWithDetailsOfJenkinsServer1 = jenkinsServer1.getJob(robot.getId());
			String filePath = sftpeqactualpath;
			String jobXml = getXmLOfJenkinsServer();
			jobXml = jobXml.replace("{{customWorkspace}}", filePath);
			jobXml = jobXml.replace("{{command}}", command);
			jobXml = jobXml.replace("{{description}}", "");

			if (schedule) {
				unBookingSlots(robot.getId());
				String cronPattern = bookingSlots(robot.getId());
				if (cronPattern != null) {
					jobXml = jobXml.replace("{{timeslot}}", cronPattern);
					robot.setSchedule(true);
					robot.setJenkinsCommand(cronPattern);
				} else {
					robot.setSchedule(false);
					robot.setJenkinsCommand(null);
					jobXml = jobXml.replace("{{timeslot}}", "");
				}
			} else {
				unBookingSlots(robot.getId());
				robot.setSchedule(false);
				robot.setJenkinsCommand(null);
				jobXml = jobXml.replace("{{timeslot}}", "");
			}
			if (jobWithDetailsOfJenkinsServer1 != null) {
				robot.setStatus(Robot.STATUS_PUBLISHED);
				jenkinsServer1.updateJob(robot.getId(), jobXml, true);
			} else {
				if (schedule) {
					robot.setStatus(Robot.STATUS_PUBLISHED);
					jenkinsServer1.createJob(robot.getId(), jobXml, true);
				}
			}
			jenkinsServer1.close();
			isCreateUpdateJob = true;

		} catch (Exception e) {
			e.printStackTrace();
			isCreateUpdateJob = false;
		}
		return isCreateUpdateJob;
	}
	public boolean createUpdateAndScedulingJobUnscheduleAll(String botId ,String fileName) {
		String command = "npx playwright test " + fileName + " --headed";
		boolean isCreateUpdateJob = false;
		try {
			JenkinsServer jenkinsServer1 = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);
			JobWithDetails jobWithDetailsOfJenkinsServer1 = jenkinsServer1.getJob(botId);
			String filePath = sftpeqactualpath;
			String jobXml = getXmLOfJenkinsServer();
			jobXml = jobXml.replace("{{customWorkspace}}", filePath);
			jobXml = jobXml.replace("{{command}}", command);
			jobXml = jobXml.replace("{{description}}", "");
			jobXml = jobXml.replace("{{timeslot}}", "");
			
			if (jobWithDetailsOfJenkinsServer1 != null) {
				jenkinsServer1.updateJob(botId, jobXml, true);
			} 
			jenkinsServer1.close();
			isCreateUpdateJob = true;

		} catch (Exception e) {
			e.printStackTrace();
			isCreateUpdateJob = false;
		}
		return isCreateUpdateJob;
	}
	public boolean createUpdateAndScedulingJobUnscheduleAll(List<Robot> robots) {
		
		boolean isCreateUpdateJob = false;
		try {
			JenkinsServer jenkinsServer1 = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);
			
			for(Robot robot:robots) {
				
				JobWithDetails jobWithDetailsOfJenkinsServer1 = jenkinsServer1.getJob(robot.getId());
				if (jobWithDetailsOfJenkinsServer1 != null) {
					String fileName =JKUtil.getScriptFileName(robot); 
					String filePath = sftpeqactualpath;
					String command = "npx playwright test " + fileName + " --headed";
					String jobXml = getXmLOfJenkinsServer();
					jobXml = jobXml.replace("{{customWorkspace}}", filePath);
					jobXml = jobXml.replace("{{command}}", command);
					jobXml = jobXml.replace("{{description}}", "");
					jobXml = jobXml.replace("{{timeslot}}", "");
					jenkinsServer1.updateJob(robot.getId(), jobXml, true);
				} 
			}
			jenkinsServer1.close();
			isCreateUpdateJob = true;

		} catch (Exception e) {
			e.printStackTrace();
			isCreateUpdateJob = false;
		}
		return isCreateUpdateJob;
	}
	private String bookingSlots(String jobId) {
		JobConfigModel jcm = jobConfigService.getJobConfig();
		TimeSlots firstTimeSlot = timeSlotsRepository.findFirstOrderById();
		String cronPattern = null;
		if (firstTimeSlot != null) {
			int day = firstTimeSlot.getDay();
			cronPattern = getCronPattern(firstTimeSlot.getFromTime(), jcm.getFrequency(), day);
			List<TimeSlots> timeSlots = getTimeSlots(firstTimeSlot.getFromTime(), jcm.getFrequency(), day);
			for (TimeSlots tSlot : timeSlots) {
				tSlot.setLastExecuted(ZonedDateTime.now());
				tSlot.setServerId("1");
				tSlot.setAllocated(true);
				tSlot.setJobId(jobId);
				timeSlotsRepository.save(tSlot);
			}
		}
		return cronPattern;
	}

	private void unBookingSlots(String jobId) {
		List<TimeSlots> timeslosts = timeSlotsRepository.findByJobId(jobId);
		if (timeslosts != null) {
			for (TimeSlots timeslost : timeslosts) {
				timeslost.setLastExecuted(null);
				timeslost.setServerId(null);
				timeslost.setAllocated(false);
				timeslost.setJobId(null);
				timeSlotsRepository.save(timeslost);
			}
		}

	}

	public List<NextExecutionDTO> getNextExec() {
		return getHTMLNode(jenkinsServerUrl, jenkinsServerUsername, jenkinsServerPassword, "next-exec");
	}
	public List<NextExecutionDTO> getHTMLNode(String url, String userId, String password, String extractNode) {
		try {
			url = url + "/";
			String encodedCred = Base64.getEncoder().encodeToString((userId + ":" + password).getBytes("utf-8"));
			return getHTMLNode(url, encodedCred, extractNode);
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}

	private List<NextExecutionDTO> getHTMLNode(String url, String cred, String extractNode) throws IOException {
		List<NextExecutionDTO> nextExecutionList = new ArrayList<>();
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm");
			Document doc = Jsoup.connect(url).header("Authorization", "Basic " + cred).get();
			Element div = doc.getElementById("next-exec");
			Elements tableRows = div.getElementsByTag("tr");
			for (Element tableRow : tableRows) {
				NextExecutionDTO nextExecution = new NextExecutionDTO();
				nextExecution.setJobId(tableRow.getElementsByTag("a").text());
				nextExecution.setDate(tableRow.getAllElements().get(3).text());
				try {
					String dt=nextExecution.getDate().replace("UTC","").trim();
					nextExecution.setDt(LocalDate.parse(dt, formatter).atStartOfDay(ZoneId.systemDefault()));
				}catch(Exception ex) {
					
				}
				nextExecution.setExecuteIn(tableRow.getAllElements().get(3).attr("tooltip"));
				nextExecutionList.add(nextExecution);
			}
		} catch (Exception e) {

		}
		return nextExecutionList;
	}
	public String getNextExecv1() {
		return getHTMLNodev1(jenkinsServerUrl, jenkinsServerUsername, jenkinsServerPassword, "next-exec");
	}
	public String getHTMLNodev1(String url, String userId, String password, String extractNode) {
		try {
			url = url + "/";
			String encodedCred = Base64.getEncoder().encodeToString((userId + ":" + password).getBytes("utf-8"));
			return getHTMLNodeV1(url, encodedCred, extractNode);
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}

	}
	private String getHTMLNodeV1(String url, String cred, String extractNode) throws IOException {
		try {
			Document doc = Jsoup.connect(url).header("Authorization", "Basic " + cred).get();
			Element div = doc.getElementById("next-exec");
			return div.toString();
		} catch (Exception e) {

		}
		return null;
	}

	public boolean publishBot(Robot robot, String txtId, String jobName, String fileName, String userName,
			String userEmail) {
		String command = "npx playwright test " + fileName + " --headed";
		boolean isCreateUpdateJob = false;
		try {
			JenkinsServer jenkinsServer1 = new JenkinsServer(new URI(jenkinsServerUrl), jenkinsServerUsername,
					jenkinsServerPassword);

			// our XML file for this example
			JobWithDetails jobWithDetailsOfJenkinsServer1 = jenkinsServer1.getJob(jobName);
			String filePath = sftpeqactualpath;
			String jobXml = getXmLOfJenkinsServer();
			jobXml = jobXml.replace("{{customWorkspace}}", filePath);
			jobXml = jobXml.replace("{{command}}", command);
			jobXml = jobXml.replace("{{description}}", "");
			jobXml = jobXml.replace("{{timeslot}}", "");

			System.out.println("jobXml " + jobXml);

			if (jobWithDetailsOfJenkinsServer1 != null) {
				jenkinsServer1.updateJob(jobName, jobXml, true);
				isCreateUpdateJob = true;

				SystemLogs systemLogs = new SystemLogs("Update Job in Jenkins server 1",
						jobName + " job is successfully updated", ZonedDateTime.now(), txtId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_JK,
						userEmail, SystemLogs.USER, robot.getAccountNo(), robot.getVendorId(), robot.getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);
				systemLogsRepository.save(systemLogs);
			} else {
				jenkinsServer1.createJob(jobName, jobXml, true);
				isCreateUpdateJob = true;

				SystemLogs systemLogs = new SystemLogs("create Job in Jenkins server 1",
						jobName + " job is successfully created", ZonedDateTime.now(), txtId,
						SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_SUCCESS, SystemLogs.SYSTEM_TAG_JK,
						userEmail, SystemLogs.USER, robot.getAccountNo(), robot.getVendorId(), robot.getAssetCode(),
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);
				systemLogsRepository.save(systemLogs);
			}

			jenkinsServer1.close();

			return isCreateUpdateJob;
		} catch (Exception e) {
			e.printStackTrace();
			isCreateUpdateJob = false;

			SystemLogs systemLogs = new SystemLogs("create or Update Job", e.getMessage(), ZonedDateTime.now(), txtId,
					SystemLogs.SYSTEM_TYPE_JENKINS, SystemLogs.SYSTEM_TYPE_ERROR, SystemLogs.SYSTEM_TAG_JK, userEmail,
					SystemLogs.USER, robot.getAccountNo(), robot.getVendorId(), robot.getAssetCode(),
					HttpReqRespUtils.getClientIpAddressIfServletRequestExist(), userName);
			systemLogsRepository.save(systemLogs);
			return isCreateUpdateJob;
		}

	}
}
