package com.smartdocs.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.JobConfigModel;
import com.smartdocs.repository.JobConfigRepository;

@Service
public class JobConfigService {

	@Autowired
	private JobConfigRepository jobConfigRepository;

	public JsonResponse updateJobConfig(JobConfigModel jobConfig) {
		if(jobConfig!=null) {
			jobConfig.setId(100L);
			jobConfigRepository.save(jobConfig);
			return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Job Config Updated", JsonResponse.STATUS_200);
		}else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, "Job Config Details Doesn't Exist", JsonResponse.STATUS_404);
		}
	}

	public JsonResponse getJobConfig(long id) {
	Optional<JobConfigModel> jobConfigModel=	jobConfigRepository.findById(id);
		if(jobConfigModel.isPresent()) {
		 return new JsonResponse(jobConfigModel.get(),JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200);
		}else {
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Job Config Details Doesn't Exist", JsonResponse.STATUS_404);
	
		}
	}

	public JobConfigModel getJobConfig() {
			Optional<JobConfigModel> jobConfigModel=jobConfigRepository.findById(100L);
			if(jobConfigModel.isPresent()) {
				return jobConfigModel.get();
			}else {
				return new JobConfigModel(24,5,4);
			}
		}
	
}
