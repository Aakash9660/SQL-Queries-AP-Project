package com.smartdocs.service;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.smartdocs.model.SmartStoreConfigurator;
import com.smartdocs.service.util.RSAUtil;

@Service
public class DocumentUploadService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DocumentUploadService.class);

	public String buildURL(SmartStoreConfigurator smartStoreConfigurator, String documentId, String method,
			String fileName) {
		LOGGER.info("DocumentUploadService -> buildURL");
		if (smartStoreConfigurator.getExpiration() != null
				&& !smartStoreConfigurator.getExpiration().equalsIgnoreCase("ssp=true")) {
			return buildURL(smartStoreConfigurator, documentId, method);
		}
		String expiration = null;
		String secKey = null;
		String url = "";
		String fileextension = "";
		try {
			expiration = convertLocalTimeToUTCPlus(10);
			if (fileName != null) {
				fileextension = getFileExtension(fileName);
			}
			String appendedText = null;
			url = smartStoreConfigurator.getServerURL();
			url = url + "" + smartStoreConfigurator.getSystem() + "?" + method;

			url = url + "&pVersion=" + smartStoreConfigurator.getPVersion();
			url = url + "&contRep=" + smartStoreConfigurator.getContRep();
			url = url + "&docId=" + documentId;

			if (method.equals("create")) {
				url = url + "&compId=" + smartStoreConfigurator.getCompId() + fileextension;
				url = url + "&docProt=rud";
				url = url + "&accessMode=c";
				appendedText = smartStoreConfigurator.getContRep() + documentId + smartStoreConfigurator.getCompId()
						+ fileextension + "rud" + "c" + smartStoreConfigurator.getAuthId().replace("%3D", "=")
						+ expiration;
			} else {
				url = url + "&accessMode=r";
				appendedText = smartStoreConfigurator.getContRep() + documentId + "r"
						+ smartStoreConfigurator.getAuthId().replace("%3D", "=") + expiration;
			}
			url = url + "&authId=" + smartStoreConfigurator.getAuthId();
			url = url + "&expiration=" + expiration;
			url = url + "&ssp=true";

			String publicKey = smartStoreConfigurator.getSecKey();
			secKey = RSAUtil.encryptMessage(appendedText, publicKey);
			url = url + "&secKey=" + secKey;
		} catch (Exception e) {
			LOGGER.error("Exception during building URL: {}", e.getMessage());
			e.printStackTrace();
		}

		return url;
	}

	public String buildURL(SmartStoreConfigurator smartStoreConfigurator, String documentId, String method) {
		LOGGER.info("DocumentUploadService -> buildURL");
		String url = "";
		String expiration = "";
		try {
			expiration = convertLocalTimeToUTCPlus(10);
		} catch (Exception e) {
			LOGGER.error("Exception while converting local time to UTC: {}", e.getMessage());
			e.printStackTrace();
		}
		url = smartStoreConfigurator.getServerURL();
		url = url + "" + smartStoreConfigurator.getSystem() + "?" + method;

		url = url + "&pVersion=" + smartStoreConfigurator.getPVersion();
		url = url + "&contRep=" + smartStoreConfigurator.getContRep();
		url = url + "&docId=" + documentId;
		url = url + "&compId=" + smartStoreConfigurator.getCompId();
		url = url + "&docProt=rud";
		if (method.equals("create")) {
			url = url + "&accessMode=c";
		} else {
			url = url + "&accessMode=r";
		}

		url = url + "&authId=" + smartStoreConfigurator.getAuthId();
		url = url + "&expiration=" + expiration;
		url = url + "&sp=true";
		url = url + "&secKey=" + smartStoreConfigurator.getSecKey();

		return url;
	}

	public static String convertLocalTimeToUTCPlus(int minuts) throws Exception {
		final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

		return sdf.format(addHoursToJavaUtilDate(new Date(), minuts));

	}

	public static Date addHoursToJavaUtilDate(Date date, int minuts) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MINUTE, minuts);
		return calendar.getTime();
	}

	public static String getFileExtension(String fileName) {

		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
			return "." + fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
		else
			return "";
	}
	
	public int uploadFile(String url,  ByteArrayOutputStream in, String conenttype) {
		int responceCode = 0;
		HttpURLConnection httpcon = null;
		try {
			httpcon = (HttpURLConnection) (new URL(url).openConnection());
			httpcon.setRequestProperty("User-Agent",
					"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
			httpcon.setRequestMethod("PUT");
			httpcon.setReadTimeout(100000);
			httpcon.setDoOutput(true);
			httpcon.setRequestProperty("Content-Type", conenttype);
			httpcon.connect();
			OutputStream os = httpcon.getOutputStream();

			os.write(in.toByteArray(), 0, in.size());

			responceCode = httpcon.getResponseCode();

			httpcon.disconnect();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (httpcon != null)
				httpcon.disconnect();
		}
		return responceCode;
	}

}
