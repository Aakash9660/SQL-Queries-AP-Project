package com.smartdocs.service;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.graph.logger.DefaultLogger;
import com.microsoft.graph.models.Attachment;
import com.microsoft.graph.models.FileAttachment;
import com.microsoft.graph.models.Message;
import com.microsoft.graph.requests.MessageCollectionResponse;
import com.microsoft.graph.serializer.DefaultSerializer;
import com.nimbusds.oauth2.sdk.http.HTTPResponse;
import com.smartdocs.dto.DocumentHelper;
import com.smartdocs.dto.EmailDTO;
import com.smartdocs.dto.EmailRequestDTO;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.EmailChannel;
import com.smartdocs.repository.EmailChannelRepository;

@Service
public class GraphAPIReadEmailService {

	@Autowired
	private EmailChannelRepository emailChannelsRepository;
	
	@Value("${graph.appId}")
	private String graphAppClientId;

	@Value("${graph.appSecreat}")
	private String graphAppSecreat;

	@Value("${graph.oauth.redirectURI}")
	private String redirectURI;

	@Value("${graph.tenantId}")
	private String tenantId;

	private final String OTP_REG = "[0-9a-zA-Z]*[0-9]+[0-9a-zA-Z]*";

	private static final Logger logger = LoggerFactory.getLogger(GraphAPIReadEmailService.class);

	public JsonResponse readEmail(EmailChannel emailConfig, String from, String jobId) throws IOException {
		getAttachment(emailConfig, from);
		logger.info("readEmail : {} ", emailConfig.getEmail());
		String otp = "";
		Map<Object, Object> oauthAuthentication = oauthAuthentication(emailConfig);
		Object messageResponse = oauthAuthentication.get("responseObject");
		String accessToken = oauthAuthentication.get("accessToken").toString();
		MessageCollectionResponse messageCollectionResponse = (MessageCollectionResponse) messageResponse;
		List<Message> values = messageCollectionResponse.values();
		String messageId = "";
		for (Message message : values) {
			if (message.from.emailAddress.address.equals(from)) {
				messageId = message.id;
				ZonedDateTime now = ZonedDateTime.now();
				ZoneOffset offset = ZoneId.systemDefault().getRules().getOffset(now.toInstant());
				ZonedDateTime dateInMyZone = now.withZoneSameInstant(offset);
				OffsetDateTime offsetDateTime = dateInMyZone.toOffsetDateTime();
				OffsetDateTime minusMinutes = offsetDateTime.minusMinutes(10);
				if (minusMinutes.isBefore(message.receivedDateTime)) {
					String messageContent = message.bodyPreview.toString();
					otp = getOTP(messageContent, OTP_REG);
					break;
				}

			} else {
				return new JsonResponse(JsonResponse.RESULT_FAILED, "From email not found!", JsonResponse.STATUS_404);
			}
		}
		if (!StringUtils.isEmpty(otp)) {
			updateMessageAsRead(accessToken, messageId,emailConfig);
			return new JsonResponse(otp, JsonResponse.RESULT_SUCCESS, "OTP get successfully!", JsonResponse.STATUS_200);
		}
		return new JsonResponse(otp, JsonResponse.RESULT_FAILED, "OTP not recieved!", JsonResponse.STATUS_500);

	}

	public JsonResponse readEmailTest(EmailChannel emailConfig, EmailRequestDTO emailRequestDTO) {
		logger.info("readEmail : {} ", emailConfig.getEmail());
		String otp = "";
		Map<Object, Object> oauthAuthentication = oauthAuthentication(emailConfig);

		Object messageResponse = oauthAuthentication.get("responseObject");
		String accessToken = oauthAuthentication.get("accessToken").toString();
		MessageCollectionResponse messageCollectionResponse = (MessageCollectionResponse) messageResponse;
		List<Message> values = messageCollectionResponse.values();
		System.out.println(values.size());
		String messageId = "";
		JsonResponse jsonResponse = null;
		if (!values.isEmpty()) {
			for (Message message : values) {
				if (message.from.emailAddress.address.equals(emailRequestDTO.getFrom())) {
					String bodyContent = message.body.content;
					String bodyPreview = message.bodyPreview;
					EmailDTO emailDTO = new EmailDTO();
					messageId = message.id;
					 
						otp = getOTP(bodyPreview, getRegx(emailRequestDTO.getVendorId()));
						emailDTO.setReg(getRegx(emailRequestDTO.getVendorId()));
						emailDTO.setOtp(otp);
						emailDTO.setBodyContent(bodyContent);
						updateMessageAsRead(accessToken, messageId,emailConfig);
						return new JsonResponse(emailDTO, JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200);
					 
				} else {
					jsonResponse = new JsonResponse(JsonResponse.RESULT_FAILED, "Not From email found!",
							JsonResponse.STATUS_404);
				}

			}

		} else {
			jsonResponse = new JsonResponse(JsonResponse.RESULT_FAILED, "Not any unread email found!",
					JsonResponse.STATUS_404);
		}
		return jsonResponse;
	}

	private String getOTP(String message, String regex) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(message);
		String otp = "Not Found!";
		while (matcher.find()) {
			otp = matcher.group();
		}
		return otp;
	}

	public Map<Object, Object> oauthAuthentication(EmailChannel emailConfig) {
		MessageCollectionResponse responseObject = null;
		HashMap<Object, Object> map = new HashMap<>();
		String accessToken = "";
		try {
			// check expire time
			if (emailConfig.getExpires_in() < System.currentTimeMillis()) {

				JSONObject jsonObject = OauthUtils.refreshIMAPToken(emailConfig.getRefresh_token(), graphAppClientId,
						graphAppSecreat, tenantId, emailConfig.getRedirectURI());
				if (jsonObject == null) {
					logger.info("Token is null...");
				} else {
					Object accessTokenObj = jsonObject.get("access_token");
					if (accessTokenObj != null) {
						String accesstoken = (String) accessTokenObj;
						String refreshtoken = (String) jsonObject.get("refresh_token");
						Integer expiresIn = (Integer) jsonObject.get("expires_in");
						logger.debug("accessToken : {} ", accesstoken);
						logger.debug("refresh token : {}", refreshtoken);
						long expireTime = System.currentTimeMillis() + (expiresIn * 900);
						accessToken = accesstoken;
						emailConfig.setAccess_token(accesstoken);
						emailConfig.setRefresh_token(refreshtoken);
						emailConfig.setExpires_in(expireTime);
						emailConfig.setLastUpdated(ZonedDateTime.now());
						emailConfig.setTenantId(tenantId);
						emailChannelsRepository.save(emailConfig);

					}
				}

			} else {
				accessToken = emailConfig.getAccess_token();
			}

			try {

				URL url = new URL("https://graph.microsoft.com/v1.0/users/"+emailConfig.getSharedEmail()+"/mailfolders/'Inbox'/messages?$filter=isRead%20ne%20true&$count=true");
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Authorization", "Bearer " + accessToken);
				conn.setRequestProperty("Prefer", "IdType='ImmutableId'");
				conn.setRequestProperty("Accept", "application/json");
				conn.setRequestProperty("Request", "application/json");
				int httpResponseCode = conn.getResponseCode();
				if (httpResponseCode == HTTPResponse.SC_OK) {
					StringBuilder response;
					try (BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
						String inputLine;
						response = new StringBuilder();
						while ((inputLine = in.readLine()) != null) {
							response.append(inputLine);
						}
					}
					String responseString = response.toString();
					System.out.println(responseString);
					ObjectMapper objectMapper = new ObjectMapper()
							.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
					objectMapper.findAndRegisterModules();

					DefaultSerializer serializer = new DefaultSerializer(new DefaultLogger());
					responseObject = serializer.deserializeObject(responseString, MessageCollectionResponse.class);
					map.put("responseObject", responseObject);
					map.put("accessToken", accessToken);
					map.put("httpConn", conn);
				}
			} catch (Exception e) {
				map.put("exception", e);
				System.out.println(e.getMessage());
				e.printStackTrace();
			}

		} catch (Exception ax) {
			map.put("exception", ax);
			logger.error("Exception while authenticating: {}", ax.getMessage());
			try {
				JSONObject jsonObject = OauthUtils.refreshIMAPToken(emailConfig.getRefresh_token(), graphAppClientId,
						graphAppSecreat, tenantId, emailConfig.getRedirectURI());
				if (jsonObject == null) {
					logger.info("Token is null...");
				} else {
					Object accessTokenObj = jsonObject.get("access_token");
					if (accessTokenObj != null) {
						String accesstoken = (String) accessTokenObj;
						String refreshtoken = (String) jsonObject.get("refresh_token");
						Integer expiresIn = (Integer) jsonObject.get("expires_in");
						long expireTime = System.currentTimeMillis() + (expiresIn * 900);
						accessToken = accesstoken;
						emailConfig.setAccess_token(accesstoken);
						emailConfig.setRefresh_token(refreshtoken);
						emailConfig.setExpires_in(expireTime);
						emailConfig.setLastUpdated(ZonedDateTime.now());

						emailChannelsRepository.save(emailConfig);

					}
				}
			} catch (Exception e) {
				logger.error("Exception: {}", e.getMessage());
				e.printStackTrace();
			}
		}

		return map;

	}

	public void updateMessageAsRead(String accessToken, String messageId, EmailChannel emailConfig) {
		String url = "https://graph.microsoft.com/v1.0/users/"+emailConfig.getSharedEmail()+"/mailFolders/'Inbox'/messages/" + messageId;
		CloseableHttpClient httpClient = null;
		try {
			httpClient = HttpClients.createDefault();
			HttpPatch httpGet = new HttpPatch(url);
			JSONObject obj = new JSONObject();
			obj.put("isRead", true);
			logger.info(obj.toString());
			httpGet.setEntity(new StringEntity(obj.toString(), org.apache.http.entity.ContentType.APPLICATION_JSON));
			httpGet.setHeader("Authorization", "Bearer " + accessToken);
			httpGet.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
			CloseableHttpResponse rawResponse = httpClient.execute(httpGet);
			int statusCode = rawResponse.getStatusLine().getStatusCode();
			System.out.println("updateMessageAsRead: statusCode:" + statusCode);

		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			try {
				httpClient.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public JsonResponse getAttachment(EmailChannel emailConfig, String from) throws IOException {
		Map<Object, Object> oauthAuthentication = oauthAuthentication(emailConfig);
		List<DocumentHelper> documentHelpers = new ArrayList<>();
		Object messageResponse = oauthAuthentication.get("responseObject");
		MessageCollectionResponse messageCollectionResponse = (MessageCollectionResponse) messageResponse;
		List<Message> values = messageCollectionResponse.values();
		if (!values.isEmpty()) {
			for (Message message : values) {
				if (message.from.emailAddress.address.equals(from) && message.hasAttachments) {
					DocumentHelper documentHelper = new DocumentHelper();
					for (Attachment attachment : message.attachments.getCurrentPage()) {
						documentHelper.setFilename(attachment.name);
						documentHelper.setFiletype(attachment.contentType);
						documentHelper.setUploadedBy(from);
						documentHelper.setUploadedDate(attachment.lastModifiedDateTime.toZonedDateTime());
						try {
							 FileAttachment f= (FileAttachment)attachment;
							 byte[] contentBytes = f.contentBytes;
							 ByteArrayOutputStream baos = new ByteArrayOutputStream(contentBytes.length);
							 baos.write(contentBytes, 0, contentBytes.length);
						} catch (Exception e) {
							
						}
						
//						BufferDocument bufferDocument=new BufferDocument(documentHelper);
					}
					documentHelpers.add(documentHelper);
				}
			}
		}
		return null;
	}
	
    private String getRegx(String vendorId) {
		
		return "[0-9a-zA-Z]*[0-9]+[0-9a-zA-Z]*";
		
	}

}
