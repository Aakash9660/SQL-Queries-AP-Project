package com.smartdocs.service;

import java.time.ZonedDateTime;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.repository.SystemLogsRepository;
import com.smartdocs.service.util.GeneralUtil;

@Service
public class SystemlogsService {

	@Autowired
	private SystemLogsRepository systemLogsRepository;

	public Page<SystemLogs> getAllSystemLogs(String orderBy, int page, int size, String category, String ipAddress,
			String email, String fromDate, String toDate,String jobId) {

		Pageable pageable = GeneralUtil.getSortPageRequest(orderBy, page, size);
		if (StringUtils.isBlank(category)) {
			category = null;
		} else {
			category = category.trim();
		}
		Page<SystemLogs> details = null;
		ZonedDateTime getFromDate = GeneralUtil.getFromDate(fromDate, "UTC");
		ZonedDateTime getToDate = GeneralUtil.getToDate(toDate, "UTC");
		try {
			details = systemLogsRepository.findBySystemTag(category, ipAddress, email,jobId, getFromDate, getToDate,
					pageable);
		} catch (Exception e) {
			pageable = PageRequest.of(page, size);
			details = systemLogsRepository.findBySystemTag(category, ipAddress, email,jobId, getFromDate, getToDate,
					pageable);
		}
		return details;
	}

}
