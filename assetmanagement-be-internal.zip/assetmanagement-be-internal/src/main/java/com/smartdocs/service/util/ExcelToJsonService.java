package com.smartdocs.service.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.smartdocs.dto.AssetAccountExcelRow;
import com.smartdocs.dto.VaultExcelRow;

@Service
public class ExcelToJsonService {

	public List<AssetAccountExcelRow> convertAssetAccountDataToJson(InputStream inputStream, int sheetIndex)
			throws IOException, JSONException {
		System.out.println("--------converting FileToJson-------");
		Workbook excelWorkBook = new XSSFWorkbook(inputStream);
		List<AssetAccountExcelRow> assetAccounts = null;
		int totalSheetNumber = excelWorkBook.getNumberOfSheets();
		System.out.println(">> " + totalSheetNumber);
		if (totalSheetNumber > 0) {
			Sheet sheet = excelWorkBook.getSheetAt(sheetIndex);
			if (sheet != null) {
				System.out.println("sheetName > " + sheet.getSheetName());
				List<List<String>> sheetDataTable = getAssetAccountRows(sheet);
				assetAccounts = toAssetAccountRow(sheetDataTable);
			}

		}
		excelWorkBook.close();
		return assetAccounts;
	}
	
	public List<VaultExcelRow>  convertVaultDataToJson(InputStream inputStream, int sheetIndex)
			throws IOException, JSONException {
		System.out.println("--------converting FileToJson-------");
		Workbook excelWorkBook = new XSSFWorkbook(inputStream);
		List<VaultExcelRow> vaultExcelRows = null;
		int totalSheetNumber = excelWorkBook.getNumberOfSheets();
		System.out.println(">> " + totalSheetNumber);
		if (totalSheetNumber > 0) {
			Sheet sheet = excelWorkBook.getSheetAt(sheetIndex);
			if (sheet != null) {
				System.out.println("sheetName > " + sheet.getSheetName());
				List<List<String>> sheetDataTable = getAssetAccountRows(sheet);
				vaultExcelRows = toVaultRow(sheetDataTable);
			}

		}
		excelWorkBook.close();
		return vaultExcelRows;
	}
	
	private List<VaultExcelRow> toVaultRow(List<List<String>> dataTable) throws JSONException {
		List<VaultExcelRow> lineItemList = new ArrayList<VaultExcelRow>();
		if (dataTable != null) {
			int rowCount = dataTable.size();
			System.out.println("rowCount ::: " + rowCount);
			if (rowCount > 1) {
				List<String> headerRow = dataTable.get(0);
				JSONObject tableJsonObject = new JSONObject();
				int columnCount = headerRow.size();
				for (int i = 1; i < rowCount; i++) {
					List<String> dataRow = dataTable.get(i);
					JSONObject rowJsonObject = new JSONObject();
					for (int j = 0; j < columnCount; j++) {
						String columnName = headerRow.get(j);
						String columnValue = dataRow.get(j);
						System.out.println("Column Name " + columnName + "// columnValue : " + columnValue);
						rowJsonObject.put(columnName, columnValue);
					}
					
					VaultExcelRow row = new VaultExcelRow();
					row.setDescription(rowJsonObject.getString("Description"));
					row.setName(rowJsonObject.getString("Secret Name"));
					row.setPassword(rowJsonObject.getString("Password"));
					row.setUserId(rowJsonObject.getString("User Email"));
					row.setToEmail(rowJsonObject.getString("Key"));
					lineItemList.add(row);
					tableJsonObject.put("InvoiceTemplate", rowJsonObject);
				}
			}
		}
		return lineItemList;
	}
	
	private List<AssetAccountExcelRow> toAssetAccountRow(List<List<String>> dataTable) throws JSONException {

		List<AssetAccountExcelRow> lineItemList = new ArrayList<AssetAccountExcelRow>();
		if (dataTable != null) {
			int rowCount = dataTable.size();
			System.out.println("rowCount ::: " + rowCount);
			if (rowCount > 1) {
				List<String> headerRow = dataTable.get(0);
				JSONObject tableJsonObject = new JSONObject();
				int columnCount = headerRow.size();
				for (int i = 1; i < rowCount; i++) {
					List<String> dataRow = dataTable.get(i);
					JSONObject rowJsonObject = new JSONObject();
					for (int j = 0; j < columnCount; j++) {
						String columnName = headerRow.get(j);
						String columnValue = dataRow.get(j);
						System.out.println("Column Name " + columnName + "// columnValue : " + columnValue);
						rowJsonObject.put(columnName, columnValue);
					}

					AssetAccountExcelRow row = new AssetAccountExcelRow();
					row.setAssetCode(rowJsonObject.getString("AssetCode"));
					row.setVendorId(rowJsonObject.getString("Vendor ID"));
					row.setAccountNo(rowJsonObject.getString("AccountNo"));
					row.setGlAccount(rowJsonObject.getString("GL Account"));
					row.setChannel(rowJsonObject.getString("Channel"));
					row.setCostCenter(rowJsonObject.getString("Cost Center"));
					row.setVault(rowJsonObject.getString("Vault"));
					row.setFrequency(String.valueOf(rowJsonObject.getString("Frequency")));
					if ("YES".equalsIgnoreCase(rowJsonObject.getString("SendtoExternal"))) {
						row.setSendToExternal(true);
					}
					try {
						String startdate = rowJsonObject.getString("StartDate");
						DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yyyy");
						ZonedDateTime startDateZonedTime = LocalDate.parse(startdate, format)
								.atStartOfDay(ZoneId.of("America/New_York"));
						row.setStarDateTime(startDateZonedTime);
					} catch (Exception e) {
						e.printStackTrace();
					}
					row.setSecondaryAccountNo((rowJsonObject.getString("SecondaryAccountNo")));
					lineItemList.add(row);
					tableJsonObject.put("InvoiceTemplate", rowJsonObject);
				}
			}
		}
		return lineItemList;
	}

	private List<List<String>> getAssetAccountRows(Sheet sheet) {
		System.out.println("getAssetAccountRows :");
		List<List<String>> ret = new ArrayList<List<String>>();
		int firstRowNum = sheet.getFirstRowNum();
		int lastRowNum = sheet.getLastRowNum();
		int firstColNo = sheet.getRow(0).getFirstCellNum();
		int lastColNo = sheet.getRow(0).getLastCellNum();
		// int amtIndex = 0;
		System.out.println("lastRowNum: " + lastRowNum);

		if (lastRowNum > 0) {
			for (int i = firstRowNum; i < lastRowNum + 1; i++) {
				Row row = sheet.getRow(i);
				if (checkIfEmptyRow(sheet, i)) {
					System.out.println("row is empty");
				} else {
					List<String> rowDataList = new ArrayList<String>();
					for (int j = firstColNo; j < lastColNo; j++) {
						Cell cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
						CellType type = cell.getCellType();
						System.out.println(type);
						switch (type) {
						case NUMERIC:
							if (HSSFDateUtil.isCellDateFormatted(cell)) {
								DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
								Date date = cell.getDateCellValue();
								rowDataList.add(df.format(date));
							} else {
								double numVal = cell.getNumericCellValue();
								String stringCellValue = String.format("%.0f", numVal);
								rowDataList.add(stringCellValue);
							}
							break;

						case STRING:
							String cellValue = cell.getStringCellValue();
							rowDataList.add(cellValue);
							break;
						case BOOLEAN:
							boolean val = cell.getBooleanCellValue();
							String getVal = String.valueOf(val);
							rowDataList.add(getVal);
						case BLANK:
							rowDataList.add("");
							break;
						default:
							throw new RuntimeException("No support for this of cell");
						}
					}
					ret.add(rowDataList);
				}
			}
		}
		System.out.println("" + ret);
		return ret;
	}

	private boolean checkIfEmptyRow(Sheet worksheet, int rowIndex) {
		Row row = worksheet.getRow(rowIndex);
		boolean isRowEmpty = true;
		if(row!=null) {
			System.out.println(row.getFirstCellNum());
			System.out.println(row.getLastCellNum());
			for (int columnIndex = row.getFirstCellNum(); columnIndex < row.getLastCellNum(); columnIndex++) {
				Cell cell = row.getCell(columnIndex, MissingCellPolicy.RETURN_NULL_AND_BLANK);
				if (cell != null) {
					CellType type = cell.getCellType();
					String stringCellValue = "";
					switch (type) {
					case NUMERIC:
						double numVal = cell.getNumericCellValue();
						stringCellValue = String.format("%.0f", numVal);
						break;
					case STRING:
						stringCellValue = cell.getStringCellValue();
						break;
					case BOOLEAN:
						boolean val = cell.getBooleanCellValue();
						stringCellValue = String.valueOf(val);
					case BLANK:
						break;
					default:
						throw new RuntimeException("No support for this of cell");
					}
					if (StringUtils.isNotBlank(stringCellValue) && StringUtils.isNotEmpty(stringCellValue)) {
						isRowEmpty = false;
						break;
					}
				}
			}
		}
		
		return isRowEmpty;
	}
	

}
