package com.smartdocs.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.smartdocs.model.BillDocument;
import com.smartdocs.model.Vault;
import com.smartdocs.model.group.RobotLogData;
import com.smartdocs.service.util.EncryptionDecryption;
import com.smartdocs.sql.dto.BillHistoryInf;
import com.smartdocs.sql.dto.ManageBills;
import com.smartdocs.sql.dto.MissingBillInf;

@Service
public class ExcelGeneratorService {

	private static final String TIME_FORMAT = "MM/dd/yyyy";
	private static final String INVOICE_NUMBER = "Invoice Number";
	private static final String INVOICE_DATE = "Invoice Date";
	private static final String ACCOUNT_NUMBER = "Account Number";
	private static final String ASSET_CODE = "Asset Code";
	private static final String ASSET_NAME = "Asset Name";
	private static final String VENDOR_ID = "Vendor ID";
	private static final String VENDOR_NAME = "Vendor Name";
	private static final String STATUS = "STATUS";
	private static final String AMOUNT = "AMOUNT";
	private static final String FREQUENCY = "Bill Frequency";
	private static final String BOT_NAME = "Bot Name";

	public ByteArrayInputStream invoiceToExcel(Page<BillDocument> billDocuments) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		String[] columns = { "PortalDocId", "InvoiceNumber", "Invoice Date", "Vendor ID", "UploadedBy", "Due Date",
				"Bill_DATE", "STATUS", "AMOUNT" };
		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("Invoice");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			Row headerRow = sheet.createRow(0);

			for (int i = 0; i < columns.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columns[i]);
				cell.setCellStyle(headerCellStyle);
			}
			int rowNum = 1;
			if (billDocuments != null && !billDocuments.getContent().isEmpty()) {
				for (BillDocument billDocument : billDocuments.getContent()) {
					Row row = sheet.createRow(rowNum++);
					row.createCell(0).setCellValue(billDocument.getPortalDocId());
					row.createCell(1).setCellValue(billDocument.getInvoiceNumber());
					if (billDocument.getInvoiceDate() != null) {
						row.createCell(2).setCellValue(
								DateTimeFormatter.ofPattern(TIME_FORMAT).format(billDocument.getInvoiceDate()));
					} else {
						row.createCell(2).setCellValue("");
					}
					row.createCell(3).setCellValue(billDocument.getVendorId());
					row.createCell(4).setCellValue(billDocument.getUploadedBy());
					if (billDocument.getDueDate() != null) {
						row.createCell(5).setCellValue(
								DateTimeFormatter.ofPattern(TIME_FORMAT).format(billDocument.getDueDate()));
					} else {
						row.createCell(5).setCellValue("");
					}

					row.createCell(6).setCellValue("");

					if (billDocument.getDueDate() != null) {
						row.createCell(7).setCellValue(
								DateTimeFormatter.ofPattern(TIME_FORMAT).format(billDocument.getDueDate()));
					} else {
						row.createCell(7).setCellValue("");
					}
					row.createCell(8).setCellValue(billDocument.getStatus());
					row.createCell(9).setCellValue(String.valueOf(billDocument.getAmount()));
				}
			}
			for (int i = 0; i < columns.length; i++) {
				sheet.autoSizeColumn(i);
			}
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ByteArrayInputStream(out.toByteArray());
	}

	public ByteArrayInputStream vaultToExcel(List<Vault> vaults) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		String[] columns = { "Secret Name", "Password", "User Email", "Key", "Description" };
		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("Invoice");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			Row headerRow = sheet.createRow(0);

			for (int i = 0; i < columns.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columns[i]);
				cell.setCellStyle(headerCellStyle);
			}
			int rowNum = 1;
			if (vaults != null && !vaults.isEmpty()) {
				for (Vault vault : vaults) {
					Row row = sheet.createRow(rowNum++);
					row.createCell(0).setCellValue(vault.getName());
					try {
						if (vault.getPassword() != null) {
							row.createCell(1).setCellValue(EncryptionDecryption.decrypt(vault.getPassword()));
						} else {
							row.createCell(1).setCellValue("");
						}
					} catch (Exception e) {
						row.createCell(1).setCellValue("");
					}
					row.createCell(2).setCellValue(vault.getUserId());
					row.createCell(3).setCellValue(vault.getToEmail());
					row.createCell(4).setCellValue(vault.getDescription());
				}
			}
			for (int i = 0; i < columns.length; i++) {
				sheet.autoSizeColumn(i);
			}
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ByteArrayInputStream(out.toByteArray());
	}

	public ByteArrayInputStream billToExcel(List<BillHistoryInf> infs) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		String[] columns = { INVOICE_NUMBER, ASSET_CODE, ASSET_NAME, VENDOR_ID, VENDOR_NAME, ACCOUNT_NUMBER,
				INVOICE_DATE, AMOUNT };
		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("Invoice");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			Row headerRow = sheet.createRow(0);

			for (int i = 0; i < columns.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columns[i]);
				cell.setCellStyle(headerCellStyle);
			}
			int rowNum = 1;
			if (infs != null && !infs.isEmpty()) {
				for (BillHistoryInf inf : infs) {
					Row row = sheet.createRow(rowNum++);
					row.createCell(0).setCellValue(inf.getInvoiceNumber());
					row.createCell(1).setCellValue(inf.getAssetcode());
					row.createCell(2).setCellValue(inf.getAssetname());
					row.createCell(3).setCellValue(inf.getVendorId());
					row.createCell(4).setCellValue(inf.getVendorName());
					row.createCell(5).setCellValue(inf.getAccountNumber());
					if (inf.getInvoiceDate() != null) {
						row.createCell(6).setCellValue(DateTimeFormatter.ofPattern(TIME_FORMAT)
								.format(ZonedDateTime.ofInstant(inf.getInvoiceDate().toInstant(), ZoneId.of("UTC"))));
					} else {
						row.createCell(6).setCellValue("");
					}
					row.createCell(7).setCellValue(inf.getAmount());
				}
			}
			for (int i = 0; i < columns.length; i++) {
				sheet.autoSizeColumn(i);
			}
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ByteArrayInputStream(out.toByteArray());
	}

	
	public ByteArrayInputStream failedBotToExcel(List<RobotLogData> bots) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		String[] columns = {  ASSET_CODE, ASSET_NAME, VENDOR_ID, VENDOR_NAME, ACCOUNT_NUMBER,
				BOT_NAME,"Executed On",STATUS};
		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("Invoice");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			Row headerRow = sheet.createRow(0);

			for (int i = 0; i < columns.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columns[i]);
				cell.setCellStyle(headerCellStyle);
			}
			int rowNum = 1;
			if (bots != null && !bots.isEmpty()) {
				for ( RobotLogData inf : bots) {
					Row row = sheet.createRow(rowNum++);
					row.createCell(0).setCellValue(inf.getRobotLog().getAssetCode());
					row.createCell(1).setCellValue(inf.getAssetName());
					row.createCell(2).setCellValue(inf.getRobotLog().getVendorId());
					row.createCell(3).setCellValue(inf.getVendorName());
					row.createCell(4).setCellValue(inf.getRobotLog().getAccountNo());
					row.createCell(5).setCellValue(inf.getRobotLog().getBotName());
					if (inf.getRobotLog().getLastUpdated() != null) {
						row.createCell(6).setCellValue(DateTimeFormatter.ofPattern(TIME_FORMAT)
								.format(ZonedDateTime.ofInstant(inf.getRobotLog().getLastUpdated() .toInstant(), ZoneId.of("UTC"))));
					} else {
						row.createCell(6).setCellValue("");
					}
					row.createCell(7).setCellValue(inf.getRobotLog().getStatus());
				}
			}
			for (int i = 0; i < columns.length; i++) {
				sheet.autoSizeColumn(i);
			}
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ByteArrayInputStream(out.toByteArray());
	}
	
	public ByteArrayInputStream missingBillsReportToExcel(List<MissingBillInf> missingBills) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		String[] columns = { "Asset Name", "Asset Code", "Vendor Code", "Vendor Name", "Account Number", "Channel",
				"Bill Frequency", "Period" };
		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("Invoice");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			Row headerRow = sheet.createRow(0);

			for (int i = 0; i < columns.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columns[i]);
				cell.setCellStyle(headerCellStyle);
			}
			int rowNum = 1;
			if (missingBills != null && !missingBills.isEmpty()) {
				for (MissingBillInf billsDto : missingBills) {
					Row row = sheet.createRow(rowNum++);
					row.createCell(0).setCellValue(billsDto.getAssetName());
					row.createCell(1).setCellValue(billsDto.getAssetCode());
					row.createCell(2).setCellValue(billsDto.getVendorId());
					row.createCell(3).setCellValue(billsDto.getVendorName());
					row.createCell(4).setCellValue(billsDto.getAccountNo());
					row.createCell(5).setCellValue(billsDto.getChannel());
					row.createCell(6).setCellValue(billsDto.getFrequency());
					row.createCell(7).setCellValue(billsDto.getPeriod());
				}
			}
			for (int i = 0; i < columns.length; i++) {
				sheet.autoSizeColumn(i);
			}
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ByteArrayInputStream(out.toByteArray());
	}

	public ByteArrayInputStream manageBillsToExcel(List<ManageBills> missingBills) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		String[] columns = { "Vendor Id", "Vendor Name", "Account Number", "Asset Code", "Asset Name",
				"Bill Frequency", "Lastest Bill","Invoice Date","Invoice Number","Amount" };
		try (Workbook workbook = new XSSFWorkbook()) {
			Sheet sheet = workbook.createSheet("Invoice");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			Row headerRow = sheet.createRow(0);

			for (int i = 0; i < columns.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columns[i]);
				cell.setCellStyle(headerCellStyle);
			}
			int rowNum = 1;
			if (missingBills != null && !missingBills.isEmpty()) {
				for (ManageBills billsDto : missingBills) {
					Row row = sheet.createRow(rowNum++);
					row.createCell(0).setCellValue(billsDto.getVendorId());
					row.createCell(1).setCellValue(billsDto.getVendorName());
					row.createCell(2).setCellValue(billsDto.getAccountNo());
					row.createCell(3).setCellValue(billsDto.getAssetCode());
					row.createCell(4).setCellValue(billsDto.getAssetName());
					row.createCell(5).setCellValue(billsDto.getFrequency());
					if (billsDto.getBillMonth() != null) {
						row.createCell(6).setCellValue(
								DateTimeFormatter.ofPattern(TIME_FORMAT).format(billsDto.getBillMonth()));
					} else {
						row.createCell(6).setCellValue("");
					}
					if (billsDto.getInvoiceDate() != null) {
						row.createCell(7).setCellValue(
								DateTimeFormatter.ofPattern(TIME_FORMAT).format(billsDto.getInvoiceDate()));
					} else {
						row.createCell(7).setCellValue("");
					}
					row.createCell(8).setCellValue(billsDto.getInvoiceNo());
					if(billsDto.getCurrency()!=null) {
					row.createCell(9).setCellValue(String.valueOf(billsDto.getAmount())+""+billsDto.getCurrency());
					}else {
						row.createCell(9).setCellValue(String.valueOf(billsDto.getAmount()));
					}
				}
			}
			for (int i = 0; i < columns.length; i++) {
				sheet.autoSizeColumn(i);
			}
			workbook.write(out);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ByteArrayInputStream(out.toByteArray());
	}
}
