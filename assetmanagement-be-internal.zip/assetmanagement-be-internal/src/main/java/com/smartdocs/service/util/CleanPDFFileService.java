package com.smartdocs.service.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfReader;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.smartdocs.service.AdminService;
import com.smartdocs.service.DocumentUploadService;

@Service
public class CleanPDFFileService {

	@Autowired
	private AdminService adminService;

	@Autowired
	private DocumentUploadService documentService;

	@Value("${destinationPath}")
	private String destinationPath;

	public String clean(String docId, String fileName) {
		PdfDocument pdfDoc = null;
		InputStream is = null;
		PdfReader prd = null;
		File file = null;
		String txId = null;
		String systemPath = destinationPath + fileName;
		System.out.println(systemPath);
		String buildURL = documentService.buildURL(adminService.getSmartStoreConfig().get(0), docId, "get", null);
		try {
			URL url = new URL(buildURL);
			is = url.openStream();
			prd = new PdfReader(is);
			pdfDoc = new PdfDocument(prd, new PdfWriter(systemPath));
			if (pdfDoc != null) {
				pdfDoc.close();
			}
			if (is != null) {
				is.close();
			}
			txId = UUID.randomUUID().toString();
			file = new File(systemPath);
			buildURL = documentService.buildURL(adminService.getSmartStoreConfig().get(0), txId, "create", fileName);
			documentService.uploadFile(buildURL, getBytes(systemPath), Files.probeContentType(file.toPath()));
			if (file != null) {
				file.delete();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return txId;
	}

	private ByteArrayOutputStream getBytes(String systemPath) {
		ByteArrayOutputStream out = null;
		InputStream in = null;
		try {
			in = new FileInputStream(systemPath);
			byte[] b = new byte[1024];
			int size = -1;
			out = new ByteArrayOutputStream();
			while ((size = in.read(b)) != -1) {
				out.write(b, 0, size);
			}
			in.close();
			out.close();
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return out;
	}

}