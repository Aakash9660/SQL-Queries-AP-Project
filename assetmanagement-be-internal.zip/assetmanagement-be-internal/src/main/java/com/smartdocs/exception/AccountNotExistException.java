package com.smartdocs.exception;

public class AccountNotExistException extends Exception {
	
	/**
	 * Constructs a <code>AccountNotExistException</code> with the specified message.
	 * @param msg the detail message
	 */
	public AccountNotExistException(String msg) {
		super(msg);
	}
	
	/**
	 * Constructs a <code>AccountNotExistException</code> with the specified message and
	 * root cause.
	 * @param msg the detail message
	 * @param cause root cause
	 */
	public AccountNotExistException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
