package com.smartdocs.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.UncategorizedDataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.service.ExceptionLogService;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	@Autowired
	private ExceptionLogService exceptionLogService;

	private final Logger log = LoggerFactory.getLogger(CustomExceptionHandler.class);

	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		addLog("SSPERCEH0022121", ex, request);
		return buildResponseEntity(new JsonResponse(HttpStatus.BAD_REQUEST, ex.getLocalizedMessage()));
	}

	private ResponseEntity<Object> buildResponseEntity(JsonResponse apiError) {
		return new ResponseEntity<>(apiError, apiError.getHttpStatus());
	}

	@ExceptionHandler(DataAccessResourceFailureException.class)
	public final ResponseEntity<JsonResponse> handleDataAccessResourceFailureException(
			DataAccessResourceFailureException ex, WebRequest request) {

		String txId = addLog("SSPERCEH001", ex, request);
		JsonResponse json = new JsonResponse();
		json.setMessage("Exception");
		json.setStatus(JsonResponse.RESULT_FAILED);
		json.setResult(txId);
		return new ResponseEntity<>(json, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(UncategorizedDataAccessException.class)
	public final ResponseEntity<JsonResponse> handleUserNotFoundException(UncategorizedDataAccessException ex,
			WebRequest request) {
		String txId = addLog("SSPERCEH002", ex, request);
		JsonResponse json = new JsonResponse();
		json.setMessage("Exception");
		json.setStatus(JsonResponse.RESULT_FAILED);
		json.setResult(txId);
		return new ResponseEntity<>(json, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(UncategorizedSQLException.class)
	public final ResponseEntity<JsonResponse> sqlException(UncategorizedSQLException ex, WebRequest request) {
		String txId = addLog("SSPERCEH005", ex, request);
		JsonResponse json = new JsonResponse();
		json.setMessage("Exception");
		json.setStatus(JsonResponse.RESULT_FAILED);
		json.setResult(txId);
		return new ResponseEntity<>(json, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(NullPointerException.class)
	public final ResponseEntity<JsonResponse> handleNullPointerException(NullPointerException ex, WebRequest request) {
		String txId = addLog("SSPERCEH003", ex, request);
		JsonResponse json = new JsonResponse();
		json.setResult(txId);
		json.setStatus(JsonResponse.RESULT_FAILED);
		json.setMessage("Exception");

		return new ResponseEntity<>(json, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(BadCredentialsException.class)
	public final ResponseEntity<JsonResponse> badCredentialsException(BadCredentialsException ex, WebRequest request) {

		JsonResponse json = new JsonResponse();
		json.setMessage(ex.getMessage());
		return new ResponseEntity<>(json, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(AccessDeniedException.class)
	public final ResponseEntity<JsonResponse> accessDeniedException(AccessDeniedException ex, WebRequest request) {

		JsonResponse json = new JsonResponse();
		json.setMessage(ex.getMessage());
		return new ResponseEntity<>(json, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(InternalAuthenticationServiceException.class)
	public final ResponseEntity<JsonResponse> internalAuthenticationServiceException(
			InternalAuthenticationServiceException ex, WebRequest request) {
		JsonResponse json = new JsonResponse();
		json.setMessage(ex.getMessage());
		return new ResponseEntity<>(json, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<JsonResponse> handleException1(Exception ex, WebRequest request) {
		String txId = addLog("SSPERCEH004", ex, request);
		JsonResponse json = new JsonResponse();
		json.setMessage("Exception");
		json.setResult(txId);
		json.setStatus(JsonResponse.RESULT_FAILED);
		return new ResponseEntity<>(json, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public final ResponseEntity<JsonResponse> handleIntegrityConstraint(DataIntegrityViolationException ex,
			WebRequest request) {
		String txId = addLog("SSPERCEH004", ex, request);
		JsonResponse json = new JsonResponse();
		json.setMessage(ex.getMessage());
		json.setResult(txId);
		json.setStatus(JsonResponse.RESULT_FAILED);
		return new ResponseEntity<>(json, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public final ResponseEntity<JsonResponse> handleConstraintViolationException(ConstraintViolationException ex,
			WebRequest request) {
		String txId = addLog("SSPERCEH004", ex, request);
		JsonResponse json = new JsonResponse();
		json.setMessage("Unique or Not Null Constraint violated ");
		json.setResult(txId);
		json.setStatus(JsonResponse.RESULT_FAILED);
		return new ResponseEntity<>(json, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public String addLog(String errorCode, Exception ex, WebRequest request) {
		ex.printStackTrace();
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		ex.printStackTrace(pw);

		String errorLog = sw.toString();

		String uri = ((ServletWebRequest) request).getRequest().getRequestURI().toString();
		log.error(uri + ":" + ex.getMessage());
		log.error(errorLog);
		return exceptionLogService.addLog(ex.getMessage(), uri, null, errorCode, errorLog);

	}
}
