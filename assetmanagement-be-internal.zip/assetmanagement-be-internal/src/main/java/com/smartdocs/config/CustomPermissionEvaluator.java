package com.smartdocs.config;


import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.smartdocs.mongo.collectionhelpers.Permission;
import com.smartdocs.mongo.collections.PermissionGroup;
import com.smartdocs.mongo.repository.AuthProfileRepository;
import com.smartdocs.security.service.UserPrincipal;

@Component
public class CustomPermissionEvaluator implements PermissionEvaluator {

	@Autowired
	private AuthProfileRepository authProfileRepository;
	
	
	@Override
	public boolean hasPermission(Authentication authentication, Object accessType, Object permission) {
		 
		if (authentication != null && accessType instanceof String) {
			UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
			 List<PermissionGroup> allPrmission=authProfileRepository.findByGroupIdIn(userPrincipal.getPermissionsGroups());
			return validateAccess(allPrmission,String.valueOf(accessType) , String.valueOf(permission));
		}
		return false;
	}

	private boolean validateAccess(List<PermissionGroup> permiossionGroups,String module, String access) {
		if(permiossionGroups!=null && access!=null ) {
			for(PermissionGroup permissionGroup : permiossionGroups) {
				if(permissionGroup!=null && permissionGroup.getPermissions()!=null) {
					for(Permission permission: permissionGroup.getPermissions()) 
					{
						if(permission!=null && permission.getName().equalsIgnoreCase(module) && 
								((( access.equalsIgnoreCase("VIEW") || access.equalsIgnoreCase("READ")) && permission.getView()) ||
								((access.equalsIgnoreCase("EDIT")|| access.equalsIgnoreCase("UPDATE")) && permission.getEdit())  ))
									{
										return true;
									}
					}
				}
				
			}
		}
		return false;
	}
	@Override
	public boolean hasPermission(Authentication authentication, Serializable serializable, String targetType,
			Object permission) {
		return false;
	}

}