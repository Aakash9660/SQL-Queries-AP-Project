package com.smartdocs.config;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
 


@Configuration 
public class MongoDBConfigurator {
  
//	@Bean
//	public CustomConversions customConversions() {
//		List<Converter<?, ?>> converters = new ArrayList<Converter<?, ?>>();
//		converters.add(new DateToZonedDateTimeConverter());
//		converters.add(new ZonedDateTimeToDateConverter());
//		return new CustomConversions(converters);
//	}
//
//	class DateToZonedDateTimeConverter implements Converter<Date, ZonedDateTime> {
//
//		@Override
//		public ZonedDateTime convert(Date source) {
//			return source == null ? null : ZonedDateTime.ofInstant(source.toInstant(), ZoneId.systemDefault());
//		}
//	}
//
//	class ZonedDateTimeToDateConverter implements Converter<ZonedDateTime, Date> {
//
//		@Override
//		public Date convert(ZonedDateTime source) {
//			return source == null ? null : Date.from(source.toInstant());
//		}
//	}

	@Bean
    public MongoCustomConversions customConversions(){
        List<Converter<?,?>> converters = new ArrayList<>();
        converters.add(DateToZonedDateTimeConverter.INSTANCE);
        converters.add( ZonedDateTimeToDateConverter.INSTANCE);
        return new MongoCustomConversions(converters);
    }

    enum DateToZonedDateTimeConverter implements Converter<Date, ZonedDateTime> {

        INSTANCE;

        @Override
        public ZonedDateTime convert(Date source) {
        	return source == null ? null : ofInstant(source.toInstant(), ZoneId.systemDefault());
        }
    }

    enum ZonedDateTimeToDateConverter implements Converter<ZonedDateTime, Date> {

        INSTANCE;

        @Override
        public Date convert(ZonedDateTime source) {
            return Date.from(source.toInstant());
        }
    }

	public static ZonedDateTime ofInstant(Instant instant, ZoneId systemDefault) {
		
		return instant.atZone(systemDefault);
	}
}
 
