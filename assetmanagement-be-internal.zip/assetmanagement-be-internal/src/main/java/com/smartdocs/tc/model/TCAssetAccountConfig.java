package com.smartdocs.tc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.smartdocs.model.AssetAccount;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table
@Data
@NoArgsConstructor
public class TCAssetAccountConfig {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String accountNo;
	private String assetCode;
	private String secondaryAccountNumber;
	private String assetName;
	private String vendorId;
	private String vendorName;
	private String utilityType;
	private String botName;
	private String userEmail;
	
	public TCAssetAccountConfig(AssetAccount assetAccount) {
		this.accountNo = assetAccount.getAccountNumber();
		this.assetCode = assetAccount.getAssetCode();
		this.vendorId = assetAccount.getVendorId();
		this.secondaryAccountNumber=assetAccount.getSecondaryAccountNumber();
	}
}
