package com.smartdocs.tc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.smartdocs.tc.model.TCAssetAccountConfig;

public interface TCAssetAccountRepository extends JpaRepository<TCAssetAccountConfig, Long> {
   
	List<TCAssetAccountConfig> findByUserEmail(String email);
	TCAssetAccountConfig findFirstByUserEmailAndAccountNoAndAssetCodeAndVendorId(String email,String accountNo,String assetCode,String vendorId);
    boolean existsByUserEmail(String email);
}
