package com.smartdocs.tc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.Robot;
import com.smartdocs.model.Vault;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.VendorScript;
import com.smartdocs.repository.AssetAccountRepository;
import com.smartdocs.repository.AssetRepository;
import com.smartdocs.repository.RobotRepository;
import com.smartdocs.repository.VaultRepository;
import com.smartdocs.repository.VendorRepository;
import com.smartdocs.repository.VendorScriptRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.util.EncryptionDecryption;
import com.smartdocs.tc.model.TCAssetAccountConfig;
import com.smartdocs.tc.repository.TCAssetAccountRepository;

@Service
public class TCConfigAssetAccountService {

	@Autowired
	private TCAssetAccountRepository accountConfigRepository;

	@Autowired
	private AssetAccountRepository assetAccountRepository;

	@Autowired
	private VendorScriptRepository vendorScriptRepository;

	@Autowired
	private VendorRepository vendorRepository;

	@Autowired
	private AssetRepository assetRepository;

	@Autowired
	private VaultRepository vaultRepository;

	@Autowired
	private RobotRepository robotRepository;

	public List<TCAssetAccountConfig> getMyScriptDetails(UserPrincipal logedInUser) {
		return accountConfigRepository.findByUserEmail(logedInUser.getEmail());
	}

	public String getScriptDetails(UserPrincipal logedInUser, String accountNo, String assetCode, String vendorId) {
		String vendorScript = "";
		if (logedInUser != null) {
			boolean config = accountConfigRepository.existsByUserEmail(logedInUser.getEmail());
			if (config) {
				AssetAccount assetAccount = assetAccountRepository
						.findOneByAssetCodeAndAccountNumberAndVendorId(assetCode, accountNo, vendorId);
				if (assetAccount != null) {
					Optional<Vault> existVault = vaultRepository.findById(assetAccount.getVaultId());
					if (existVault.isPresent()) {
						VendorScript script = vendorScriptRepository.findByVendorId(vendorId);
						if (script != null) {
							vendorScript = script.getCodeScript();
							vendorScript = vendorScript.replace("{{LOGIN_ID}}", existVault.get().getUserId());
							if (existVault.get().getPassword() != null) {
								vendorScript = vendorScript.replace("{{LOGIN_PWD}}",
										EncryptionDecryption.decrypt(existVault.get().getPassword()));
							} else {
								vendorScript = vendorScript.replace("{{LOGIN_PWD}}", existVault.get().getPassword());
							}
						}
					}
				}
			}
		}
		return vendorScript;
	}

	public void addDataInTCAssetAccountConfig() {
		List<AssetAccount> assetAccounts = assetAccountRepository.findAll();
		for (AssetAccount assetAccount : assetAccounts) {
			if (vendorScriptRepository.findByVendorId(assetAccount.getVendorId()) != null) {
				TCAssetAccountConfig config = new TCAssetAccountConfig(assetAccount);
				Optional<Asset> existAsset = assetRepository.findOneByAssetCode(assetAccount.getAssetCode());
				if (existAsset.isPresent()) {
					config.setAssetName(existAsset.get().getName());
				}
				Vendor vendor = vendorRepository.findFirstByVendorId(assetAccount.getVendorId());
				if (vendor != null) {
					config.setVendorName(vendor.getName());
					if (vendor.getClassifications() != null) {
						config.setUtilityType(vendor.getClassifications().get(0));
					}
				}
				Robot robot = robotRepository.findFirstByAssetCodeAndAccountNoAndVendorId(assetAccount.getAssetCode(),
						assetAccount.getAccountNumber(), assetAccount.getVendorId());
				if (robot != null)
					config.setBotName(robot.getId());
				accountConfigRepository.save(config);
			}
		}
	}

}
