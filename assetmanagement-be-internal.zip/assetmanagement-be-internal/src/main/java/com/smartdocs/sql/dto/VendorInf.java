package com.smartdocs.sql.dto;

import java.sql.Timestamp;
import java.util.List;

public interface VendorInf {

	 Long id();
	 String getVendorId();
	 String getVendorName();
	 Timestamp getLastUpdated();
	 String getAddress1();
	 String getAddress2();
	 String getCity();
	 String getState();
	 String getCountry();
	 String getZip();
	 String getLocation();
	 List<String> getClassifications();
	 Long getCount();
	 Boolean getManualIntervention();
	 String getAddedBy();
	 
}
