package com.smartdocs.sql.dto;

import java.sql.Timestamp;
import java.time.ZonedDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RobotCustom {
	private String  id;
	 private String  accountNo;
	 private String  vendorId;
	 private String  assetCode;
	 private Timestamp lastUpdated;
	 private String status;
	 private Timestamp lastExecuted;
	 private boolean Schedule;
	 private String jobId;
	 private String jenkinsCommand;
	 private String frequency;
	 private String vendorName;
     private  String assetName;
     private ZonedDateTime nextExecution;
     
   public RobotCustom(RobotInf inf) {
		super();
		this.id = inf.getId();
		this.accountNo = inf.getAccountNo();
		this.vendorId = inf.getVendorId();
		this.assetCode = inf.getAssetCode();
		this.lastUpdated = inf.getLastUpdated();
		this.status = inf.getStatus();
		this.lastExecuted = inf.getLastExecuted();
		Schedule = inf.getSchedule();
		this.jobId = inf.getJobId();
		this.jenkinsCommand = inf.getJenkinsCommand();
		this.frequency = inf.getFrequency();
		this.vendorName = inf.getVendorId();
		this.assetName = inf.getAssetCode();
	}
     
}
