package com.smartdocs.sql.dto;

import java.sql.Timestamp;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BillHistory {

	private String assetcode;
	private String assetname;
	private String vendorId;
	private String vendorName;
	private List<String> classifications;
	private String accountNumber;
	private String costCenter;
	private String costCenterDesc;
	private String glAccount;
	private String glAccountDesc;
	private String docId;
	private String status;
	private double amount;
	private String portalDocId;
	private String invoiceNumber;
	private String channel;
	private Timestamp billMonth;
	private Timestamp invoiceDate;
	private Timestamp invoiceCreatedDate;
	
	public BillHistory(BillHistoryInf billHistoryInf) {
		this.assetcode = billHistoryInf.getAssetcode();
		this.assetname = billHistoryInf.getAssetname();
		this.vendorId = billHistoryInf.getVendorId();
		this.vendorName = billHistoryInf.getVendorName();
		this.classifications = billHistoryInf.getClassifications();
		this.accountNumber = billHistoryInf.getAccountNumber();
		this.costCenter = billHistoryInf.getCostCenter();
		this.costCenterDesc = billHistoryInf.getCostCenter();
		this.glAccount = billHistoryInf.getGlAccount();
		this.glAccountDesc = billHistoryInf.getGlAccount();
		this.docId = billHistoryInf.getDocId();
		this.status = billHistoryInf.getStatus();
		this.amount = billHistoryInf.getAmount();
		this.portalDocId = billHistoryInf.getPortalDocId();
		this.invoiceNumber = billHistoryInf.getInvoiceNumber();
		this.channel = billHistoryInf.getChannel();
		this.billMonth = billHistoryInf.getBillMonth();
		this.invoiceDate = billHistoryInf.getInvoiceDate();
		this.invoiceCreatedDate = billHistoryInf.getInvoiceCreatedDate();
	}
}
