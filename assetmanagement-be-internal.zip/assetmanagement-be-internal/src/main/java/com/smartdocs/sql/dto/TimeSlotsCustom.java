package com.smartdocs.sql.dto;

import java.sql.Timestamp;
import java.time.ZonedDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TimeSlotsCustom {


	boolean allocated;
	String jobId;
	String assetCode;
	String assetName;
	String  vendorId;
	String vendorName;
	String accountNumber;
	String jenkinsCommand;
    private ZonedDateTime nextExecution;
    private Timestamp pastExecution;
    private String lastBuildStatus;
    private String leLogId;
    
	public TimeSlotsCustom(TimeSlotsInf inf) {
		this.allocated = inf.getAllocated();
		this.jobId = inf.getJobId();
		this.assetCode = inf.getAssetCode();
		this.assetName = inf.getAssetName();
		this.vendorId = inf.getVendorId();
		this.vendorName = inf.getVendorName();
		this.accountNumber = inf.getAccountNumber();
		this.jenkinsCommand = inf.getJenkinsCommand();
		this.lastBuildStatus=inf.getStatus();
		this.pastExecution=inf.getLastExecuted();
		this.leLogId=inf.getleLogId();
	}
}
