package com.smartdocs.sql.dto;

import java.sql.Timestamp;

public interface RobotInf {

	 String getId();
	 String getAccountNo();
	 String getVendorId();
	 String getAssetCode();
	 Timestamp getLastUpdated();
	 String getStatus();
	 Timestamp getLastExecuted();
	 boolean getSchedule();
	 String getJobId();
	 String getJenkinsCommand();
	 String getFrequency();
     String getVendorName();
     String getAssetName();
}
