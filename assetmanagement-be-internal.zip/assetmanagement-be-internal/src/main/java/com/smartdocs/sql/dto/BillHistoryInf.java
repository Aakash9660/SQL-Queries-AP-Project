package com.smartdocs.sql.dto;

import java.sql.Timestamp;
import java.util.List;

public interface BillHistoryInf {

	 String getAssetcode();
	 String getAssetname();
	 String getVendorId();
	 String getVendorName();
	 List<String> getClassifications();
	 String getAccountNumber();
	 String getChannel();
	 String getCostCenter();
	 String getCostCenterDesc();
	 String getGlAccount();
	 String getGlAccountDesc();
	 String getDocId();
	 String getStatus();
	 double getAmount();
	 String getPortalDocId();
	 String getInvoiceNumber();
	 Timestamp getBillMonth();
	 Timestamp getInvoiceDate();
	 Timestamp getInvoiceCreatedDate();
	 Boolean getPortalVisible();
	 String getTxId();
	 String getUploadedBy();
	 Timestamp  getUploadedDate();
	 Boolean getS1Sync();
	 Long getId();
	
}
