package com.smartdocs.sql.dto;

public interface ManageBillsInf {
	
	 String getVendorId();
	 String getVendorName();
	 String getAssetCode();
	 String getAssetName();
	 String getAccountNo(); 
	 String getFrequency();
	 String getNotes();

}
