package com.smartdocs.sql.dto;

import java.sql.Timestamp;

public interface AssetCustomInf {

	Long getAssetAccountId();
	String getAccountNumber();
	String getSecondaryAccountNumber();
	Long getVaultId();
	String getFrequency();
	String getChannel();
	Boolean getSendToExternal();
	Timestamp getStartDate();
	String getCostCode();
	String getCostDescription();
	String getGLCode();
	String getGLDescription();
	String getVendorId();
	String getVendorName();
	String getClassifications();
	String getAddress1();
	String getAddress2();
	String getCity();
	String getState();
	String getCountry();
	String getZip();
	String getLocation();
	
}
