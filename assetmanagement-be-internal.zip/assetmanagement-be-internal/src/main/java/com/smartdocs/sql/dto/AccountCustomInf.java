package com.smartdocs.sql.dto;

public interface AccountCustomInf {

	 String getVendorId();
	 String getVendorName();
	 String getAccountNumber();
}
