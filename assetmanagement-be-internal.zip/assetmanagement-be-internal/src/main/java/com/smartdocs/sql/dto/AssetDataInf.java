package com.smartdocs.sql.dto;

public interface AssetDataInf{
	 Long getId();
	 String getAssetCode();
	 String getName();
	 String getAssetType();
	 Double getLatitude();
	 Double getLongitude();
	 String getAddress1();
	 String getAddress2();
	 String getCity();
	 String getState();
	 String getCountry();
	 String getZip();
	 String getLocation();
	 long  getCount();

}
