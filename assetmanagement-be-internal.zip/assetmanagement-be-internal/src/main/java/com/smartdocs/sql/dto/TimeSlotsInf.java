package com.smartdocs.sql.dto;

import java.sql.Timestamp;

public interface TimeSlotsInf {

	boolean getAllocated();
	String getJobId();
	String getAssetCode();
	String getAssetName();
	String  getVendorId();
	String getVendorName();
	String getAccountNumber();
	String getJenkinsCommand();
	String getStatus();
	Timestamp getLastExecuted();
	String getleLogId();
}
