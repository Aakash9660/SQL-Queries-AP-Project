package com.smartdocs.sql.dto;

public interface OneYearBillInf {
	
	 String getClassifications();
	 String getMonth();
	 Double getTotalAmount();

}
