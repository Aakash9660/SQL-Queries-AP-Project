package com.smartdocs.sql.dto;

import java.sql.Timestamp;

public interface ManageBillsLogInf {

	 String getAssetCode();
	 String getAccountNo();
	 String getVendorId();
	 String getUserName();
	 String getComments();
	 String getDocId();
	 String getFileName();
	 String getFileType();
	 String getActicityCode();
	 String getActivityDesc();
	 Timestamp getUploadedDate();
	 Timestamp getBillMonth();
}
