package com.smartdocs.sql.dto;

import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AssetCustom {
	private Long assetAccountId;
	private String accountNumber;
	private Long vaultId;
	private String frequency;
	private String channel;
	private Boolean sendToExternal;
	private Timestamp startDate;
	private String costCenter;
	private String costCenterDesc;
	private String glAccount;
	private String glAccountDesc;
	private String vendorName;
	private String vendorId;
	private String classifications;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String country;
	private String zip;
	private String location;
	private String secondaryAccountNumber;


	public AssetCustom(AssetCustomInf assetCustomDtoInf) {
		super();
		this.assetAccountId = assetCustomDtoInf.getAssetAccountId();
		this.accountNumber = assetCustomDtoInf.getAccountNumber();
		this.vaultId = assetCustomDtoInf.getVaultId();
		this.frequency = assetCustomDtoInf.getFrequency();
		this.channel = assetCustomDtoInf.getChannel();
		this.sendToExternal = assetCustomDtoInf.getSendToExternal();
		this.startDate = assetCustomDtoInf.getStartDate();
		this.costCenter = assetCustomDtoInf.getCostCode();
		this.costCenterDesc = assetCustomDtoInf.getCostDescription();
		this.glAccount = assetCustomDtoInf.getGLCode();
		this.glAccountDesc = assetCustomDtoInf.getGLDescription();
		this.vendorName = assetCustomDtoInf.getVendorName();
		this.vendorId = assetCustomDtoInf.getVendorId();
		this.classifications = assetCustomDtoInf.getClassifications();
		this.address1 = assetCustomDtoInf.getAddress1();
		this.address2 = assetCustomDtoInf.getAddress2();
		this.city = assetCustomDtoInf.getCity();
		this.state = assetCustomDtoInf.getState();
		this.country = assetCustomDtoInf.getCountry();
		this.zip = assetCustomDtoInf.getZip();
		this.location = assetCustomDtoInf.getLocation();
		this.secondaryAccountNumber=assetCustomDtoInf.getSecondaryAccountNumber();
	}
}
