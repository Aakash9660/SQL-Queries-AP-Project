package com.smartdocs.sql.dto;

public interface MissingBillInf {
	
	 String getAssetName();
	 String getAssetCode();
	 String getAccountNo();
	 String getChannel();
	 String getFrequency();
	 String getVendorName();
	 String getVendorId();
	 String getPeriod();
	 String getId();
	 String getStatus();
}
