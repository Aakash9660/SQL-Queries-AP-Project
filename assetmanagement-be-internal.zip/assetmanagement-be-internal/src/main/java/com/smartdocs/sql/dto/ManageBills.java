package com.smartdocs.sql.dto;

import java.time.ZonedDateTime;

import com.smartdocs.model.BillDocument;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ManageBills {
	
	private String assetCode; 
	private String  vendorId; 
	private String  vendorName; 
	private String accountNo; 
	private String frequency; 
	private String assetName; 
	private String invoiceNo; 
	private ZonedDateTime invoiceDate;
	private ZonedDateTime billMonth;
	private Double amount;
	private String currency;
	private String portalDocId;
	private String notes;
	
	public ManageBills(ManageBillsInf inf) {
		this.assetCode = inf.getAssetCode();
		this.vendorId = inf.getVendorId();
		this.vendorName = inf.getVendorName();
		this.accountNo = inf.getAccountNo();
		this.frequency = inf.getFrequency();
		this.assetName = inf.getAssetName();
		this.notes=inf.getNotes();
	}
	
	public ManageBills(ManageBillsInf inf,BillDocument billDocument) {
		this.assetCode = inf.getAssetCode();
		this.vendorId = inf.getVendorId();
		this.vendorName = inf.getVendorName();
		this.accountNo = inf.getAccountNo();
		this.frequency = inf.getFrequency();
		this.assetName = inf.getAssetName();
		this.invoiceNo = billDocument.getInvoiceNumber();
		this.invoiceDate = billDocument.getInvoiceDate();
		this.billMonth = billDocument.getUploadedDate();
		this.amount = billDocument.getAmount();
		this.portalDocId=billDocument.getPortalDocId();
		this.notes=inf.getNotes();
		this.currency=billDocument.getCurrency();
	}

}
