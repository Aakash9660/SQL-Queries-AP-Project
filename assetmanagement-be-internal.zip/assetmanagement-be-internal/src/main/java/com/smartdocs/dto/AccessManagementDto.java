package com.smartdocs.dto;

import lombok.Data;

@Data
public class AccessManagementDto {

	private String appName;
}
