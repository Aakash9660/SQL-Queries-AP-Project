package com.smartdocs.dto;

import lombok.Data;

@Data
public class RobotReportDto {

	private double totalBots;
	private double passedBots;
	private double failedBots;
	private double upComingBots;
	private double minusBots;
	
	private String pattern;
	
}
