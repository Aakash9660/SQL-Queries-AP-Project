package com.smartdocs.dto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class UtilAssetDto {

	private Long totalAssets;
	List<Map<String, Integer>> mapList;
}
