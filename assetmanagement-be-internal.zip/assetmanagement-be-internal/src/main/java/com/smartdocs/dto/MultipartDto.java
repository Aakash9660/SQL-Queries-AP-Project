package com.smartdocs.dto;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class MultipartDto {

	private MultipartFile file;
}
