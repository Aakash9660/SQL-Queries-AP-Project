package com.smartdocs.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SystemUtilityDto {

	private long totalTimeSlots;
	private long totalBookedTimeSlots;
	private long totalScheduleBots;
}
