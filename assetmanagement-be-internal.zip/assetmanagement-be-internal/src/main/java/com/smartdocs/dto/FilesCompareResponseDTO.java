package com.smartdocs.dto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class FilesCompareResponseDTO {

	private String jobId;
	private boolean isContentSame;
	private String inProcessDocId;
	private List<String> processedDocIds;
	private Map<String,String> exceptions;
}
