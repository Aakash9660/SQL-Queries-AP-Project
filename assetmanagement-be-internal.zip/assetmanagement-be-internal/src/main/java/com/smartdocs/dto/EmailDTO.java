package com.smartdocs.dto;

import lombok.Data;

@Data
public class EmailDTO {
	
	private String reg;
	private String otp;
	private String bodyContent;
	

}
