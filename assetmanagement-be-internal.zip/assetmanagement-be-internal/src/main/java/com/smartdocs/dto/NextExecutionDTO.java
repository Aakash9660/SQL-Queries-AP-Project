package com.smartdocs.dto;

import java.time.ZonedDateTime;

import lombok.Data;

@Data
public class NextExecutionDTO {
	
	private String jobId;
	private String date;
	private ZonedDateTime dt;
	private String time;
	private String executeIn;

}

