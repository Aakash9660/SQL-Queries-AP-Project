package com.smartdocs.dto;

import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.CostCenter;
import com.smartdocs.model.GLAccount;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@NoArgsConstructor
@AllArgsConstructor
@Data
public class VendorAssets {
    
    AssetAccount assetAccount;
    Asset asset;
    CostCenter costCenter;
    GLAccount glAccount;
}