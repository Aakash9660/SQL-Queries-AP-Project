package com.smartdocs.dto;

import java.time.ZonedDateTime;

import lombok.Data;

@Data
public class InvoiceRequest {

	private DocumentHelper documentInfo ;
	private String vendorId;
	private String assetCode;
	private Double amount;
	private String status;
	private ZonedDateTime invoiceDate;
	private ZonedDateTime  dueDate;
	private String currency;
	private String accountNo;
	private String txId;
	private String invoiceNumber;
	private String channel;
	
	@Override
	public String toString() {
		return "InvoiceRequest [documentInfo=" + documentInfo + ", vendorId=" + vendorId + ", assetCode=" + assetCode
				+ ", amount=" + amount + ", status=" + status + ", invoiceDate=" + invoiceDate + ", dueDate=" + dueDate
				+ ", currency=" + currency + ", accountNo=" + accountNo + ", txId=" + txId + ", invoiceNumber="
				+ invoiceNumber + "]";
	}
	
	
}
