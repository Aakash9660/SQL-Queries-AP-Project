package com.smartdocs.dto;

import lombok.Data;

@Data
public class EmailRequestDTO {
	
	private String from;
	private String to;
	private String vendorId;

}
