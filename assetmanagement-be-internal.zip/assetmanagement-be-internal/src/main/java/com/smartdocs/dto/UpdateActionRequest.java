package com.smartdocs.dto;

import lombok.Data;

@Data
public class UpdateActionRequest {

	private String id;
	private int stage;
	private String comment;
	private String activityCode;
	private String status;
	private String assetCode;
	private String accountNo;
	private String vendorId;
	private AttachmentDTO attachment;
	private String notes;
}
