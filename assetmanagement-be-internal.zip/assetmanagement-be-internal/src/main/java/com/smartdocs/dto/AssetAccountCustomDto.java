package com.smartdocs.dto;

import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.helper.Address;

import lombok.Data;

@Data
public class AssetAccountCustomDto {

	private AssetAccount assetAccount;
	private String assetname;
	private Address address;
	private Long assetId;
}
