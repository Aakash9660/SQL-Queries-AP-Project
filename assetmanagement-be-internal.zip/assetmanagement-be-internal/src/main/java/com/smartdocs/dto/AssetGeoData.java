package com.smartdocs.dto;

import com.smartdocs.model.helper.Address;

import lombok.Data;

@Data
public class AssetGeoData {

	private long id;
	private String assetName;
	private String assetCode;
	private Address address;
	private double latitude;
	private double  longitude;
}
