package com.smartdocs.dto;

import org.springframework.http.HttpStatus;

import lombok.Data;

@Data
public class JsonResponse {

	private HttpStatus httpStatus;
	public static final String RESULT_FAILED = "failed";
	public static final String RESULT_SUCCESS = "success";

	public static final String STATUS_200 = "200";
	public static final String STATUS_201 = "201";
	public static final String STATUS_403 = "403";
	public static final String STATUS_404 = "404";
	public static final String STATUS_400 = "400";
	public static final String STATUS_500 = "500";
	public static final String STATUS_501 = "501";
	
	public static final String MFA_REQUIRE = "450";
	
	public static final String NOT_FOUND = "Not Found";

	private Object result = null;
	private String status = null;
	private String message = null;

	private long count = 0;

	private String statusCode = null;

	 

	public JsonResponse(){

	}
	
	public JsonResponse(HttpStatus status,  String ex) {
	       this();
	       this.httpStatus = status;
	       this.message = ex;
	}
	
	public JsonResponse(String status,String statusCode){
		this.result = null;
		this.status = status;
		this.message = "";
		this.statusCode = statusCode;
	}
	public JsonResponse(Object data,String status, String statusCode){
		this.result = data;
		this.status = status;
		this.message = "";
		this.statusCode = statusCode;
	}
	public JsonResponse(Object data,String status, String msg,String statusCode){
		this.result = data;
		this.status = status;
		this.message = msg;
		this.statusCode = statusCode;
	}
	public JsonResponse(String status, String msg,String statusCode){
		this.result = null;
		this.status = status;
		this.message = msg;
		this.statusCode = statusCode;
	}
	public JsonResponse(String otp,String status, String msg,String statusCode){
		this.result = otp;
		this.status = status;
		this.message = msg;
		this.statusCode = statusCode;
	}

	@Override
	public String toString() {

		if (result == null) {
			return "{\"status\":\"" + status + "\",\"result\":null}";
		}
		return "{\"status\":\"" + status + "\",\"result\":" + result.toString()
				+ "}";

	}

	 
	public void invalidUser() {
		this.setStatus(RESULT_FAILED);
		this.setResult("You are not authorised to access this api.");
		this.setMessage("You are not authorised to access this api.");
		this.setStatusCode(STATUS_403);
	}

	public void userAlreadyExist(String email) {
		this.setStatus(RESULT_FAILED);
		this.setResult("User with email "
				+ email
				+ " already exist. Please contact with system admin or forgot password.");
		this.setMessage("User with email "
				+ email
				+ " already exist. Please contact with system admin or forgot password.");
		this.setStatusCode(STATUS_200);
	}

	public void userSuccessCreated() {
		this.setStatus(RESULT_SUCCESS);
		this.setResult("User Successfully create.");
		this.setMessage("User Successfully create.");
		this.setStatusCode(STATUS_200);

	}

}

