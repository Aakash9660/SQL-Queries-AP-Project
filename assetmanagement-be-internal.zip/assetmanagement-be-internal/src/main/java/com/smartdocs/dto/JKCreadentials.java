package com.smartdocs.dto;

import java.util.Base64;

public class JKCreadentials {

	private String username;
	private String serverURL;
	private String password;
	
	public JKCreadentials(String serverURL,String username ,String password) {
		this.username=username;
		this.serverURL=serverURL;
		this.password=password;
	}

	public String getUsername() {
		return username;
	}

	public String getServerURL() {
		return serverURL;
	}

	public String getPassword() {
		return password;
	}
	
	public String getAuth() {
		try{
			String authStr = this.getUsername() + ":" + this.getPassword();
			return "Basic "+Base64.getEncoder().encodeToString(authStr.getBytes("utf-8"));
		}
		catch(Exception e) {
			return null;
		}
		

	}
	
}
