package com.smartdocs.dto;


import lombok.Data;

@Data
public class AppAccessDto {
	private String appId;
	private String appSecret;
}
