package com.smartdocs.dto;

import java.util.List;

import com.smartdocs.model.Manager;
import com.smartdocs.model.group.AssetRequireData;
import com.smartdocs.sql.dto.AssetCustom;

import lombok.Data;

@Data
public class AssetAccountDetails {

	private AssetRequireData asset;
	private List<Manager> managers;
	private List<AssetCustom> accounts;
	
}
