package com.smartdocs.dto;

import java.util.List;

import com.smartdocs.model.BillDocument;
import com.smartdocs.mongo.collections.DocumentHelper;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CustomDto {
	
	private String ocrProfile;
    private String poNumber;
    private String glAccount;
    private String costCenter;
    private String vendorId;
    private DocumentHelper file;
    private String channel;
	private String txId;
	private String assetCode;
	private Long assetId;
	private String  assetName;
	private String accountNo;
	private String utilityType;
	private List<DocumentHelper> supportingDoc;
	
	public CustomDto(BillDocument billDocument) {
		this.ocrProfile = "ap1000";
		this.glAccount = billDocument.getGlAccount();
		this.costCenter = billDocument.getCostCenter();
		this.vendorId = billDocument.getVendorId();
		this.channel = "AP";
		this.txId = billDocument.getTxId();
		this.assetCode = billDocument.getAssetCode();
		this.assetId = billDocument.getAssetId();
		this.assetName = billDocument.getAssetName();
		this.accountNo = billDocument.getAccountNumber();
		this.utilityType=billDocument.getUtilityType();
	}
}
