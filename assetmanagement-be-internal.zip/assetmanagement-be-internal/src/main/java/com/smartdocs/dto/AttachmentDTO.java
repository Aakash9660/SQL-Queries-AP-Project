package com.smartdocs.dto;

import lombok.Data;

@Data
public class AttachmentDTO {

	private String docid;
	private String filename;
	private String filetype;
	private String attid;
	private String arid;
}
