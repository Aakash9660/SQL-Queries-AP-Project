package com.smartdocs.dto;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class UtilVendorDto {

	private Long totalUtilityVendors;
	List<Map<String, Integer>> mapList;
}
