package com.smartdocs.dto;

import java.time.ZonedDateTime;

import com.smartdocs.model.Robot;
import com.smartdocs.model.helper.Address;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RobotCustomData {

	private String id;
	private Long assetId;
	private String assetCode;
	private String assetName;
	private Address address;
	private String vendorId;
	private String vendorName;
	private String accountNumber;
	private ZonedDateTime  lastUpdated;
	private ZonedDateTime lastExecuted;
	private ZonedDateTime nextExecution;
	private String status;
	private String frequency;
	private String jobId;
	private Integer sriptVersion;
	private int buildNo;
	private String buildStatus;
	private BillDocumentRequest billDocumentRequest;
	private String txId;
	private String executedStatus;
	private String jenkinsCommand;
	private String leLogId;
	private boolean schedule;
	
	public RobotCustomData(Robot robot,BillDocumentRequest billDocumentRequest) {
		this.id = robot.getId();
		this.assetCode = robot.getAssetCode();
		this.vendorId = robot.getVendorId();
		this.accountNumber = robot.getAccountNo();
		this.lastUpdated = robot.getLastUpdated();
		this.lastExecuted = robot.getLastExecuted();
		this.executedStatus = robot.getExecutedStatus();
		this.nextExecution = robot.getNextExecution();
		this.status = robot.getStatus();
		this.frequency = robot.getFrequency();
		this.jobId = robot.getJobId();
		this.sriptVersion = robot.getScriptVersion();
		this.billDocumentRequest=billDocumentRequest;
		this.leLogId=robot.getLeLogId();
	}
	
	
	public RobotCustomData(Robot robot) {
		this.id = robot.getId();
		this.assetCode = robot.getAssetCode();
		this.vendorId = robot.getVendorId();
		this.accountNumber = robot.getAccountNo();
		this.lastUpdated = robot.getLastUpdated();
		this.lastExecuted = robot.getLastExecuted();
		this.executedStatus = robot.getExecutedStatus();
		this.nextExecution = robot.getNextExecution();
		this.status = robot.getStatus();
		this.frequency = robot.getFrequency();
		this.jobId = robot.getJobId();
		this.sriptVersion = robot.getScriptVersion();
		this.leLogId=robot.getLeLogId();
	}
	
	
}
