package com.smartdocs.dto;

import com.smartdocs.security.service.UserPrincipal;

import lombok.Data;

@Data
public class JwtResponse {
	
	public static final String LOGIN_SSO="sso";
	public static final String LOGIN_APP="appAccess";
	public static final String LOGIN_BASIC_UP="basic";
	
    private String token;
    private String type = "Bearer";
    private String loginType;
    private UserPrincipal user;
 

    public JwtResponse( ) {
    }
    
    public JwtResponse(String accessToken,UserPrincipal user,String loginType) {
        this.token = accessToken;
        this.user=user;
        this.loginType=loginType;
    }

    
}