package com.smartdocs.dto;

import java.time.ZonedDateTime;

import com.smartdocs.model.BillDocument;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BillDocumentRequest {

	private String missingBillId;
	private String docId;
	private String filename;
	private String status;
	private ZonedDateTime uploadedDate;
	private double amount;
	
	public BillDocumentRequest(BillDocument billDocument) {
		this.docId = billDocument.getDocid();
		this.filename = billDocument.getFilename();
		this.status = billDocument.getStatus();
		this.uploadedDate = billDocument.getUploadedDate();
		this.amount = billDocument.getAmount();
	}
}
