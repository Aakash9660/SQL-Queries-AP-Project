package com.smartdocs.dto;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class UtilitySubmitRequest {

	private String vendorId;
	private String jobId;
	
	private String assetId;
	private String accountno;
	private String billAmount;
	private String dueDate;
	
	private MultipartFile file;
	
}
