package com.smartdocs.dto;

import java.util.List;

import com.smartdocs.model.CostCenter;
import com.smartdocs.model.GLAccount;
import com.smartdocs.model.group.AssetData;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AssetVendorDto {

	private String vendorId;
	private String vendorName;
	private String accountNumber;
	private GLAccount glAccount;
	private CostCenter costCenter;
	private String frequency;
	private String channel;
	private List<String> classifications;

	public AssetVendorDto(AssetData assetData) {
		this.glAccount = assetData.getGlAccount();
		this.costCenter = assetData.getCostCenter();
		if (assetData.getAssetAccount() != null) {
			this.frequency = assetData.getAssetAccount().getFrequency();
			this.accountNumber = assetData.getAssetAccount().getAccountNumber();
			this.channel = assetData.getAssetAccount().getChannel();
		}
		if (assetData.getVendor() != null) {
			this.vendorId = assetData.getVendor().getVendorId();
			this.vendorName = assetData.getVendor().getName();
			this.classifications = assetData.getVendor().getClassifications();
		}
	}

}
