package com.smartdocs.dto;

import java.time.ZonedDateTime;

import lombok.Data;

@Data
public class AssetAccountExcelRow {
	
	public static final String STATUS_SUCCESS="SUCCESS";
	public static final String STATUS_WARNING="WARNING";
	public static final String STATUS_ERROR="ERROR";

	private String assetCode;
	private String vendorId;
	private String accountNo;
	private String secondaryAccountNo;
	private String glAccount;
	private String costCenter;
	private String channel;
	private String vault;
	private String frequency;
	private boolean sendToExternal;
	private String status;
	private String message;
	private ZonedDateTime starDateTime;
	@Override
	public String toString() {
		return "AssetAccountExcelRow [assetCode=" + assetCode + ", vendorId=" + vendorId + ", accountNo=" + accountNo
				+ ", glAccount=" + glAccount + ", costCenter=" + costCenter + ", channel=" + channel + ", vault="
				+ vault + ", frequency=" + frequency + ", sendToExternal=" + sendToExternal + ", status=" + status
				+ ", message=" + message + ", starDateTime=" + starDateTime + "]";
	}

}
