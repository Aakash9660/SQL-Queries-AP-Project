package com.smartdocs.dto;

import lombok.Data;

@Data
public class VaultExcelRow {
	
	private String name;
	private String description;
	private String userId;
	private String password;
	private int version;
	private String toEmail;
}
