package com.smartdocs.dto;

import java.util.List;

import lombok.Data;

@Data
public class RobotFailedBotActionRequest {
	
	
	private String id;
	private String comment;
	private String activity;
	private List<String> ids;
	private AttachmentDTO attachment;
}
