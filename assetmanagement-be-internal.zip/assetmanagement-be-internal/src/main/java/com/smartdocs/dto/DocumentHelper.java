package com.smartdocs.dto;

import java.time.ZonedDateTime;

import com.smartdocs.model.BillDocument;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class DocumentHelper {

	private String documentid;
	private Integer sharadId;
	private String filename;
	private String filetype;
	private String attid;
	private String arid;
	private String uploadedBy;
	private ZonedDateTime uploadedDate;
	
	public DocumentHelper(BillDocument billDocument) {
		super();
		this.documentid = billDocument.getDocid();
		this.sharadId = null;
		this.filename = billDocument.getFilename();
		this.filetype = billDocument.getFiletype();
		this.attid = billDocument.getAttid();
		this.arid = billDocument.getArid();
		this.uploadedBy =billDocument.getUploadedBy();
		this.uploadedDate = billDocument.getUploadedDate();
	}
	
	
}
