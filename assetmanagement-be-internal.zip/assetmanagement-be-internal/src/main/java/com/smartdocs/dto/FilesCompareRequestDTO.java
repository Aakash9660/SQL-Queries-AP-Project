package com.smartdocs.dto;

import java.util.List;

import lombok.Data;

@Data
public class FilesCompareRequestDTO {

	private String jobId;
	private String inProcessDocId;
	private List<String> processedDocIds;
}
