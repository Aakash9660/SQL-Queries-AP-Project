package com.smartdocs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.model.EmployeeMaster;
import com.smartdocs.service.EmployeeMasterService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Api(tags = "EmployeeController", value = "EmployeeController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/employeeMaster")
public class EmployeeMasterController {

	@Autowired
	private EmployeeMasterService employeeMasterService;

	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Employee", value = "Get Employee")
	@GetMapping("/{name}")
	public List<EmployeeMaster> getEmployeeMaster(@PathVariable ("name") String name) {
		return this.employeeMasterService.getEmployee(name);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get ALL Employees", value = "Craete EmployeeMaster")
	@GetMapping("/page")
	public Page<EmployeeMaster> getEmployeeMasterPages(@RequestParam(name = "email", required = false) String email,
			@RequestParam(name = "firstName", required = false) String firstName,
			@RequestParam(name = "lastName", required = false) String lastName, @RequestParam("order") String orderBy,
			@RequestParam("page") int page, @RequestParam("limit") int size) {
		Page<EmployeeMaster> employeeMaster = employeeMasterService.getEmployeeMasterPages(email, firstName, lastName,
				page - 1, size, orderBy);
		return employeeMaster;
	}
}
