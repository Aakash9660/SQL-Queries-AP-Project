package com.smartdocs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.tc.model.TCAssetAccountConfig;
import com.smartdocs.tc.service.TCConfigAssetAccountService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "TCAssetAccountConfigController", value = "TCAssetAccountConfigController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/tc-assetAccountConfig")
public class TCAssetAccountConfigController {
	
	@Autowired
	private TCConfigAssetAccountService configAssetAccountService;
	
//	@PostMapping("/test-addData")
//	public void saveDataForTCAssetAccountConfig() {
//		configAssetAccountService.addDataInTCAssetAccountConfig();
//	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update Vendor to set ManualIntervention", value = "Update Vendor to set ManualIntervention")
	@GetMapping("/getMyScriptDetails")
	public List<TCAssetAccountConfig> getMyConfigDetails(
			@ApiIgnore Authentication authentication) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return configAssetAccountService.getMyScriptDetails(logedInUser);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update Vendor to set ManualIntervention", value = "Update Vendor to set ManualIntervention")
	@PostMapping("/getScript")
	public String getScript(
			@RequestParam String accountNo,@RequestParam String assetCode,
			@ApiIgnore Authentication authentication,@RequestParam String vendorId) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return configAssetAccountService.getScriptDetails(logedInUser,accountNo,assetCode, vendorId);
	}

}
