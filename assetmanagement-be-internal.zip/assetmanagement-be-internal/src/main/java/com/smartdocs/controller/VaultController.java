package com.smartdocs.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.MultipartDto;
import com.smartdocs.model.Vault;
import com.smartdocs.model.dto.VaultDto;
import com.smartdocs.service.VaultService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import net.sf.json.JSONException;

@Api(tags = "VaultController", value = "VaultController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/vault")
public class VaultController {

	@Autowired
	private VaultService vaultService;

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for create new Vault", value = "Create new Vault")
	@PostMapping
	public JsonResponse createVault(@RequestBody VaultDto vaultDto) throws NoSuchAlgorithmException {
		return this.vaultService.createVault(vaultDto);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update Vault", value = "Update Vault")
	@PutMapping("/{id}")
	public JsonResponse updateVault(@RequestBody VaultDto vaultDto, @PathVariable Long id)
			throws NoSuchAlgorithmException {
		return this.vaultService.updateVault(vaultDto, id);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Vault", value = "Get Vault")
	@GetMapping("/{id}")
	public Vault getVault(@PathVariable Long id) {
		return this.vaultService.getVault(id);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Vault with Decrypt password", value = "Get Vault with decrypt password")
	@GetMapping("/vaultWithDecryptPassword/{secretName}")
	public Vault getVaultWithDecryptPassword(@PathVariable String secretName) {
		return this.vaultService.getVaultWithDecryptPassword(secretName);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Vault Password", value = "Get Vault Password")
	@GetMapping("/decrypt-password/{id}")
	public Map<String, Object> getVaultPassword(@PathVariable long id) {
		return this.vaultService.getDecryptPassword(id);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Vault Pages", value = "Get Vault Page")
	@GetMapping("/page")
	public Page<Vault> getVaultPages(@RequestParam(name = "name", required = false) String name,
			@RequestParam(value = "order") String orderBy, @RequestParam(value = "limit") Integer size,
			@RequestParam(value = "page") Integer page) {
		return this.vaultService.getVaultPages(name, page - 1, size, orderBy);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for delete Vault", value = "Delete Vault")
	@DeleteMapping("/{id}")
	public void deleteVault(@PathVariable Long id) {
		this.vaultService.deleteVault(id);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for download Vault Pages", value = "Download Vault Page")
	@GetMapping("/downloadVaultPages")
	public ResponseEntity<InputStreamResource> downloadVaultPages(
			@RequestParam(name = "name", required = false) String name) throws IOException {
		ByteArrayInputStream byteInputStream = vaultService.getVaultPagesDownload(name);
		if (byteInputStream != null) {
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Vault.xlsx")
					.contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
					.body(new InputStreamResource(byteInputStream));
		}
		return null;
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for bulk upload vault through Excel.", value = " Bulk Upload Vault")
	@PostMapping(value = "/upload-vault", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
	public JsonResponse uploadAssetAccount(@ModelAttribute MultipartDto data) throws IOException, JSONException {
		try {
			InputStream inputStream = data.getFile().getInputStream();
			return vaultService.processVaultUpload(inputStream);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Uploaded File Invalid", JsonResponse.STATUS_500);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Vault List", value = "Get Vault List")
	@GetMapping("/byVendorId/{vendorId}")
	public List<Vault> getVaultsByVendorId(@PathVariable String vendorId) {
		return vaultService.getVaultByVendorId(vendorId);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vault','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Vault", value = "Get Vault")
	@GetMapping("/byAccountNo/{accountNo}")
	public VaultDto getVaultByAccountNo(@PathVariable String accountNo) {
		return vaultService.getVaultByAccountNo(accountNo);
	}
}
