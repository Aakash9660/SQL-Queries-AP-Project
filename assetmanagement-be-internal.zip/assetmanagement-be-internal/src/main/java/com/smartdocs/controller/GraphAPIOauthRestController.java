package com.smartdocs.controller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.ZonedDateTime;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.model.EmailChannel;
import com.smartdocs.repository.EmailChannelRepository;
import com.smartdocs.service.OauthUtils;
import com.smartdocs.service.util.OAuthConstants;

import io.swagger.annotations.Api;

@Api(tags = "GraphAPIOauthRestController")
@RestController
@RequestMapping("/microsoftGraph")
public class GraphAPIOauthRestController {

	private static final Logger logger = LoggerFactory.getLogger(GraphAPIOauthRestController.class);

	@Value("${graph.appId}")
	private String imapAppClientId;
	
	@Value("${graph.appSecreat}")
	private String imapAppSecreat;
	
	@Value("${graph.oauth.redirectURI}")
	private String redirectURI;
	
	@Value("${graph.tenantId}")
	private String tenantId;

	public static final String API_HOST = "graph.microsoft.com/v1.0/me";
	public static final String DEFAULT_SCHEME = "https";

	@Autowired
	private EmailChannelRepository emailChannelsRepository;

	@GetMapping("/signin")
	public void newToOffice365AuthSignin(HttpServletResponse httpServletResponse) {
		logger.info("IMAPOauthRestController -> /imapOauth/signin : newToOffice365AuthSignin");
		String authorizeURL = OAuthConstants.SMTP_OAUTH_AUTHORIZATION_URL.replace("{tenantId}", tenantId);
		String url = new StringBuilder(authorizeURL).append("?client_id=")
				.append(imapAppClientId)
				.append("&").append(OAuthConstants.PROMPT).append("=login")
				.append("&").append(OAuthConstants.REDIRECT_URI).append("=").append(redirectURI)
				.append("&").append(OAuthConstants.SCOPE).append("=").append("offline_access https://graph.microsoft.com/Mail.Read https://graph.microsoft.com/User.Read https://graph.microsoft.com/Mail.ReadWrite https://graph.microsoft.com/Mail.Read.Shared https://graph.microsoft.com/Mail.ReadWrite.Shared")
				//.append("&").append(OAuthConstants.SCOPE).append("=").append("offline_access https://graph.microsoft.com/Mail.Read https://graph.microsoft.com/User.Read")
				//.append("&").append(OAuthConstants.STATE).append("=").append(id)
				.append("&").append(OAuthConstants.RESPONSE_TYPE).append("=code")
				.toString();
		try {
			httpServletResponse.sendRedirect(url);
		} catch (IOException e) {
			logger.error("IOException: {}", e.getMessage());
			e.printStackTrace();
		}

	}

	@GetMapping("/redirect")
	public ResponseEntity<?> redirect(HttpServletRequest request, HttpServletResponse httpServletResponse)
			throws IOException, JSONException {
		logger.info("GraphAPIOauthRestController : /graphAPIOauth/redirect -> redirect");
		String code = request.getParameter("code");
		//String state = request.getParameter("state");

		//Optional<EmailChannels> emailChannel = emailChannelsRepository.findById(state);
		JSONObject jsonObject = OauthUtils.getGraphAccessToken(code, redirectURI, imapAppClientId, imapAppSecreat,tenantId);
		//if (emailChannel.isPresent()) {

			if (jsonObject == null) {
				logger.warn("Access Token is null");
				return new ResponseEntity<>("error while getting access token", HttpStatus.OK);
			} else {
				Object accessTokenObj = jsonObject.get("access_token");
				if (accessTokenObj != null) {
					String accessToken = (String) accessTokenObj;
					JSONObject user=OauthUtils.getUser(accessToken);
					String userEmail=user.getString("mail");
					if(userEmail!=null)
					{
						System.out.println("Email"+userEmail);
						userEmail=userEmail.toLowerCase();
						EmailChannel emailAccount= emailChannelsRepository.findOneByEmail(userEmail);
						if(emailAccount==null) {
							emailAccount=new EmailChannel();
							emailAccount.setId(userEmail);
							emailAccount.setEmail(userEmail);
						}
						String refreshToken = (String) jsonObject.get("refresh_token");
						Integer expiresIn = (Integer) jsonObject.get("expires_in");
						long expireTime = System.currentTimeMillis() + (expiresIn * 400);
						emailAccount.setAccess_token(accessToken);
						emailAccount.setRefresh_token(refreshToken);
						emailAccount.setExpires_in(expireTime);
						emailAccount.setEnabled(true);
						emailAccount.setRedirectURI(redirectURI);
						emailAccount.setAuthType(EmailChannel.AUTH_TYPE_OAUTH);
						//emailAccount.setAuthType(EmailChannel.AUTH_TYPE_OAUTH_GRAPH);
						emailAccount.setLastUpdated(ZonedDateTime.now());
						emailChannelsRepository.save(emailAccount);
						return new ResponseEntity<>("success", HttpStatus.OK);
					}
					else {
						return new ResponseEntity<>("email is null", HttpStatus.OK);
					}
				} else {
					logger.warn("Access Token not found");
					return new ResponseEntity<>("Access Token not found!", HttpStatus.NOT_FOUND);
				}

			}
	}

	public String getOutlookName(String accessToken) throws IOException {
		logger.info("GraphAPIOauthRestController -> getOutlookName");
		String responseString = null;
		String mail = null;
		URI uri;

		try {
			uri = new URIBuilder().setScheme(DEFAULT_SCHEME).setHost(API_HOST).build();
		} catch (URISyntaxException e) {
			throw new IllegalStateException("Invalid drives path", e);
		}
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

			HttpGet httpGet = new HttpGet(uri);
			httpGet.setHeader("Authorization", "Bearer " + accessToken);
			HttpResponse rawResponse = httpClient.execute(httpGet);

			int statusCode = rawResponse.getStatusLine().getStatusCode();
			logger.info("statusCode: {} ", statusCode);
			if (statusCode == 200) {
				HttpEntity responseEntity = rawResponse.getEntity();
				responseString = EntityUtils.toString(responseEntity);
				logger.info("Response: {} ", responseString);
				JSONObject objs = new JSONObject(responseString);
				mail = objs.get("userPrincipalName").toString();
			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		return mail;

	}
}
