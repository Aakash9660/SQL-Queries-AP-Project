package com.smartdocs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.EmailRequestDTO;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.service.ReadEmailService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Api(tags = "ReadEmailController" , value = "ReadEmailController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@Validated
@RequestMapping("/readEmail")
public class ReadEmailController {

	@Autowired
	private ReadEmailService readEmailService;

	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This API for get OTP", value = "Get OTP")
	@GetMapping(value = "/otp")
	public JsonResponse runReadEmail(@RequestParam String from,@RequestParam String to) {
		return readEmailService.readEmail(to,from);
	}
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@PostMapping(value = "/get-otp")
	public JsonResponse testReadEmail(@RequestBody EmailRequestDTO emailRequest) {
		return readEmailService.readEmail(emailRequest);
	}
 

}
