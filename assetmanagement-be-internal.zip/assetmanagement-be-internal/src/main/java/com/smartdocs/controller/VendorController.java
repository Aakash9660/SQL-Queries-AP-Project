package com.smartdocs.controller;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.AssetAccountCustomDto;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.UtilVendorDto;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.VendorClassifications;
import com.smartdocs.model.dto.VendorAssetsDto;
import com.smartdocs.model.dto.VendorDto;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.VendorService;
import com.smartdocs.sql.dto.VendorInf;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "VendorController", value = "VendorController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/vendor")
public class VendorController {

	@Autowired
	private VendorService vendorService;

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vendor','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update Vendor", value = "Update Vendor By ID")
	@PutMapping("/{vendorId}")
	public JsonResponse updateVendor(@RequestBody VendorDto vendorDto, @PathVariable String vendorId) {
		return this.vendorService.updateVendor(vendorDto, vendorId);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update Vendor", value = "Get Vendor By ID")
	@GetMapping("/vendorId-{vendorId}")
	public Vendor getAssetsByCode(@PathVariable String vendorId) {
		return vendorService.getVendorByVendorId(vendorId);
	}

	@Deprecated
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Vendor by ID", value = "Get Vendor By ID")
	@GetMapping("/{id}")
	public Vendor getVendor(@PathVariable Long id) {
		return vendorService.getVendorById(id);
	}

	@Deprecated
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Vendor Name", value = "Get Vendor Name")
	@GetMapping("/getVendorName/{vendorId}")
	public JsonResponse getVendorName(@PathVariable String vendorId) {
		return vendorService.getVendorName(vendorId);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api to get Utility Vendors in page", value = "This Api to get Utility Vendors in page")
	@GetMapping("/page")
	public Page<VendorInf> getVendorPage(
			@RequestParam(name = "query", required = false) String query,
			@RequestParam(name = "manualIntervention", required = false) Boolean manualIntervention,
			@RequestParam(name = "utilityType", required = false) String utilityType,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return vendorService.getVendorsPage(manualIntervention,query, utilityType, orderBy, page - 1, size);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get AssetAccount List", value = "Get AssetAccount List")
	@GetMapping("/getAssetAccounts/{vendorId}")
	public List<AssetAccountCustomDto> getVendorsAccounts(@PathVariable String vendorId) {
		return vendorService.getAccounts(vendorId);
	}

	@Deprecated
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api to get Utility Vendor and Asset account", value = "This Api to get Utility Vendor and Asset Account")
	@GetMapping("/utility/assets")
	public Page<VendorAssetsDto> getAllVendorAssets(@RequestParam(name = "vendorId") String vendorId,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return vendorService.findAllVendorAssets(vendorId, orderBy, accountNumber, page - 1, size);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Distinct Vendors Classifications", value = "Get Distinct Vendors Classifications")
	@GetMapping("/getDitsinctClassifications")
	public Set<String> getTotalDistinctClassifications() {
		return vendorService.getDistinctVedorClassifications();
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Distinct Vendors Classifications", value = "Get Distinct Vendors Classifications")
	@GetMapping("/getVendorIdAndName/{query}")
	public List<Map<String, Integer>> getVendorNameAndVendorId(@PathVariable String query) {
		return vendorService.findVendorNameByVendorIdOrName(query);
	}

	// ================================classifications =================

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api to get Classifications", value = "This Api to get Classifications")
	@GetMapping("/classifications/count")
	public UtilVendorDto getCountClassifications() {
		return vendorService.getCountOfUtilies();
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get vendorClassifications page", value = "Get vendorClassifications page")
	@GetMapping("/vendorClassifications/page")
	public Page<VendorClassifications> getvendorClassificationsPage(
			@RequestParam(name = "order", required = false) String orderBy,
			@RequestParam(name = "query", required = false) String query, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return vendorService.getVendorClassificationsPage(query, orderBy, page - 1, size);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get vendorClassifications List", value = "Get vendorClassifications List")
	@GetMapping("/vendorClassifications/list")
	public Set<String> getvendorClassificationsList() {
		return vendorService.getListOfVendorClassifications();
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get vendorClassifications", value = "Get  vendorClassifications")
	@GetMapping("/vendorClassifications/{name}")
	public JsonResponse getvendorClassifications(@PathVariable String name) {
		return vendorService.getVendorClassifications(name);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update vendorClassifications", value = " update vendorClassifications")
	@PutMapping("/vendorClassifications")
	public JsonResponse updatevendorClassifications(@RequestBody VendorClassifications vendorClassifications) {
		return vendorService.updateVendorClassifications(vendorClassifications);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for create new Vendor Classifications", value = "Create new Vendor Classifications")
	@PostMapping("/vendorClassifications")
	public JsonResponse createvendorClassifications(@RequestBody VendorClassifications vendorClassifications) {
		return this.vendorService.createVendorClassifications(vendorClassifications);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER') ")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for delete Assettype", value = " delete vendorClassifications")
	@DeleteMapping("/vendorClassifications/{name}")
	public JsonResponse deletevendorClassifications(@PathVariable String name) {
		return vendorService.deleteVendorClassifications(name);
	}

	// this api used in search.
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Vendor List", value = "Get Vendor List")
	@GetMapping("/pageByVendorIdOrName")
	public Page<VendorDto> getVendorsOnSearch(@RequestParam(name = "query", required = false) String query,
			@RequestParam(name = "vendorclassification", required = false) String vendorclassification,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return vendorService.getVendors(vendorclassification, query, orderBy, page - 1, size);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update Vendor to set ManualIntervention", value = "Update Vendor to set ManualIntervention")
	@PutMapping("/updateManualIntervention")
	public JsonResponse updateManualIntervention(
			@ApiIgnore Authentication authentication,
			@RequestBody List<String> vendorIds,@RequestParam(name = "manualIntervention", required = false) Boolean manualIntervention) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return vendorService.setManualIntervention(vendorIds, manualIntervention,logedInUser);
	}
			

}
