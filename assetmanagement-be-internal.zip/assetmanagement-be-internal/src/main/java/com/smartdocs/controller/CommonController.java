package com.smartdocs.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.Manager;
import com.smartdocs.repository.BillDocumentRepository;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.AdminService;
import com.smartdocs.service.AssetAccountService;
import com.smartdocs.service.AssetService;
import com.smartdocs.service.DocumentUploadService;
import com.smartdocs.service.EmailChannelService;
import com.smartdocs.service.RobotLogService;
import com.smartdocs.service.RobotService;
import com.smartdocs.service.VendorService;
import com.smartdocs.service.util.EncryptionDecryption;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "CommonController", value = "CommonController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/common")
public class CommonController {

	@Autowired
	private AdminService adminService;

	@Autowired
	private DocumentUploadService documentService;

	@Autowired
	private EmailChannelService emailChannelService;

	@Autowired
	private VendorService vendorService;

	@Autowired
	private RobotService robotService;

	@Autowired
	private AssetService assetService;

	@Autowired
	private AssetAccountService assetAccountService;

	@Autowired
	private RobotLogService robotLogService;

	@Autowired
	private BillDocumentRepository billDocumentRepository;

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_EmailConfig','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get emailchannel ", value = "is Api for get emailchannel")
	@GetMapping("/emailChannel/page")
	public Page<Map<String, Object>> getEmailPage(@RequestParam(name = "email", required = false) String email,
			@RequestParam(name = "authType", required = false) String authType,
			@RequestParam(name = "tenantId", required = false) String tenantId,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return emailChannelService.getEmailChannel(email, authType, orderBy, tenantId, page - 1, size);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Document Url ", value = "is Api for get Document Url ")
	@GetMapping(value = "/buildDownloadDocURL/{docId}")
	public JsonResponse buildDownloadDocURL(@PathVariable("docId") String docId) {
		String url = documentService.buildURL(adminService.getSmartStoreConfig().get(0), docId, "get", null);
		return new JsonResponse(url, JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_EmailConfig','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update Shared Email ", value = "is Api for Update Shared Email ")
	@DeleteMapping(value = "/emailChannel/{emailChannelId}")
	public JsonResponse deleteEmailChannel(@PathVariable("emailChannelId") String emailChannelId) {
		return emailChannelService.deleteEmailChannel(emailChannelId);
	}

	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_EmailConfig','EDIT')")
	@PutMapping(value = "/updateSharedEmail/{id}/{sharedEmail}")
	public JsonResponse updateSharedEmail(@PathVariable String id, @PathVariable String sharedEmail) {
		return emailChannelService.updateEmailChannel(id, sharedEmail);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Manager','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for create new Manager", value = "Create new Manager")
	@PostMapping("/manager/create")
	public JsonResponse createManager(@RequestBody Manager manager) {
		return this.adminService.createManager(manager);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Manager','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update  Manager", value = "Update Manager")
	@PutMapping("/manager/update/{id}")
	public JsonResponse updateManager(@RequestBody Manager manager, @PathVariable Long id) {
		return this.adminService.updateManager(id, manager);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Manager','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for delete Manager", value = "Delete Manager")
	@DeleteMapping("/manager/delete/{id}")
	public JsonResponse deleteManager(@PathVariable Long id) {
		return this.adminService.deleteManager(id);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get All Assets By Pagination", value = "Get All Assets")
	@GetMapping("/manager/page")
	public Page<Manager> getPagination(@RequestParam(name = "order") String orderBy,
			@RequestParam(name = "name", required = false) String name,
			@RequestParam(name = "email", required = false) String email, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return this.adminService.getPage(page - 1, size, orderBy, name, email);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api is for update and delete manager for all assets", value = "Action on asset's managers")
	@PutMapping("/manager/action")
	public JsonResponse actionOnMangers(@ApiIgnore Authentication authentication, @RequestParam int managerId,
			@RequestParam boolean action) {
		UserPrincipal user = (UserPrincipal) authentication.getPrincipal();
		return adminService.actionOnAssetManagers(user, managerId, action);
	}

	@Deprecated
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Manager List", value = "Get Manager List")
	@GetMapping("/manager/list")
	public List<Manager> getListOFManager() {
		return this.adminService.getListOfManager();
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api is for Manager List through assetCode", value = "Get Manager List")
	@GetMapping("/manager/getByAssetCode/{AssetCode}")
	public List<Manager> getAssetIdByAssetCode(@PathVariable String AssetCode) {
		return adminService.getAssetIdByAssetCode(AssetCode);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api is for get AES decrypt Format", value = "AES decrypt Format")
	@GetMapping("/getAESDecryptFormat")
	public String getAESDecryptFormat(@RequestParam String format) {
		try {
			return EncryptionDecryption.decrypt(format);
		} catch (Exception e) {
			return "Incorrect Encrypt Format";
		}
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api is for count of Assets, Accounts, Robots and Vendors", value = "Get count of Assets, Accounts, Robots and Vendors")
	@GetMapping("/count/asset-robot-account-vendor")
	public Map<String, Long> getCounts() {
		Map<String, Long> mapCount = new HashMap<>();
		mapCount.put("totalVendors", vendorService.getTotalVendors());
		mapCount.put("totalManualIntervationVendors", vendorService.getTotalManualIntervationsVendors());
		mapCount.put("totalBotVendors", vendorService.getTotalVendorsHaveBots());
		mapCount.put("totalAssets", assetService.getTotalAssets());
		mapCount.put("totalAssetAccount", assetAccountService.getTotalAssetAccounts());
		mapCount.put("totalRobots", robotService.getTotalARobots());
		return mapCount;
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api is for count of Robots Logs", value = "Get count of Robots Logs")
	@GetMapping("/count/robotLogs")
	public Map<String, Long> getCountsOfRobotLogs() {
		Map<String, Long> mapCount = new HashMap<>();
		mapCount.put("totalBotExecutions", robotLogService.getTotalRobotsLogs());
		mapCount.put("totalFailedExecutions", robotLogService.getTotalRobotsLogsByStatus("FAILURE"));
		mapCount.put("totalSuccessExecutions", robotLogService.getTotalRobotsLogsByStatus("SUCCESS"));
		return mapCount;
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api is for count of bills", value = "Get count of Bills")
	@GetMapping("/count/bills")
	public Map<String, Long> getCountsOfBills() {
		Map<String, Long> mapCount = new HashMap<>();
		mapCount.put("totalInvoices", billDocumentRepository.count());
		mapCount.put("totalBotInvoices", billDocumentRepository.countBillsByBots());
		mapCount.put("totalHumanInvoices", billDocumentRepository.countBillsHaveManualIntervention());
		return mapCount;
	}

}
