package com.smartdocs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.SystemConfig;
import com.smartdocs.model.TaskStatus;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.SystemConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "SystemConfigController", value = "SystemConfigController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/systemConfig")
public class SystemConfigController {

	@Autowired
	private SystemConfigService systemConfigService;
	
	@PreAuthorize("hasRole('COMPANY_USER') and (hasPermission('AP_SystemConfigurator','EDIT') )")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update System Configuration ", value = "Update System Configuration")
	@PutMapping("/update/{config}")
	public JsonResponse updateConfiguation(@RequestBody SystemConfig systemConfig,@PathVariable String config) {
		return systemConfigService.updateConfiguartion(config, systemConfig);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER') and (hasPermission('AP_SystemConfigurator','EDIT') )")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get System Configuration ", value = "Get System Configuration ")
	@GetMapping("/{config}")
	public JsonResponse getConfig(@PathVariable String config) {
		return systemConfigService.getConfiguartion(config);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and (hasPermission('AP_SystemConfigurator','EDIT') )")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get All tasks ", value = "Get All tasks")
	@GetMapping("/task/list")
	public List<TaskStatus> getAllTask(){
		return systemConfigService.listTask();
	}
	
	@PreAuthorize("hasRole('COMPANY_USER') and (hasPermission('AP_SystemConfigurator','EDIT') )")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@GetMapping("/task/execute/{id}")
	public JsonResponse execuiteTask(@ApiIgnore Authentication authentication,@PathVariable String id){
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return systemConfigService.execute(logedInUser,id);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Task Detail ", value = " All tasks")
	@GetMapping("/task/{id}")
	public TaskStatus getTask(@PathVariable String id){
		return systemConfigService.getTask(id);
	}
}
