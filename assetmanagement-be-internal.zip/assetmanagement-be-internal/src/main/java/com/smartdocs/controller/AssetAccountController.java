package com.smartdocs.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.AssetAccountExcelRow;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.MultipartDto;
import com.smartdocs.dto.UtilitySubmitRequest;
import com.smartdocs.model.group.AssetAccountProjection;
import com.smartdocs.model.log.ApplicationLog;
import com.smartdocs.repository.ApplicationLogRepository;
import com.smartdocs.service.AssetAccountService;
import com.smartdocs.service.DocumentProcessorService;
import com.smartdocs.service.util.Constants;
import com.smartdocs.service.util.HttpReqRespUtils;
import com.smartdocs.sql.dto.AccountCustomInf;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import net.sf.json.JSONException;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "AssetAccountController", value = "AssetAccountController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/assetAccount")
public class AssetAccountController {

	@Autowired
	private DocumentProcessorService documentProcessorService;

	@Autowired
	private ApplicationLogRepository applicationLogRepository;

	@Autowired
	private AssetAccountService assetAccountService;

	@PreAuthorize("hasRole('COMPANY_USER') and (hasPermission('AP_Asset','EDIT') or hasPermission('AP_FailedBotL1','EDIT') or hasPermission('AP_FailedBotL2','EDIT'))")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@PostMapping(value = "/upload", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
	public JsonResponse upload(HttpServletRequest request, @ModelAttribute UtilitySubmitRequest data,
			HttpServletResponse response, @ApiIgnore Authentication authentication,
			@RequestParam(required = false) Boolean isDupCheckRequire) {
		System.out.println("/assetAccount/upload");
		System.out.println("VendorId=:" + data.getVendorId());

		String fileName = "" + data.getFile().getOriginalFilename();
		String txId = UUID.randomUUID().toString();
		int rescode;
		JsonResponse jsonResponse = documentProcessorService.process(data, txId, authentication, isDupCheckRequire);
		if (JsonResponse.STATUS_200.equals(jsonResponse.getStatusCode())) {
			rescode = 1;
		} else {
			rescode = 2;
		}
		applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
				Constants.ACTIVITY_TYPE_DELETION, "System", "Robot", null, null, fileName + " file Uploaded ",
				" " + data.getAccountno() + " " + data.getAssetId() + " >>" + rescode, " ", "/assetAccount/upload",
				""));

		return jsonResponse;
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api will give Asset Accounts Number", value = "Asset Accounts Number")
	@GetMapping("/getAssetAccountsNo")
	public List<String> getAssetAccountNo(@RequestParam String accountNo) {
		return assetAccountService.getAssetAccountNo(accountNo);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Account Vendor Details ", value = "Account Vendor Details ")
	@GetMapping("/account-vendor")
	public Page<AssetAccountProjection> getUtilityVendor(@RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size, @RequestParam(name = "order", required = true) String order,
			@RequestParam(name = "assetQuery", required = false) String assetQuery,
			@RequestParam(name = "accountNo", required = false) String accountNo,
			@RequestParam(name = "vendorId", required = false) String vendorId) {
		return assetAccountService.getAssetAccountDetails(vendorId, assetQuery, accountNo, order, page - 1, size);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Asset','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for bulk upload asset account.", value = " Bulk Upload Asset Account")
	@PostMapping(value = "/upload-asset-account/jsonData", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
	public JsonResponse excelToJson(@ModelAttribute MultipartDto data) throws IOException, JSONException {
		try {
			InputStream inputStream = data.getFile().getInputStream();
			return assetAccountService.convertExceltoJson(inputStream);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Uploaded File Invalid", JsonResponse.STATUS_500);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Asset','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for bulk upload asset account.", value = "Validate All Accoont's record")
	@PostMapping(value = "/upload-asset-account/validateAllRecords")
	public JsonResponse validateUploadedData(@RequestBody List<AssetAccountExcelRow> assetRows) {
		try {
			return assetAccountService.validateAllAssetAccountExcelRow(assetRows);
		} catch (Exception e) {
			e.printStackTrace();
			return new JsonResponse("", JsonResponse.RESULT_FAILED, "Ex:" + e.getMessage(), JsonResponse.STATUS_500);
		}
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Asset','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for bulk upload asset account.", value = "Save All Accoont's records")
	@PostMapping(value = "/upload-asset-account/saveAllRecords")
	public JsonResponse saveAll(@RequestBody List<AssetAccountExcelRow> assetRows) {
		try {
			return assetAccountService.saveAllAssetAccountExcelRow(assetRows);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Can't save AssetAccounts", JsonResponse.STATUS_500);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api will give Asset Accounts Custom data", value = "Get Asset Accounts Custom data")
	@GetMapping("/getAccountDetails")
	public List<AccountCustomInf> getAccountDetails(@RequestParam String assetCode,
			@RequestParam(required = false) String channel, @RequestParam(required = false) String vendorQuery) {
		return assetAccountService.getAccountDetails(assetCode, channel, vendorQuery);
	}
}
