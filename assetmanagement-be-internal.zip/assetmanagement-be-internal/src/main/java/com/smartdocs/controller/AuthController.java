package com.smartdocs.controller;

import java.time.ZonedDateTime;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.AuthenticationRequest;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.JwtResponse;
import com.smartdocs.model.AccessManagement;
//import com.smartdocs.model.User;
import com.smartdocs.model.log.ApplicationLog;
import com.smartdocs.mongo.collectionhelpers.Permission;
import com.smartdocs.mongo.collections.User;
import com.smartdocs.mongo.repository.UserRepository;
import com.smartdocs.repository.AccessManagementRepository;
import com.smartdocs.repository.ApplicationLogRepository;
//import com.smartdocs.repository.UserRepository;
import com.smartdocs.security.jwt.JwtProvider;
import com.smartdocs.security.service.UserDetailsServiceImpl;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.AuthProfileService;
import com.smartdocs.service.util.Constants;
import com.smartdocs.service.util.HttpReqRespUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "AuthController", value = "AuthController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/auth")
public class AuthController {

	@Autowired
	private AuthProfileService authProfileService;
	
	private static final Logger log = LoggerFactory.getLogger(AuthController.class);

	@Autowired
	private JwtProvider jwtProvider;
	@Autowired
	private UserDetailsServiceImpl userDetailService;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ApplicationLogRepository applicationLogRepository;

	@Autowired
	private AccessManagementRepository accessManagementRepository;
	
	
	@Value("${dateformate}")
	private String dateformate;

	@Value("${dateAndTimeFormate}")
	private String dateAndTimeFormate;
	

//	@PostMapping("/signin")
//	@ApiOperation(notes = "This api helps in signin", value = "let's signin")
//	public ResponseEntity<JwtResponse> authenticateUser(@RequestBody AuthenticationRequest loginRequest) {
//		log.info("AuthRestAPIs -> /auth/signin : authenticateUser");
//
//		try {
//			Authentication authentication = authenticationManager.authenticate(
//					new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));
//			SecurityContextHolder.getContext().setAuthentication(authentication);
//			UserPrincipal user = ((UserPrincipal) authentication.getPrincipal());
//			String jwt = jwtProvider.generateJwtToken(authentication,
//					HttpReqRespUtils.getClientIpAddressIfServletRequestExist());
//			log.debug("Token generated for user : {}", user.getEmail());
//			// String ip,String type, String agent,String name, String itemType, String
//			// itemId, String title, String description
//			applicationLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
//					Constants.ACTIVITY_TYPE_USER_SIGNIN, user.getEmail(), user.getName(), null, null,
//					user.getName() + " Successfully sign in ", "", "AuthRestAPIs:authenticateUser()", "/auth/signin",user.getRole()));
//			Optional<User> entity = userRepository.findByEmailIgnoreCase(loginRequest.getUsername());
//			if (entity.isPresent()) {
//				if (entity.get().getInvalidPasswordAttempts() > 0) {
//					entity.get().setInvalidPasswordAttempts(0);
//				}
//				entity.get().setAccessToken(jwt);
//				entity.get().setLastLogin(ZonedDateTime.now());
//				entity.get().setLastActivity(ZonedDateTime.now());
//				userRepository.save(entity.get());
//			}
//			user.setDateAndTimeFormate(dateAndTimeFormate);
//			user.setDateformate(dateformate);
//			return ResponseEntity.ok(new JwtResponse(jwt, user, JwtResponse.LOGIN_BASIC_UP));
//		}
//
//		catch (BadCredentialsException ex) {
//			log.info("BadCredentialsException during signin: {}", ex.getMessage());
//			Optional<User> user = userRepository.findByEmailIgnoreCase(loginRequest.getUsername());
//			if (user.isPresent()) {
//				user.get().addInvalidPasswordAttempt();
//				log.info("Update invalid password Attempt.");
//				userRepository.save(user.get());
//				throw new BadCredentialsException(
//						"INCORRECT_LOGIN_DETAIL___" + (7 - user.get().getInvalidPasswordAttempts()));
//			} else {
//				throw new BadCredentialsException("INCORRECT_LOGIN_DETAIL");
//			}
//		}
//
//	}

	@PostMapping("/app/signin")
	@ApiOperation(notes = "This api helps in signin", value = "let's signin")
	public ResponseEntity<JsonResponse> authenticateAppUser(@RequestBody AuthenticationRequest loginRequest) {
		log.info("AuthRestAPIs -> /auth/signin : authenticateUser");

		try {

			Optional<AccessManagement> existAccessManagement = accessManagementRepository
					.findByAppIdAndAppSecret(loginRequest.getUsername(), loginRequest.getPassword());
			if (existAccessManagement.isPresent()) {
				Map<String,Permission> pg= null;
				Optional<User> user = userRepository.findByEmail(existAccessManagement.get().getUserEmail());
				 if(user.get().getRole().equals("CompanyUser")) {
					 pg= authProfileService.getAllPermissionGroups(user.get());
				}
				UserPrincipal userPrinciple = UserPrincipal.build(user.get(),pg);
				String jwt = jwtProvider.generateJwtToken(userPrinciple,
						HttpReqRespUtils.getClientIpAddressIfServletRequestExist());

				applicationLogRepository
						.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
								Constants.ACTIVITY_TYPE_USER_SIGNIN, user.get().getEmail(), user.get().getFirstname(), null, null,
								user.get().getFirstname() + " Successfully sign in ", "", "AuthRestAPIs:authenticateUser()",
								"/auth/app/signin",user.get().getRole()));

				user.get().setAppAccessToken(jwt);
				user.get().setLastActivity(ZonedDateTime.now());
				userRepository.save(user.get());
				return ResponseEntity.ok(new JsonResponse(new JwtResponse(jwt, userPrinciple, JwtResponse.LOGIN_APP),
						JsonResponse.RESULT_SUCCESS, JsonResponse.STATUS_200));
			} else {
				return ResponseEntity
						.ok(new JsonResponse(JsonResponse.RESULT_FAILED, "Invalid url", JsonResponse.STATUS_400));
			}

		}

		catch (BadCredentialsException ex) {
			log.info("BadCredentialsException during signin: {}", ex.getMessage());
			Optional<User> user = userRepository.findByEmailIgnoreCase(loginRequest.getUsername());
			if (user.isPresent()) {
				user.get().addInvalidPasswordAttempt();
				log.info("Update invalid password Attempt.");
				userRepository.save(user.get());
				throw new BadCredentialsException(
						"INCORRECT_LOGIN_DETAIL___" + (7 - user.get().getInvalidPasswordAttempts()));
			} else {
				throw new BadCredentialsException("INCORRECT_LOGIN_DETAIL");
			}
		}

	}

	@PreAuthorize("hasAnyRole('SUPER_ADMIN','COMPANY_USER', 'SYSTEM_ADMIN','SUPPLIER_USER','SUPPLIER_ADMIN','SUPPLIER_LOGISTICS','SUPPLIER_ACCOUNTING')")
	@GetMapping("/signout")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "Logout api", value = "")
	public ResponseEntity<JsonResponse> logout(HttpServletRequest request, @ApiIgnore Authentication authentication) {
		log.info("AuthRestAPIs -> /auth/signout : logout");
		JsonResponse jsonResponse = new JsonResponse();

		UserPrincipal loggedInUser = (UserPrincipal) authentication.getPrincipal();

		String app = request.getParameter("app");
		if (StringUtils.isBlank(app)) {
			app = "default";
		}

		if (loggedInUser != null) {
			boolean result = userDetailService.logoutDeleteToken(app, loggedInUser.getEmail());
			if (result) {
				log.info("User logged out successfully");
				jsonResponse.setResult("Logout successfully");
				jsonResponse.setStatus(JsonResponse.RESULT_SUCCESS);
			} else {
				log.info("Logged out failed");
				jsonResponse.setResult("Some issue in logout");
				jsonResponse.setStatus(JsonResponse.RESULT_FAILED);
			}
		} else {
			log.info("User logged out successfully");
			jsonResponse.setResult("Logout successfully");
			jsonResponse.setStatus(JsonResponse.RESULT_SUCCESS);
		}
		return ResponseEntity.ok(jsonResponse);

	}

}
