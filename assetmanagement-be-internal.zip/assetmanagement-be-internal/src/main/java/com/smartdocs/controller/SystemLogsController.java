package com.smartdocs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.smartdocs.model.log.SystemLogs;
import com.smartdocs.service.SystemlogsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(tags = "SystemLogsController", value = "SystemLogsController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/systemLogs")
public class SystemLogsController {

	@Autowired
	private SystemlogsService systemlogsService;

	
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_SystemLog','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Page for System Log", value = "Get Page For System Log")
	@GetMapping("/page")
	public Page<SystemLogs> getAllSystemLogs(@RequestParam(name = "orderBy", required = false) String orderBy,
			@ApiParam(required = true) @RequestParam("page") int page,
			@ApiParam(required = true) @RequestParam("limit") int size,
			@ApiParam(value = "category", required = false) @RequestParam(required = false) String category,
			@ApiParam(value = "ipAddress", required = false) @RequestParam(required = false) String ipAddress,
			@ApiParam(value = "jobId", required = false) @RequestParam(required = false) String jobId,
			@ApiParam(value = "email", required = false) @RequestParam(required = false) String email,
			@ApiParam(value = "fromDate", required = false) @RequestParam(required = false) String fromDate,
			@ApiParam(value = "toDate", required = false) @RequestParam(required = false) String toDate
			) {
		return systemlogsService.getAllSystemLogs(orderBy, page - 1, size, category,ipAddress,email,fromDate,toDate,jobId);
	}

}
