package com.smartdocs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.model.log.ApplicationLog;
import com.smartdocs.service.ApplicationLogsServices;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@Api(tags = "ApplicationLogsController", value = "ApplicationLogsController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/applicationLogs")
public class ApplicationLogsController {
	
	@Autowired
	private ApplicationLogsServices applicationLogsServices;
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Page for Application Logs", value = "Get Page For Application Logs")
	@GetMapping("/page")
	public Page<ApplicationLog> getAllApplicationLogs(@RequestParam(name = "orderBy", required = true) String orderBy,
			@ApiParam(required = true) @RequestParam("page") int page,
			@ApiParam(required = true) @RequestParam("limit") int size,
			@ApiParam(value = "type", required = false) @RequestParam(required = false) String type,
			@ApiParam(value = "ipAddress", required = false) @RequestParam(required = false) String ipAddress,
			@ApiParam(value = "email", required = false) @RequestParam(required = false) String email,
			@ApiParam(value = "date", required = false) @RequestParam(required = false) String date
			) {
	    	return applicationLogsServices.getAllApplicationLogs(orderBy, page-1, size, type,ipAddress,email,date);
	}

}
