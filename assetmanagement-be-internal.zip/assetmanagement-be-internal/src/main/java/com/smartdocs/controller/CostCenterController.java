package com.smartdocs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.CostCenter;
import com.smartdocs.model.dto.CostCenterDto;
import com.smartdocs.service.CostCenterService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Api(tags = "CostCenterController", value = "CostCenterController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/costCenter")
public class CostCenterController {
	
	@Autowired
	private CostCenterService costCenterService;

	@PreAuthorize("hasRole('COMPANY_USER') and  hasPermission('AP_CostCenter','EDIT') ")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for create new Cost Center", value = "Craete new Cost Center")
	@PostMapping
	public JsonResponse createCostCenter(@RequestBody CostCenter costCenter) {
		return this.costCenterService.createCostCenter(costCenter);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and  hasPermission('AP_CostCenter','EDIT') ")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for delete Cost Center", value = "Delete Cost centers by ID")
	@DeleteMapping("/{id}")
	public JsonResponse deleteCostCenter(@PathVariable String id) {
		return this.costCenterService.deleteCostCenter(id);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update Cost Center", value = "Update  Cost Center By ID")
	@PutMapping("/{id}")
	public JsonResponse updateCostCenter(@RequestBody CostCenterDto costCenterDto, @PathVariable String id) {
		return this.costCenterService.updateCostCenter(costCenterDto, id);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api get Cost Center", value = "Get Cost Center By ID")
	@GetMapping("/{id}")
	public CostCenter getCostCenter(@PathVariable String id) {
		return this.costCenterService.getCostCenter(id);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Cost Center page", value = "Get Cost center page")
	@GetMapping("/page")
	public Page<CostCenter> getCostCenterPage(@RequestParam(name = "query", required = false) String query,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return this.costCenterService.getCostCenterPage(query, orderBy, page - 1, size);
	}

}
