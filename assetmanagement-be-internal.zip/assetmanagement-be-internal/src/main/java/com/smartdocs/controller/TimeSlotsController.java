package com.smartdocs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.SystemUtilityDto;
import com.smartdocs.service.TimeSlotsService;
import com.smartdocs.sql.dto.TimeSlotsCustom;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Api(tags = "TimeSlotsController", value = "TimeSlotsController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/timeSlots")
public class TimeSlotsController {
	
	@Autowired
	private TimeSlotsService timeSlotsService;
	
	
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Create Time Slots", value = "Create Time Slots")
	@PostMapping("/createTimeSlots")
	public void createTimeSlots() {
		timeSlotsService.setupTimeSlot();
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Create Time Slots By SQL Function", value = "Create Time Slots By SQL Function")
	@GetMapping("/createTimeSlots-SQLFunction")
	public String createTimeSlotsBySQLFunction() {
		return timeSlotsService.creatTimeSlotsBySQLFunction();
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Count timeslots and scheduled bots", value = " Count timeslots and scheduled bots")
	@GetMapping("/countTimeSlots")
	public SystemUtilityDto countTimeslotsAndScheduledBots()  {
	return timeSlotsService.getCountTimeslotsAndScheduledBots();
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get interval timeslots ", value = "Get interval timeslots ")
	@GetMapping("/getInternalTimeSLotsDetails")
	public List<TimeSlotsCustom> getInternalTimeSLotsDetails(@RequestParam (required = false) String tz,@RequestParam (required = false)  String dateTime)  {
	return timeSlotsService.intervalTimeSlots(tz,dateTime);
	}

}
