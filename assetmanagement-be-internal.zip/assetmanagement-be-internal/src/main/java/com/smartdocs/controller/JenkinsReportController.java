package com.smartdocs.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.RobotFailedBotActionRequest;
import com.smartdocs.model.RobotLog;
import com.smartdocs.model.RobotLogActivityDetail;
import com.smartdocs.model.group.RobotLogData;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.RobotLogService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "JenkinsReportController", value = "JenkinsReportController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/jenkinsReport")
public class JenkinsReportController {


	@Autowired
	private RobotLogService robotlogService;

	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "Level 1 Failed Bot Report ", value = "Level 1 Failed Bot Report")
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_FailedBotL1','READ') ")
	@GetMapping("/l1/page")
	public Page<RobotLogData> failedBotL1(@RequestParam(name = "order") String orderBy,
			@RequestParam(name = "page") int page, @RequestParam(name = "limit") int size,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "botName", required = false) String botName,
			@RequestParam(name = "buildStatus", required = false) String buildStatus) {
		return robotlogService.robotLogPage(orderBy, page-1, size, botName, assetCode, vendorId, accountNumber, RobotLog.STAGE_L1,
				buildStatus);
	}
	
	
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "Download Excel sheet for Level 1 Failed Bot", value = "Level 1 Failed Bot Report")
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_FailedBotL1','READ') ")
	@GetMapping("/l1/download")
	public ResponseEntity<InputStreamResource> failedBotL1Download(
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "botName", required = false) String botName,
			@RequestParam(name = "buildStatus", required = false) String buildStatus) throws IOException {
		ByteArrayInputStream byteInputStream = robotlogService.robotLogPageDownload(botName, assetCode, vendorId, accountNumber, RobotLog.STAGE_L1,
				buildStatus);
		if (byteInputStream != null) {
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=FailedBots.xlsx")
					.contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
					.body(new InputStreamResource(byteInputStream));
		}
		return null;
	}
	
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "Level 2 Failed Bot Report ", value = "Level 2 Failed Bot Report")
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_FailedBotL2','READ') ")
	@GetMapping("/l2/page")
	public Page<RobotLogData> failedBotL2(@RequestParam(name = "order") String orderBy,
			@RequestParam(name = "page") int page, @RequestParam(name = "limit") int size,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "botName", required = false) String botName,
			@RequestParam(name = "buildStatus", required = false) String buildStatus) {
		return robotlogService.robotLogPage(orderBy, page-1, size, botName, assetCode, vendorId, accountNumber, RobotLog.STAGE_L2,buildStatus);
	}
	
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "failed Bot Report ", value = "failedBotReport")
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_FailedBotReport','READ') ")
	@GetMapping("/report")
	public Page<RobotLogData> failedBotReport(@RequestParam(name = "order") String orderBy,
			@RequestParam(name = "page") int page, @RequestParam(name = "limit") int size,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "botName", required = false) String botName,
			@RequestParam(name = "buildStatus", required = false) String buildStatus,
			@RequestParam(name = "status", required = false) String status,
			@RequestParam(name = "buildExTimeFrom", required = false) String buildExTimeFrom,
			@RequestParam(name = "buildExTimeTo", required = false) String buildExTimeTo,
			@RequestHeader(name = "tz", required = false) String clientTz,
			@RequestParam(name = "stage", required = false) Integer stage) {
	
		
		if(status!=null) {
			if("Level1Review".equalsIgnoreCase(status)) {
				status=RobotLog.STATUS_OPEN;
				stage=1;
			}
			else if("Level2Review".equalsIgnoreCase(status)) {
				status=RobotLog.STATUS_OPEN;
				stage=2;
			}
			else if("Completed".equalsIgnoreCase(status)) {
				status=RobotLog.STATUS_COMPLETE;
			}
			else if("SettoObselete".equalsIgnoreCase(status)) {
				status=RobotLog.STATUS_OBSOLETE;
			}
		}
		
		return robotlogService.robotReport(orderBy, page-1, size,
				botName, assetCode, vendorId, accountNumber,stage,
				buildStatus,status,clientTz,buildExTimeFrom,buildExTimeTo);
	}
	
	
	@PreAuthorize("hasRole('COMPANY_USER') and (hasPermission('AP_FailedBotL1','EDIT') or hasPermission('AP_FailedBotL2','EDIT')) ")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update status ", value = "Update status Action")
	@PutMapping("/updateAction")
	public JsonResponse updateAction(@ApiIgnore Authentication authentication,@RequestBody RobotFailedBotActionRequest actionRequest) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return robotlogService.action(logedInUser,actionRequest);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER') and (hasPermission('AP_FailedBotL1','EDIT') or hasPermission('AP_FailedBotL2','EDIT')) ")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for bulk Update Action ", value = "Perform bulk Update Action")
	@PutMapping("/bulkUpdateAction")
	public JsonResponse bulkUpdateAction(@ApiIgnore Authentication authentication,@RequestBody RobotFailedBotActionRequest actionRequest) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return robotlogService.bulkUpdation(actionRequest,logedInUser);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "getLogs ", value = "getLogs")
	@GetMapping("/getLogs/{id}")
	public List<RobotLogActivityDetail> getLogs(@PathVariable String id) {
		return robotlogService.getLogs(id);
	}
	
}
