package com.smartdocs.controller;

import java.io.IOException;
import java.net.URISyntaxException;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.RobotCustomData;
import com.smartdocs.dto.RobotReportDto;
import com.smartdocs.jenkins.dto.APJobWithDetails;
import com.smartdocs.model.Robot;
import com.smartdocs.service.JenkinsService1;
import com.smartdocs.service.JenkinsService2;
import com.smartdocs.service.RobotService;
import com.smartdocs.sql.dto.RobotInf;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Api(tags = "RobotController", value = "RobotController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/robot")
public class RobotController {

	@Autowired
	private RobotService robotService;

	@Autowired
	private JenkinsService1 jenkinsService;
	
	@Autowired
	private JenkinsService2 jenkinsService2;

	

	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Robot Page", value = "Get Robot Page")
	@GetMapping("/search")
	public Page<RobotCustomData> getPage(@RequestParam(name = "status", required = false) String status,
			@RequestParam(name = "query", required = false) String query,
			@RequestParam(name = "accountNo", required = false) String accountNo,
			@RequestParam(name = "assetQuery", required = false) String assetQuery,
			@RequestParam(name = "id", required = false) String id,
			@RequestParam(value = "order") String orderBy, @RequestParam(value = "limit") Integer size,
			@RequestParam(value = "pageIndex") Integer page) {
		return robotService.searchRobotPage(assetQuery, status, query,accountNo,id, page - 1, size, orderBy);
	}
	
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Robot Page", value = "Get Robot Page")
	@GetMapping("/page")
	public Page<RobotInf> findRobotsByPage(@RequestParam(name = "status", required = false) String status,
			@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "accountNo", required = false) String accountNo,
			@RequestParam(name = "assetQuery", required = false) String assetCode,
			@RequestParam(name = "frequency", required = false) String frequency,
			@RequestParam(value = "order") String orderBy, @RequestParam(value = "limit") int size,
			@RequestParam(value = "pageIndex") int page) {
		return robotService.findRobots(assetCode, status, frequency, vendorId, accountNo, page-1, size, orderBy);
	}
	
	@Deprecated
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Robot List", value = "Get Robot List")
	@GetMapping
	public List<Robot> getList(@RequestParam(name = "assetCode") String assetCode,
			@RequestParam(name = "status", required = false) String status) {
		return robotService.robotList(assetCode,status);
	}
	
	@Deprecated
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Vendor List in Robot", value = "Vendor List in Robot")
	@GetMapping("/{vendorId}")
	public List<Map<String, Object>> getListOfVendor(@PathVariable String vendorId) {
		return robotService.robotListOfVendor(vendorId);
	}
	
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for run jenkins", value = "run jenkins")
	@GetMapping("/run/{jobId}")
	public JsonResponse run(@PathVariable String jobId) throws URISyntaxException, IOException, InterruptedException {
		System.out.println("job Id " + jobId);
		String txtId = UUID.randomUUID().toString();
		return jenkinsService.run(jobId,txtId);

	}
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for run jenkins", value = "run jenkins")
	@GetMapping("/runFailBot/{jobId}")
	public JsonResponse runFailBot(@PathVariable String jobId) throws URISyntaxException, IOException, InterruptedException {
		System.out.println("job Id " + jobId);
		String txtId = UUID.randomUUID().toString();
		return jenkinsService2.run(jobId,txtId);

	}
	
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This api to get jod builds details", value = "get jod builds details")
	@GetMapping("/getJenkinsDetail/{jobId}")
	public APJobWithDetails getDetail(@PathVariable String jobId,
			@RequestParam(name = "serverName", required = true) String serverName) {
		System.out.println("job Id " + jobId);
		if (serverName.equals(APJobWithDetails.SERVER1)) {
			return jenkinsService.getJobHistoryDetails(jobId);
		}
		else if (serverName.equals(APJobWithDetails.SERVER2)) {
			 return jenkinsService2.getJobHistoryDetails(jobId);
		}
		return null;
	}
	
	@Deprecated
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get execution time", value = "get execution time jenkins")
	@GetMapping("/getJobDuration/{jobId}")
	public String getJobDuration(@PathVariable String jobId) throws URISyntaxException, IOException {
		System.out.println("job Id " + jobId);
		return jenkinsService.getJobDuration(jobId);
	}

	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This api to get jod build console info", value = "get jod build console info")
	@GetMapping("/getJenkinsDetail/{jobId}/{buildNo}")
	public String getDetailConsole(@PathVariable int buildNo, @PathVariable String jobId,
			@RequestParam(name = "serverName", required = true) String serverName) {
		System.out.println("job Id " + jobId);
		try {
			if (serverName.equals(APJobWithDetails.SERVER1)) {
				return jenkinsService.getBuildConsole(buildNo, jobId);
			}
			else if (serverName.equals(APJobWithDetails.SERVER2)){
				return jenkinsService2.getBuildConsole(buildNo, jobId);
			}
			
		} catch (Exception e) {
			return null;
		}
		return null;
	}
	
	@Deprecated
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Active Bots futher 5 min", value = "Get Active Bots")
	@GetMapping("/active-bots")
	public Page<RobotCustomData> getActiveRobots(@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNo", required = false) String accountNo,
		    @RequestParam(name = "formDate", required = false) String formDate,
			@RequestParam(name = "toDate", required = false) String toDate,
			@RequestParam(name = "clientTz", required = true) String clientTz,
			@RequestParam(value = "order") String orderBy, @RequestParam(value = "limit") Integer size,
			@RequestParam(value = "pageIndex") Integer page){
		return robotService.getActiveRobots(assetCode, vendorId, accountNo, formDate, clientTz, toDate, orderBy, page-1, size);
	}

	@Deprecated
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Active Bots futher 5 min", value = "Get Active Bots")
	@GetMapping("/upcoming-bots")
	public Page<RobotCustomData> getUpcoingRobots(@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNo", required = false) String accountNo,
		    @RequestParam(name = "formDate", required = false) String formDate,
			@RequestParam(name = "toDate", required = false) String toDate,
			@RequestParam(name = "clientTz", required = true) String clientTz,
			@RequestParam(value = "order") String orderBy, @RequestParam(value = "limit") Integer size,
			@RequestParam(value = "pageIndex") Integer page){
		return robotService.getUpcomingRobots(assetCode, vendorId, accountNo, formDate, clientTz, toDate, orderBy, page-1, size);
	}
	 
	
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Robot By AssetCode,AccountNo and VendorId", value = "get Robot by AssetCode,AccountNo and VendorId")
	@GetMapping("/getRobot/assetCode-vendorId-accountNo")
    public JsonResponse getRobot(@RequestParam String assetCode,@RequestParam String accountNo,@RequestParam String  vendorId) throws URISyntaxException, IOException {
		return jenkinsService.getRobot(assetCode, accountNo, vendorId);
	}
	
	

	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Robot By AssetCode,AccountNo and VendorId", value = "get Robot by AssetCode,AccountNo and VendorId")
	@GetMapping("/getRobotLatestConsole/{jobId}")
    public String getConsoleOfJob(@PathVariable String jobId) throws URISyntaxException, IOException {
		return jenkinsService2.getConsole(jobId);
	}
	
	@Deprecated
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for getting nextExecution by RobotId", value = "get nextExecution by RobotId")
	@GetMapping("/nextExecutedTimeList/{id}")
	public List<ZonedDateTime> nextExecution(@PathVariable String id){
		return robotService.getExecution(id);
	}
	
	//@NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for unpublish All Bot ", value = "unpublish All Bot")
	@DeleteMapping("/unpublishAllBot")
	public JsonResponse unpublishAllBot()  {
		 jenkinsService.deleteAllJobsInJenkinsServer();
		 jenkinsService2.deleteAllJobsInJenkinsServer(); 
	  return  new JsonResponse(JsonResponse.RESULT_SUCCESS, "Unpublished All Bots", JsonResponse.STATUS_200);

	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Jenkins server 1 URL ",value = "Get Jenkins server 1 URL")
	@GetMapping("/getJenkins1URL")
	public String getJenkinsURL(){
		return jenkinsService.getJenkinsURL();
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for to publishing and sceduling bots ",value = "publishing and sceduling bots")
	@GetMapping("/publishingJobAndScedulingBots")
	public JsonResponse publishingJobAndScedulingBots(
			@RequestParam String jobId,
			@RequestParam (required = true) boolean schedule) throws TransformerConfigurationException, ParserConfigurationException{
			return robotService.publishingJob(jobId, schedule);
	}
	
	// this is in use 
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "", value = "")
	@GetMapping("/publishBot/{botId}")
	public JsonResponse publishRobot( @PathVariable String botId) {
		System.out.println("botId Id " + botId);
		return robotService.publishRobot(botId);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This API to get Next execution from Jenkins", value = "Next execution from Jenkins")
	@GetMapping("/getNextExecJobs")
	public JsonResponse getNextExecJobs() {
		System.out.println("getNextExecJobs " );
		return new JsonResponse(jenkinsService.getNextExec(),JsonResponse.RESULT_SUCCESS, " ", JsonResponse.STATUS_200);
	}
	
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This API to get Next execution from Jenkins", value = "Next execution from Jenkins")
	@GetMapping("/getNextExecJobs/v1")
	public JsonResponse getNextExecJobsV1() {
		System.out.println("getNextExecJobs " );
		return new JsonResponse(jenkinsService.getNextExecv1(),JsonResponse.RESULT_SUCCESS, " ", JsonResponse.STATUS_200);
	}
	
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This API to get Next execution from Jenkins", value = "Next execution from Jenkins")
	@GetMapping("/robotReport")
	public RobotReportDto getRobotReport() {
		return robotService.getCurrentDayCountTimeSlots();
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This API to get Monthly success bots", value = "Get Monthly success bots")
	@GetMapping("/monthlySuccessBots")
	public Map<Long, Long> getMonthlyRobotSuccessExecutionReport() {
		return robotService.geTotalSuccessRobotInMonth();
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This API to get Monthly Fail bots", value = "Get Monthly Fail bots")
	@GetMapping("/monthlyFailedBots")
	public Map<Long, Long> getMonthlyRobotFailExecutionReport() {
		return robotService.geTotalFailRobotInMonth();
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This API to get Monthly Fail bots", value = "Get Monthly Fail bots")
	@GetMapping("/dailyFailedBots")
	public Map<Long, Long> getDailyRobotFailExecutionReport() {
		return robotService.geTotalFailRobotInDay();
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This API to get Monthly Fail bots", value = "Get Monthly Fail bots")
	@GetMapping("/dailySuccessBots")
	public Map<Long, Long> getDailyRobotSuccessExecutionReport() {
		return robotService.geTotalSuccessRobotInDay();
	}
}
