package com.smartdocs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.model.BufferDocument;
import com.smartdocs.service.BufferDocumentService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Api(tags = "BufferDocumentController", value = "BufferDocumentController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/bufferDocument")
public class BufferDocumentController {

	@Autowired
	private BufferDocumentService bufferDocumentService;

	@Value("${url}")
	private String url;

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get BufferDocument Page ", value = "is Api for get BufferDocument page")
	@GetMapping("/page")
	public Page<BufferDocument> search(@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "jobId", required = false) String jobId,
			@RequestParam(name = "status", required = false) Integer status,
			@RequestParam(name = "txId", required = false) String txId,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return bufferDocumentService.search(assetCode, vendorId, accountNumber, jobId, txId, status, page - 1, size,
				orderBy);
	}
}
