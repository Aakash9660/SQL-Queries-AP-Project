package com.smartdocs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.AccessManagementDto;
import com.smartdocs.dto.AppAccessDto;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.JwtResponse;
import com.smartdocs.exception.AccountNotExistException;
import com.smartdocs.model.AccessManagement;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.AccessManagementService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "AccessManagementController", value = "AccessManagementController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/app-access")
public class AccessManagementController {

	@Autowired
	private AccessManagementService accessManagementService;

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for create new App Access", value = "Create new App Access")
	@PostMapping
	public JsonResponse createAppAccess(@RequestBody AccessManagementDto accessManagementDto,
			@ApiIgnore Authentication authentication) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return accessManagementService.createAppAccess(logedInUser, accessManagementDto);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get App Access List", value = "Get App Access List")
	@GetMapping("/list")
	public List<AccessManagement> getListOfAppAccess(@ApiIgnore Authentication authentication) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return accessManagementService.getListOfAppAccess(logedInUser);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Signin", value = "Get Signin")
	@PostMapping("/signin")
	public ResponseEntity<JwtResponse> authenticatitaion(@RequestBody AppAccessDto accessDto) {
		return accessManagementService.authenticatitaion(accessDto);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Revoke App Access", value = " Revoke App Access")
	@DeleteMapping("/{appId}")
	public JsonResponse revokeAppAccess(@PathVariable String appId, @ApiIgnore Authentication authentication) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		if (logedInUser != null) {
			return accessManagementService.revokeAppAccess(appId, logedInUser);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, JsonResponse.STATUS_500);
		}
	}

	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get App Access Data", value = " Get App Access Data")
	@GetMapping("/{id}")
	public JsonResponse getAppAccess(@PathVariable Long id, @ApiIgnore Authentication authentication) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		if (logedInUser != null && id != null) {
			return accessManagementService.getAppAccessDetails(id, logedInUser);
		} else {
			return new JsonResponse(JsonResponse.RESULT_FAILED, JsonResponse.STATUS_500);
		}
	}

	@SuppressWarnings("deprecation")
	@PreAuthorize("hasRole('COMPANY_USER')")
	@GetMapping("/exception/{vendorId}")
	public boolean giveExceptions(String vendorId) {
		try {
			return accessManagementService.giveExceptions(vendorId);
		} catch (AccountNotExistException e) {
			e.printStackTrace();
		}
		return false;
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@SuppressWarnings("deprecation")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Refresh Token", value = "Get Refresh Token")
	@GetMapping("/getRefreshToken/{reqToken}")
	public String getToken(@PathVariable String reqToken) {
		return accessManagementService.validateToken(reqToken);
	}
	

}
