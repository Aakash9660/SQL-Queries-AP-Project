package com.smartdocs.controller;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.ZonedDateTime;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.JwtResponse;
import com.smartdocs.model.log.ApplicationLog;
import com.smartdocs.mongo.collectionhelpers.Permission;
import com.smartdocs.mongo.collections.User;
import com.smartdocs.mongo.repository.UserRepository;
import com.smartdocs.repository.ApplicationLogRepository;
import com.smartdocs.security.jwt.JwtProvider;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.AuthProfileService;
import com.smartdocs.service.OauthUtils;
import com.smartdocs.service.UserService;
import com.smartdocs.service.util.Constants;
import com.smartdocs.service.util.HttpReqRespUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(tags = "OauthController", value = "OauthController")
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/sso/ad")
public class OauthController {
	
	private static final Logger logger = LoggerFactory.getLogger(OauthController.class);

	public static final String API_HOST = "graph.microsoft.com/v1.0/me";
	public static final String DEFAULT_SCHEME = "https";

	@Autowired
	private UserService userService;
	
	@Autowired
	private JwtProvider jwtProvider;

	@Autowired
	private AuthProfileService authProfileService;

	
	@Value("${oauth.redirectURL}")
	private String redirectURL;
	
	@Value("${oauth.appId}")
	private String appId;
	
	@Value("${oauth.appSecreat}")
	private String appSecreat;
	
	@Autowired
	private ApplicationLogRepository authLogRepository;
	 
	@Autowired
	private UserRepository userRepository;

	  
	@GetMapping("/validate")
    @ApiOperation(notes = "This api helps in signin USING MICROSOFT SESSION", value = "let's signin")
    public ResponseEntity<?> authenticateUserMSA(HttpServletRequest request,HttpServletRequest response) throws JSONException, IOException {
		logger.info("OauthController : /sso/ad/validate -> authauthenticateUserMSA");
		//String redirectUri =redirectURL;// OauthUtils.getRedirectUri(request);
		String code = request.getParameter("code");
		String app= request.getParameter("app");
		if(StringUtils.isBlank(app)) {
			app="default";
		}
		JSONObject jsonObject = OauthUtils.getAccessToken(code,  redirectURL,appId,appSecreat);
		if (jsonObject == null)
		{
			return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"Invalid url. ",JsonResponse.STATUS_400)); 
		}
		try{
			if(jsonObject.get("access_token")==null) {
			return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"AD Sign in Failed",JsonResponse.STATUS_400)); 
			}
		}catch(JSONException ex){
			logger.error("JSONException while authenticating user MSA: {}", ex.getMessage());
			return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"AD Sign in Failed.",JsonResponse.STATUS_400)); 
		}
		String accessToken = (String) jsonObject.get("access_token");
		if (accessToken != null) {
			String mail =  getOutlookName(accessToken);
			User user = userService.getUserByEmail(mail);
			if(user!=null){
				Map<String,Permission> pg= null;
	       // 	Map<String,Permission> pg= authProfileService.getAllPermissionGroups(user);
				 if(user.getRole().equals("CompanyUser")) {
					 pg= authProfileService.getAllPermissionGroups(user);
				}
	        	UserPrincipal userPrinciple = UserPrincipal.build(user,pg);
				String jwt = jwtProvider.generateJwtTokenForMSAUser(userPrinciple,HttpReqRespUtils.getClientIpAddressIfServletRequestExist());
				logger.debug("Jwt Token generated for SSO signin");
			
				authLogRepository.save(new ApplicationLog(HttpReqRespUtils.getClientIpAddressIfServletRequestExist(),
						Constants.ACTIVITY_TYPE_USER_SIGNIN, user.getEmail(), user.getName(), null, null,
						user.getName() + " Successfully sign in ", "", "AuthRestAPIs:authenticateUserMSA()", "/sso/ad/validate",user.getRole()));
				
				user.setAccessToken(jwt);
				user.setInvalidPasswordAttempts(0);
				user.setLastLogin(ZonedDateTime.now());
				user.setLastActivity(ZonedDateTime.now());
				logger.info("Saving the user in User Repository");
				userRepository.save(user);
				 
	            return	ResponseEntity.ok(new JsonResponse(new JwtResponse(jwt,userPrinciple,JwtResponse.LOGIN_SSO),JsonResponse.RESULT_SUCCESS,JsonResponse.STATUS_200)); 
			}else{
				logger.warn("User does not exist");
				return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"User not exist into system",JsonResponse.STATUS_400)); 
			}
			
		} else {
			logger.warn("Token is null");
			return	ResponseEntity.ok(new JsonResponse(JsonResponse.RESULT_FAILED,"Invalid url",JsonResponse.STATUS_400)); 
		}
    }
	public String getOutlookName(String accessToken) throws IOException {
		logger.info("OauthController -> getOutlookName");
		String responseString = null;
		String mail = null;
		URI uri;

		try {
			uri = new URIBuilder().setScheme(DEFAULT_SCHEME).setHost(API_HOST).build();
		} catch (URISyntaxException e) {
			throw new IllegalStateException("Invalid drives path", e);
		}
		try (CloseableHttpClient httpClient = HttpClients.createDefault()) {

			HttpGet httpGet = new HttpGet(uri);
			httpGet.setHeader("Authorization", "Bearer " + accessToken);
			HttpResponse rawResponse = httpClient.execute(httpGet);

			int statusCode = rawResponse.getStatusLine().getStatusCode();
			logger.debug("Status Code: {}", statusCode);
			if (statusCode == 200) {
				HttpEntity responseEntity = rawResponse.getEntity();
				responseString = EntityUtils.toString(responseEntity);
				logger.debug("Response entity: {}", responseString);
				JSONObject objs = new JSONObject(responseString);
				mail = objs.get("mail").toString();
			}

		} catch (Exception e) {
			logger.error("Exception while getting outlook name: {}", e.getMessage());

		}
		return mail;

	}

}
