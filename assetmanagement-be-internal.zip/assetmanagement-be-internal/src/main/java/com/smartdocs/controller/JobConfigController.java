package com.smartdocs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.JobConfigModel;
import com.smartdocs.service.JobConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;


@Api(tags = "JobConfigController", value = "JobConfigController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/JobConfig")
public class JobConfigController {
	
	@Autowired
	private JobConfigService jobConfigService;
	
	@PreAuthorize("hasRole('COMPANY_USER') and (hasPermission('AP_SystemConfigurator','READ') )")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for getJobConfig ", value = "get Job Config")
	@GetMapping("/get")
	public JobConfigModel getJobConfig(){
		return jobConfigService.getJobConfig();
	}
	
	@PreAuthorize("hasRole('COMPANY_USER') and (hasPermission('AP_SystemConfigurator','EDIT') )")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for updateJobConfig ", value = "update Job Config")
	@PutMapping("/update")
	public JsonResponse updateJobConfig(@RequestBody JobConfigModel configModel){
		return jobConfigService.updateJobConfig(configModel);	 
	}

}
