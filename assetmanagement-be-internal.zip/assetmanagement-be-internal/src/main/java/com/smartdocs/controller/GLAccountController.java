package com.smartdocs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.GLAccount;
import com.smartdocs.model.dto.GLAccountDto;
import com.smartdocs.service.GLAccountService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Api(tags = "GLAccountController", value = "GLAccountController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/glAccount")
public class GLAccountController {

	@Autowired
	private GLAccountService glAccountService;

	@PreAuthorize("hasRole('COMPANY_USER') and ( hasPermission('AP_GLAccount','EDIT') )")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for create new GL Account", value = "Craete GL Account")
	@PostMapping
	public JsonResponse createGLAccount(@RequestBody GLAccount glAccount) {
		return this.glAccountService.createGLAccount(glAccount);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_GLAccount','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update GL Account", value = "Update GL Account By ID")
	@PutMapping("/{id}")
	public JsonResponse updateGLAccount(@RequestBody GLAccountDto glAccountDto, @PathVariable String id) {
		return this.glAccountService.updateGLAccount(glAccountDto, id);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get GL Account", value = "Get GL Account By ID")
	@GetMapping("/{id}")
	public GLAccount getGLAccount(@PathVariable String id) {
		return this.glAccountService.getGLAccount(id);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_GLAccount','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for delete GL Account", value = "Delete GL Account By ID")
	@DeleteMapping("/{id}")
	public JsonResponse deleteGLAccount(@PathVariable String id) {
		return this.glAccountService.deleteGLAccount(id);

	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get GL Account page", value = "Api for get GL Account page")
	@GetMapping("/page")
	public Page<GLAccount> getGLAccountPage(@RequestParam(name = "query", required = false) String query,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return this.glAccountService.getGLAccountPage(query, orderBy, page - 1, size);
	}

}
