package com.smartdocs.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.BillAmountDTO;
import com.smartdocs.dto.BillDocumentRequest;
import com.smartdocs.dto.InvoiceRequest;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.UpdateActionRequest;
import com.smartdocs.model.BillDocument;
import com.smartdocs.model.BillDocumentLog;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.BillDocumentService;
import com.smartdocs.service.MissingBillsService;
import com.smartdocs.sql.dto.BillHistoryInf;
import com.smartdocs.sql.dto.ManageBills;
import com.smartdocs.sql.dto.ManageBillsLogInf;
import com.smartdocs.sql.dto.MissingBillInf;
import com.smartdocs.sql.dto.OneYearBillInf;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "BillController", value = "BillController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/billDocument")
public class BillDocumentController {

	@Autowired
	private BillDocumentService billDocumentService;

	@Autowired
	private MissingBillsService missingBillsService;

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get BillDocument Page ", value = "Get BufferDocument page")
	@GetMapping("/page")
	public Page<com.smartdocs.model.dto.BillHistory> search(
			@RequestParam(name = "vendorQuery", required = false) String vendorQuery,
			@RequestParam(name = "assetQuey", required = false) String assetQuey,
			@RequestParam(name = "jobId", required = false) String jobId,
			@RequestParam(name = "notrequirestatus", required = false) String notrequirestatus,
			@RequestParam(name = "txId", required = false) String txId,
			@RequestParam(name = "channel", required = false) String channel,
			@RequestParam(name = "invfromDate", required = false) String invfromDate,
			@RequestParam(name = "invtoDate", required = false) String invtoDate,
			@RequestParam(name = "billfromDate", required = false) String billfromDate,
			@RequestParam(name = "billtoDate", required = false) String billtoDate,
			@RequestParam(name = "clientTz", required = false) String clientTz,
			@RequestParam(name = "invoiceNumber", required = false) String invoiceNumber,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "status", required = false) String status,
			@RequestParam(name = "billMonth", required = false) String billMonth,
			@RequestParam(name = "limit") int size) {
		return billDocumentService.search(notrequirestatus, billfromDate, billtoDate, invfromDate, clientTz, invtoDate,
				assetQuey, vendorQuery, accountNumber, jobId, txId, invoiceNumber, channel, page - 1, size, orderBy,
				status, billMonth);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get BillDocument BY vendorId ", value = "Get BillDocument Page By vendorId ")
	@GetMapping("/pageByVendorId")
	public Page<BillDocument> searchBillsByVendorId(@RequestParam(name = "vendor", required = true) String vendorId,
			@RequestParam(name = "invoiceNumber", required = false) String invoiceNumber,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "billstatus", required = false) String billstatus,
			@RequestParam(name = "fromDate", required = false) String fromDate,
			@RequestParam(name = "toDate", required = false) String toDate,
			@RequestParam(name = "billMonth", required = false) String billMonth,
			@RequestHeader(name = "tz", required = false) String clientTz, @RequestParam(name = "order") String orderBy,
			@RequestParam(name = "page") int page, @RequestParam(name = "limit") int size) {
		return billDocumentService.searchBills(assetCode, accountNumber, billstatus, billMonth, fromDate, clientTz,
				toDate, invoiceNumber, vendorId, page - 1, size, orderBy);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get BillDocuments recodrs ", value = "Get BillDocuments recodrs")
	@GetMapping("/getBills")
	public Page<BillDocument> searchBills(@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return billDocumentService.getBills(assetCode, vendorId, accountNumber, page - 1, size, orderBy);
	}

	// @NotSecuredProperly
//	@PreAuthorize("hasRole('SYSTEM_ADMIN') or hasRole('BUSINESS_ADMIN') or hasRole('COMPANY_USER')")
//	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
//	@ApiOperation(notes = "This Api for Register Invoice ", value = " Register Invoice")
	@PostMapping("/registerInvoice")
	public BillDocument registerInvoiceData(@RequestBody InvoiceRequest invoiceRequest) {
		return billDocumentService.registerInvoiceData(invoiceRequest);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Check missing bills ", value = "Check missing bills")
	@GetMapping("/testMissingBills")
	public JsonResponse test(@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNo", required = false) String accountNo,
			@RequestParam(name = "vendorId", required = false) String vendorId) {
		return missingBillsService.missingInvoicesReport(assetCode, accountNo, vendorId);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get MissingReport ", value = "Get Missing Invoice")
	@GetMapping("/missingReport")
	public Page<MissingBillInf> getMissingReport(@RequestParam(name = "status", required = false) String status,
			@RequestParam(name = "channel", required = false) String channel,
			@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "manualIntervention", required = false) Boolean manualIntervention,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "period", required = false) String period,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return missingBillsService.searchMissingBills(manualIntervention, status, page - 1, size, orderBy, assetCode,
				vendorId, channel, accountNumber, period);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for To Download MissingReport ", value = "Download MissingReport")
	@GetMapping("/missingReportDownload")
	public ResponseEntity<InputStreamResource> getMissingReportsDownload(
			@RequestParam(name = "status", required = false) String status,
			@RequestParam(name = "channel", required = false) String channel,
			@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "manualIntervention", required = false) Boolean manualIntervention,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "period", required = false) String period) throws IOException {
		ByteArrayInputStream byteInputStream = missingBillsService.getMissingBillsDownLoad(manualIntervention, status,
				assetCode, vendorId, channel, accountNumber, period);
		if (byteInputStream != null) {
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=MissingBillsReport.xlsx")
					.contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
					.body(new InputStreamResource(byteInputStream));
		}
		return null;
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update action ", value = "Update action")
	@PostMapping("/updateAction")
	public JsonResponse updateActionToChangeStatus(@RequestBody UpdateActionRequest actionRequest) {
		return missingBillsService.updateStatus(actionRequest);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update Missing bills ", value = "Update Missing bills action")
	@PostMapping("/updateMissingBills")
	public JsonResponse updateMissingBillsData(@RequestBody BillDocumentRequest actionRequest) {
		return missingBillsService.updateMissingBillsData(actionRequest);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update Missing bills ", value = "Update Missing bills action")
	@DeleteMapping("/clearRecodrsInMissingBills")
	public JsonResponse clearRecodrsInMissingBills() {
		missingBillsService.deleteAllRecords();
		return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Clear all data in Missing Bills",
				JsonResponse.STATUS_200);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get One Month Bills ", value = "Get one Month Bills")
	@GetMapping("/getMonthlyBills")
	public BillAmountDTO getPastOneMonthBills(@RequestParam(required = false) String assetCode,
			@RequestParam(required = false) String status, @RequestParam(required = false) String billMonth,
			@RequestParam(required = false) String clientTz) {
		return billDocumentService.getOneMonthBills(assetCode, status, billMonth, clientTz);
	}

	// @NotSecuredProperly
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get One Year Bills Per Month", value = "Get One Year Bills Per Month")
	@GetMapping("/getYearlyBills")
	public List<OneYearBillInf> pastOneYearBills(@RequestParam(required = false) String status) {
		return billDocumentService.pastOneYearBillsData(status);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get BillDocument Page ", value = "Get BufferDocument page")
	@PostMapping("/getAll")
	public Page<BillHistoryInf> getpage(@RequestParam(name = "vendorQuery", required = false) String vendorQuery,
			@RequestParam(name = "assetQuery", required = false) String assetQuey,
			@RequestParam(name = "jobId", required = false) String jobId,
			@RequestParam(name = "txId", required = false) String txId,
			@RequestParam(name = "utilityType", required = false) String utilityType,
			@RequestParam(name = "channel", required = false) String channel,
			@RequestParam(name = "invfromDate", required = false) String invfromDate,
			@RequestParam(name = "invtoDate", required = false) String invtoDate,
			@RequestHeader(name = "tz", required = false) String clientTz,
			@RequestBody(required = false) List<String> statuses,
			@RequestParam(name = "invoiceNumber", required = false) String invoiceNumber,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "billMonth", required = false) String billMonth,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return billDocumentService.getPage(utilityType, statuses, billMonth, invfromDate, clientTz, invtoDate,
				assetQuey, vendorQuery, accountNumber, invoiceNumber, channel, page - 1, size, orderBy);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for download BillDocument  ", value = "Download BufferDocument ")
	@PostMapping("/downloadBillDocumentsReport")
	public ResponseEntity<InputStreamResource> downloadBills(
			@RequestParam(name = "vendorQuery", required = false) String vendorQuery,
			@RequestParam(name = "assetQuery", required = false) String assetQuey,
			@RequestParam(name = "jobId", required = false) String jobId,
			@RequestParam(name = "txId", required = false) String txId,
			@RequestParam(name = "utilityType", required = false) String utilityType,
			@RequestParam(name = "channel", required = false) String channel,
			@RequestParam(name = "invfromDate", required = false) String invfromDate,
			@RequestParam(name = "invtoDate", required = false) String invtoDate,
			@RequestParam(name = "clientTz", required = false) String clientTz,
			@RequestBody(required = false) List<String> statuses,
			@RequestParam(name = "invoiceNumber", required = false) String invoiceNumber,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "billMonth", required = false) String billMonth) throws IOException {
		ByteArrayInputStream byteInputStream = billDocumentService.downloadBills(utilityType, statuses, billMonth,
				invfromDate, clientTz, invtoDate, assetQuey, vendorQuery, accountNumber, invoiceNumber, channel);
		if (byteInputStream != null) {
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Bills.xlsx")
					.contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
					.body(new InputStreamResource(byteInputStream));
		}
		return null;
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update Missing bills to Obselete ", value = "Set Missing bills to Obselete ")
	@PostMapping("/setToOboselete")
	public JsonResponse setToOboselete(@RequestBody List<String> ids, @RequestParam(required = false) String comments) {
		missingBillsService.setToObsoleteRecords(ids, comments);
		return new JsonResponse(JsonResponse.RESULT_SUCCESS, "Action Performed Successfully", JsonResponse.STATUS_200);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Manange Bills ", value = "Get Manange Bills")
	@GetMapping("/getManageBills")
	public Page<ManageBills> getManageBills(@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "frequency", required = false) String frequency,
			@RequestParam(name = "accountNumber", required = false) String accountNumber,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return billDocumentService.searchManageBills(assetCode, vendorId, accountNumber, frequency, orderBy, page - 1,
				size);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Manage Bills logs ", value = "Get Manage Bills logs")
	@GetMapping("/getManageBillsLogs")
	public List<ManageBillsLogInf> getManageBills(@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber) {
		return missingBillsService.getManageBills(assetCode, vendorId, accountNumber);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Bill logs ", value = "Get  Bills Documents logs")
	@GetMapping("/getBillsDocLogs/{id}")
	public List<BillDocumentLog> getManageBills(@PathVariable long id) {
		return billDocumentService.getBillDocLogs(id);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update action ", value = "Update action")
	@PutMapping("/updateActionOnManageBills")
	public JsonResponse updateActionOnManageBills(@RequestBody UpdateActionRequest actionRequest,
			@ApiIgnore Authentication authentication) {
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return missingBillsService.updateActionOnManageBills(actionRequest, logedInUser);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for To Download ManageBills ", value = "Download ManageBills")
	@GetMapping("/manageBillsDownload")
	public ResponseEntity<InputStreamResource> getManageDownload(
			@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "assetCode", required = false) String assetCode,
			@RequestParam(name = "accountNumber", required = false) String accountNumber) throws IOException {
		ByteArrayInputStream byteInputStream = billDocumentService.downloadManageBills(assetCode, vendorId,
				accountNumber);
		if (byteInputStream != null) {
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ManageBills.xlsx")
					.contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
					.body(new InputStreamResource(byteInputStream));
		}
		return null;
	}

}
