package com.smartdocs.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.SmartStoreConfigurator;
import com.smartdocs.model.dto.SmartStoreConfiguratorDTO;
import com.smartdocs.service.SmartStoreConfigService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@Api(tags = "SmartStoreConfigController", value = "SmartStoreConfigController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/smartStoreConfig")
public class SmartStoreConfigController {

	@Autowired
	private SmartStoreConfigService smartStoreConfigService;

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_SystemConfigurator','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "Get All Smartstore Configurations", value = "Get Application By ID")
	@GetMapping(value = "/list")
	public List<SmartStoreConfigurator> getSmartStoreConfigList(HttpServletRequest request) {
		return smartStoreConfigService.getSmartStoreConfig();
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_SystemConfigurator','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "Update Smartstore Configuration", value = "Update Smartstore Configuration")
	@PutMapping(value = "/update")
	public JsonResponse updateSmartStoreConfig(
			@RequestBody SmartStoreConfigurator smartStoreConfigurator) {
		return smartStoreConfigService.updateSmartStoreConfig(smartStoreConfigurator);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_SystemConfigurator','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "Delete Smartstore Configuration by id", value = "Delete Smartstore Configuration by id")
	@DeleteMapping(value = "/{id}")
	public JsonResponse deleteSmartStoreConfig(HttpServletRequest request, @PathVariable Long id) {
		return smartStoreConfigService.deleteSmartStoreConfig(id);
	}

	
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_SystemConfigurator','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "Add Smartstore Configuration", value = "Add Smartstore Configuration")
	@PostMapping()
	public JsonResponse addSmartStoreConfig(HttpServletRequest request,
			@RequestBody SmartStoreConfiguratorDTO smartStoreConfiguratorDTO) {
		return smartStoreConfigService.addSmartStoreConfig(smartStoreConfiguratorDTO);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_SystemConfigurator','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "Get Smartstore Configuration by id", value = "Get Smartstore Configuration by id")
	@GetMapping(value = "/get")
	public SmartStoreConfigurator getSmartStoreConfig() {
		return smartStoreConfigService.findSmartStoreConfigById();
	}
}
