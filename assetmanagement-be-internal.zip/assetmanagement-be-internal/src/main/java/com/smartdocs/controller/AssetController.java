package com.smartdocs.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartdocs.dto.AssetAccountDetails;
import com.smartdocs.dto.AssetGeoData;
import com.smartdocs.dto.AssetVendorDto;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.dto.MultipartDto;
import com.smartdocs.dto.UtilAssetDto;
import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetType;
import com.smartdocs.model.Vendor;
import com.smartdocs.model.dto.AssetDto;
import com.smartdocs.service.AssetService;
import com.smartdocs.service.GeoMapService;
import com.smartdocs.sql.dto.AssetDataInf;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import net.sf.json.JSONException;

@Api(tags = "AssetController", value = "AssetController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/asset")
public class AssetController {

	@Autowired
	private AssetService assetService;

	@Autowired
	private GeoMapService geoMapService;

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Asset','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for create new Asset", value = "Create new Asset")
	@PostMapping
	public JsonResponse createAsset(@RequestBody AssetDto assetDto) {
		return this.assetService.createAsset(assetDto);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Asset','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Update Asset", value = "Update Asset By ID")
	@PutMapping("/{id}")
	public JsonResponse updateAsset(@RequestBody AssetDto assetDto, @PathVariable Long id) {
		return this.assetService.updateAsset(assetDto, id);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Near Get Assets With in Range ", value = "Get Assets With in Range")
	@GetMapping("/geo-distance-check")
	public List<AssetGeoData> geoData(@RequestParam double reqlatitude, @RequestParam double reqlongitude,
			@RequestParam double range) {
		return geoMapService.providers(reqlatitude, reqlongitude, range);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Utility vendor ", value = "Get Utility vendor ")
	@GetMapping("/utilityVendors/code-{code}")
	public Page<AssetVendorDto> getUtilityVendor(@PathVariable String code, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size,
			@RequestParam(name = "frequency", required = false) String frequency,
			@RequestParam(name = "order", required = true) String order,
			@RequestParam(name = "channel", required = false) String channel,
			@RequestParam(name = "utilityType", required = false) String utilityType,
			@RequestParam(name = "accountNo", required = false) String accountNo,
			@RequestParam(name = "vendorId", required = false) String vendorId) {
		return assetService.getUitlityVendors(code, frequency, channel, vendorId, accountNo, utilityType, order,
				page - 1, size);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Asset and Accounts Details ", value = "Get Asset and Accounts Details")
	@GetMapping("/code-{assetCode}")
	public AssetAccountDetails test(@PathVariable String assetCode,
			@RequestParam(name = "isDetail", required = false) Boolean isDetail) {
		return assetService.findAssetCodeDetails(assetCode, isDetail);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Asset Accounts By VendorId", value = "Get Asset Account By VendorId")
	@GetMapping("/getAssetAccountDeatis/{vendorId}")
	public List<Map<String, Object>> getAssetAcountsDeatis(@PathVariable String vendorId) {
		return assetService.getAssetDetails(vendorId);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Asset','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Delete Asset", value = "Delete By ID")
	@DeleteMapping("/{id}")
	public void deleteAsset(@PathVariable Long id) {
		this.assetService.deleteAsset(id);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Asset Type Count", value = "Get Asset Type Count")
	@GetMapping("/assetTypeCount")
	public UtilAssetDto getAssetTypeCount() {
		return this.assetService.getAssetTypeCount();
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Vendors", value = "Get Vendors")
	@GetMapping("/utilityVendorsList/{assetCode}")
	public List<Vendor> getVendorsData(@PathVariable String assetCode) {
		return assetService.getVendorsFromAsset(assetCode);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get All Assets By Pagination", value = "Get Asset Page API")
	@GetMapping("/page")
	public Page<AssetDataInf> test(@RequestParam(name = "assetType", required = false) String assetType,
			@RequestParam(name = "vendorQuery", required = false) String vendorQuery,
			@RequestParam(name = "assetQuery", required = false) String assetQuery, @RequestParam(name = "order") String orderBy,
			@RequestParam(name = "page") int page, @RequestParam(name = "limit") int size) {
		return assetService.getAssetPage(vendorQuery, assetType, assetQuery, page-1, size, orderBy);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_MonitoringBot','EDIT') ")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for publishAssetByAccountIdAndAssetId", value = "publishAssetByAccountIdAndAssetId")
	@PostMapping("/publish/{assetId}/{accountId}")
	public JsonResponse publishAsset(@PathVariable String assetId, @PathVariable String accountId) {
		System.out.println("publishAsset >");

		return assetService.publishAsset(assetId, accountId);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_MonitoringBot','EDIT') ")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for unPublishAssetByAccountIdAndAssetId", value = "unPublishAssetByAccountIdAndAssetId")
	@PostMapping("/unPublish/{assetId}/{accountId}")
	public JsonResponse UnPublishAsset(@PathVariable String assetId, @PathVariable String accountId) {
		System.out.println("publishAsset >");
		String txtId = UUID.randomUUID().toString();
		return assetService.unPublishAsset(assetId, accountId, txtId);

	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Asset','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for create new Asset Type", value = "Create new AssetType")
	@PostMapping("/aasetType")
	public JsonResponse createAssetType(@RequestBody AssetType assetType) {
		return this.assetService.createAssetType(assetType);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Assettype", value = "Get  AssetType")
	@GetMapping("/aasetType/{name}")
	public JsonResponse getAssetType(@PathVariable String name) {
		return assetService.getAssetType(name);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Asset Type List", value = "Get Asset Type List")
	@GetMapping("/aasetType/list")
	public Set<String> getAssetTypeListFromAsset() {
		return assetService.getListOfAssetTypeFromAsset();
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Asset Type List", value = "Get Asset Type List")
	@GetMapping("/aasetTypes")
	public List<AssetType> getAssetTypeList() {
		return assetService.getAssetTypeList();
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get Asset Type Page", value = "Get Asset Type Page")
	@GetMapping("/aasetType/page")
	public Page<AssetType> getAssetTypePage(@RequestParam(name = "query", required = false) String query,
			@RequestParam(name = "order", required = false) String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return this.assetService.getAssetTypePage(query, page - 1, size, orderBy);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for delete Assettype", value = " delete AssetType")
	@DeleteMapping("/aasetType/{name}")
	public JsonResponse deleteAssetType(@PathVariable String name) {
		return assetService.deleteAssetType(name);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update Assettype", value = " update AssetType")
	@PutMapping("/aasetType")
	public JsonResponse updateAssetType(@RequestBody AssetType assetType) {
		return assetService.updateAssetType(assetType);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for get Assets By Asset Name or AssetCode", value = "Get Assets By Asset Name or AssetCode")
	@GetMapping("/assets/assetCodeOrAssetName")
	public Page<Asset> getAssetBills(@RequestParam(name = "query", required = false) String query,
			@RequestParam(name = "page") int page, @RequestParam(name = "limit") int size) {
		return assetService.findByAssetCodeAndAssetName(query, page - 1, size);
	}

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get AssetCode and Name By Assetcode and name", value = "Get AssetCode and Name")
	@GetMapping("/getAssetCodeAndName/{query}")
	public List<Map<String, Integer>> getAssetNameByAssetCodeOrName(@PathVariable String query) {
		return assetService.getAssetNameByAssetCodeOrName(query);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Asset','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for bulk upload asset account.", value = " Bulk Upload Asset Account")
	@PostMapping(value = "/upload-asset-account", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
	public JsonResponse uploadAssetAccount(@ModelAttribute MultipartDto data) throws IOException, JSONException {
		try {
			InputStream inputStream = data.getFile().getInputStream();
			return assetService.processAssetAccountUpload(inputStream);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new JsonResponse(JsonResponse.RESULT_FAILED, "Uploaded File Invalid", JsonResponse.STATUS_500);
	}

}