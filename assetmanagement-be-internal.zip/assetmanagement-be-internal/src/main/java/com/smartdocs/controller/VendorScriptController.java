package com.smartdocs.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.smartdocs.dto.JsonResponse;
import com.smartdocs.model.VendorScript;
import com.smartdocs.model.VendorScriptLog;
import com.smartdocs.model.dto.VendorScriptDto;
import com.smartdocs.security.service.UserPrincipal;
import com.smartdocs.service.VendorScriptService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;

@Api(tags = "VendorScriptController", value = "VendorScriptController")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/vendorScript")
public class VendorScriptController {

	@Autowired
	private VendorScriptService vendorScriptService;
	
	final static Logger logger = LoggerFactory.getLogger(VendorScriptController.class);
	
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vendor','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for upload file of Vendor", value = "Upload file of Vendor")
	@PostMapping(value = "/upload/{vendorId}")
	public JsonResponse createVendor(@ApiIgnore Authentication authentication,@PathVariable String vendorId, HttpServletRequest request,
			@RequestParam(required = false) MultipartFile file, HttpServletResponse response) {
		logger.info("uploading vendor script");
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return this.vendorScriptService.uploadVendorFile(logedInUser,vendorId, file);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vendor','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for create new Vendor", value = "Create new Vendor")
	@PostMapping
	public VendorScript create(@ApiIgnore Authentication authentication, @RequestBody VendorScript vendorScript) {
		logger.info("create vendor script");
		UserPrincipal logedInUser = (UserPrincipal) authentication.getPrincipal();
		return this.vendorScriptService.createVendorScript(logedInUser,vendorScript);
	}

	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vendor','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for update  VendorScript", value = "Update VendorScript")
	@PutMapping("/{id}")
	public JsonResponse updateVendorScript(@ApiIgnore Authentication authentication,@RequestBody VendorScriptDto vendorScriptDto, @PathVariable Long id) {
		return this.vendorScriptService.updateVendorScript(vendorScriptDto, id);
	}

	
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vendor','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for Get VendorScript", value = "Get VendorScript")
	@GetMapping("/{vendorId}")
	public VendorScript getvendorScript(@ApiIgnore Authentication authentication, @PathVariable String vendorId) {
		return this.vendorScriptService.getVendorScript(vendorId);
	}
	
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vendor','READ')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for delete VendorScript", value = "Delete VendorScript")
	@DeleteMapping("/{id}")
	public JsonResponse deleteVendorScript(@ApiIgnore Authentication authentication,@PathVariable long id) {
		 return vendorScriptService.deleteVendorScript(id);
	}
	
	
	@PreAuthorize("hasRole('COMPANY_USER') and hasPermission('AP_Vendor','EDIT')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api for rePublish the bots", value = "rePublish the bots")
	@PostMapping("/rePublish/{vendorId}")
	public JsonResponse rePublishBot(@PathVariable String vendorId) {
		System.out.println("Republish >");
		//TODO: Log vendor script republish. 
		return vendorScriptService.rePublishVendoScriptOnAllServers(vendorId);
	}
	

	@PreAuthorize("hasRole('COMPANY_USER')")
	@ApiImplicitParam(name = "Authorization", value = "Access Token", required = true, allowEmptyValue = false, paramType = "header", example = "Bearer access_token")
	@ApiOperation(notes = "This Api to get  VendorScript log in page", value = "This Api to  get  VendorScript log in page")
	@GetMapping("/vendorScriptLogPage")
	public Page<VendorScriptLog> FindvendorScriptLogPage(
			@RequestParam(name = "vendorId", required = false) String vendorId,
			@RequestParam(name = "order") String orderBy, @RequestParam(name = "page") int page,
			@RequestParam(name = "limit") int size) {
		return vendorScriptService.vendorscriptlogs(orderBy, page-1, size, vendorId);
	}


}
