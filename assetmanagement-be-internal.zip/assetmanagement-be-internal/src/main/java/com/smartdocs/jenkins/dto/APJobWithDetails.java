package com.smartdocs.jenkins.dto;

import java.util.List;

import lombok.Data;
 
@Data
public class APJobWithDetails {
	
	public static final String SERVER1="server1";
	public static final String SERVER2="server2";

	private String name;
    private String url;
    private String fullName;


    private String description;

    private String displayName;

    private boolean buildable;

    private List<APBuild> builds;

    private APBuild firstBuild;

    private APBuild lastBuild;

    private APBuild lastCompletedBuild;

    private APBuild lastFailedBuild;

    private APBuild lastStableBuild;

    private APBuild lastSuccessfulBuild;

    private APBuild lastUnstableBuild;

    private APBuild lastUnsuccessfulBuild;

    private int nextBuildNumber;

    private boolean inQueue;

    private APQueueItem queueItem;

    private List<APJob> downstreamProjects;

    private List<APJob> upstreamProjects;
}
