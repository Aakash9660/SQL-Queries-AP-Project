package com.smartdocs.jenkins.dto;

import lombok.Data;

@Data
public class APJob {

	private String name;
	private String url;
	private String fullName;
}
