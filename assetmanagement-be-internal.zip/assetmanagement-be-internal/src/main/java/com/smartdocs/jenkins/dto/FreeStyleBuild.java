package com.smartdocs.jenkins.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class FreeStyleBuild {

	private String _class;
	private String id;
	private boolean building;
	private long duration;
	private long estimatedDuration;
	private boolean inProgress;
	private boolean keepLog;
	private long number;
	private long queueId;
	private String result;
	private long timestamp;
	private String url;
    
	
}
