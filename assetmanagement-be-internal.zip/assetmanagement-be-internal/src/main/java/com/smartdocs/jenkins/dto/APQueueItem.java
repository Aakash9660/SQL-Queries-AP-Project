package com.smartdocs.jenkins.dto;

import lombok.Data;

 
@Data
public class APQueueItem {

	//private List<QueueItemActions> actions;

    private boolean blocked;

    private boolean buildable;

    private Long id;

    private Long inQueueSince;

    private String params;

    private boolean stuck;

    //private QueueTask task;

    private String url;

    private String why;

    private boolean cancelled;

  //  private Executable executable;

}
