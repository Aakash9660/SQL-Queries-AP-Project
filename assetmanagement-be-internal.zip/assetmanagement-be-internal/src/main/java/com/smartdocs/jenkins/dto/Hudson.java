package com.smartdocs.jenkins.dto;

import java.util.List;

import lombok.Data;
import lombok.ToString;
@Data
@ToString
public class Hudson {
	
	private String _class;
	private List<FreeStyleProject> jobs;
}
