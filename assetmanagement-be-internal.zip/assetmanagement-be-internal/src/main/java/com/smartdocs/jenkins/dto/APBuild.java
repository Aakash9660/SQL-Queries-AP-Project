package com.smartdocs.jenkins.dto;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class APBuild {

    private int number;
    private int queueId;
    private String url;
    private Timestamp timeStamp;
    private String status;
}
