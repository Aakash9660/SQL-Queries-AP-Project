package com.smartdocs.mongo.repository;


import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.mongo.collections.PermissionGroup;


@Repository
public interface AuthProfileRepository extends MongoRepository<PermissionGroup, String>{

	public  PermissionGroup findByGroupId(String groupId);
	public  List<PermissionGroup> findByGroupIdIn(List<String> groupId);
	 
}
