package com.smartdocs.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "exceptionLog")
public class ExceptionLog {

	
	@Id
	private String id;
	
	private String ip;
	
	private ZonedDateTime dateTime;
	
	private String type;
	
	private String uri;
	
	private String title; 
	
	private String txId;
	
	private String  errorCode;
	
	public ExceptionLog() {
		super();
		this.dateTime=ZonedDateTime.now();
	}
	public String getId() {
		return id;
	}

	public String getIp() {
		return ip;
	}

	public ZonedDateTime getDateTime() {
		return dateTime;
	}

	public String getType() {
		return type;
	}

	public String getUri() {
		return uri;
	}

	public String getTitle() {
		return title;
	}

	public String getTxId() {
		return txId;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setTxId(String txId) {
		this.txId = txId;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	
	
	
}
