package com.smartdocs.mongo.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.smartdocs.mongo.collections.PermissionGroup;

@Repository
public class PermissionGroupDao {

	@Autowired 
	private MongoTemplate mongoOperation;
	
	
	public List<PermissionGroup> findReadPermissions(String permission) {
		
		Query query = new Query();      
		query.addCriteria(Criteria.where("permissions").elemMatch(Criteria.where("name").is(permission).and("enabled").is(true)));
		return mongoOperation.find(query, PermissionGroup.class);
	}
	public List<PermissionGroup> findEditPermissions(String permission) {

		Query query = new Query();      
		query.addCriteria(Criteria.where("permissions").elemMatch(Criteria.where("name").is(permission).and("edit").is(true)));
		return mongoOperation.find(query, PermissionGroup.class);
	}
}
