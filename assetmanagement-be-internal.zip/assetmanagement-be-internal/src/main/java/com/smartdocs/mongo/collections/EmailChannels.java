package com.smartdocs.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "emailChannel")
public class EmailChannels {

	public static final String REQTYPESUBJECT = "subject";
	public static final String AUTH_TYPE_OAUTH = "oauth";
	public static final String AUTH_TYPE_BASIC = "basic";

	public static final String AUTH_TYPE_OAUTH_GRAPH = "oauth_graph";

	@Id
	private String id;

	private String imapHost;
	private int imapPort;
	private String username;
	private String password;
	private String mailStoreProtocol;
	private String securedConnection;

	private String smtpPort;
	private String auth;
	private boolean starttls;
	private String smtpHost;

	private boolean enabled;

	private boolean ocrEnabled;
	private String ocrProfile;
	private String ocrMappingProfile;
	private List<String> supportedFileTypes;

	private String ignoredFolderId;
	private String processedFolderId;
	private String ignoredEmailFolder;
	private String processedEmailFolder;

	// max file size in MB
	private int maxFileSize;

	private String sendDailyReportTo;

	private boolean autoReply;
	private boolean npoLines;
	private String authType;
	private long expires_in;
	private String access_token;
	private String refresh_token;
	private String redirectURI;
	private ZonedDateTime lastUpdated;

	private String npoInvoiceType;
	private String poInvoiceType;
	private List<DataField> fieldsConfig;
	private boolean utility;
	private String channel;
	private String channelCode;

	public EmailChannels() {
		super();
	}

	public String getImapHost() {
		return imapHost;
	}

	public void setImapHost(String imapHost) {
		this.imapHost = imapHost;
	}

	public int getImapPort() {
		return imapPort;
	}

	public void setImapPort(int imapPort) {
		this.imapPort = imapPort;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMailStoreProtocol() {
		return mailStoreProtocol;
	}

	public void setMailStoreProtocol(String mailStoreProtocol) {
		this.mailStoreProtocol = mailStoreProtocol;
	}

	public String getSecuredConnection() {
		return securedConnection;
	}

	public void setSecuredConnection(String securedConnection) {
		this.securedConnection = securedConnection;
	}

	public String getSmtpPort() {
		return smtpPort;
	}

	public void setSmtpPort(String smtpPort) {
		this.smtpPort = smtpPort;
	}

	public String getAuth() {
		return auth;
	}

	public void setAuth(String auth) {
		this.auth = auth;
	}

	public boolean isStarttls() {
		return starttls;
	}

	public void setStarttls(boolean starttls) {
		this.starttls = starttls;
	}

	public String getSmtpHost() {
		return smtpHost;
	}

	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isOcrEnabled() {
		return ocrEnabled;
	}

	public void setOcrEnabled(boolean ocrEnabled) {
		this.ocrEnabled = ocrEnabled;
	}

	public List<DataField> getFieldsConfig() {
		return fieldsConfig;
	}

	public void setFieldsConfig(List<DataField> fieldsConfig) {
		this.fieldsConfig = fieldsConfig;
	}

	public List<String> getSupportedFileTypes() {
		return supportedFileTypes;
	}

	public void setSupportedFileTypes(List<String> supportedFileTypes) {
		this.supportedFileTypes = supportedFileTypes;
	}

	public int getMaxFileSize() {
		return maxFileSize;
	}

	public void setMaxFileSize(int maxFileSize) {
		this.maxFileSize = maxFileSize;
	}

	public boolean isAutoReply() {
		return autoReply;
	}

	public void setAutoReply(boolean autoReply) {
		this.autoReply = autoReply;
	}

	public boolean isNpoLines() {
		return npoLines;
	}

	public void setNpoLines(boolean npoLines) {
		this.npoLines = npoLines;
	}

	public String getNpoInvoiceType() {
		return npoInvoiceType;
	}

	public void setNpoInvoiceType(String npoInvoiceType) {
		this.npoInvoiceType = npoInvoiceType;
	}

	public String getPoInvoiceType() {
		return poInvoiceType;
	}

	public void setPoInvoiceType(String poInvoiceType) {
		this.poInvoiceType = poInvoiceType;
	}

	public String getOcrProfile() {
		return ocrProfile;
	}

	public void setOcrProfile(String ocrProfile) {
		this.ocrProfile = ocrProfile;
	}

	public long getExpires_in() {
		return expires_in;
	}

	public void setExpires_in(long expires_in) {
		this.expires_in = expires_in;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getRefresh_token() {
		return refresh_token;
	}

	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}

	public String getRedirectURI() {
		return redirectURI;
	}

	public void setRedirectURI(String redirectURI) {
		this.redirectURI = redirectURI;
	}

	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public String getAuthType() {
		return authType;
	}

	public void setAuthType(String authType) {
		this.authType = authType;
	}

	public String getSendDailyReportTo() {
		return sendDailyReportTo;
	}

	public void setSendDailyReportTo(String sendDailyReportTo) {
		this.sendDailyReportTo = sendDailyReportTo;
	}

	public String getIgnoredFolderId() {
		return ignoredFolderId;
	}

	public void setIgnoredFolderId(String ignoredFolderId) {
		this.ignoredFolderId = ignoredFolderId;
	}

	public String getProcessedFolderId() {
		return processedFolderId;
	}

	public void setProcessedFolderId(String processedFolderId) {
		this.processedFolderId = processedFolderId;
	}

	public String getIgnoredEmailFolder() {
		return ignoredEmailFolder;
	}

	public void setIgnoredEmailFolder(String ignoredEmailFolder) {
		this.ignoredEmailFolder = ignoredEmailFolder;
	}

	public String getProcessedEmailFolder() {
		return processedEmailFolder;
	}

	public void setProcessedEmailFolder(String processedEmailFolder) {
		this.processedEmailFolder = processedEmailFolder;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getOcrMappingProfile() {
		return ocrMappingProfile;
	}

	public void setOcrMappingProfile(String ocrMappingProfile) {
		this.ocrMappingProfile = ocrMappingProfile;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public boolean isUtility() {
		return utility;
	}

	public void setUtility(boolean utility) {
		this.utility = utility;
	}
	
}
