package com.smartdocs.mongo.collections;

import java.time.ZonedDateTime;

import org.apache.commons.lang3.StringUtils;

import com.smartdocs.model.BillDocument;

public class DocumentHelper {
	
	public static final int USR_UPLOADED_VENDOR=0;
	public static final int USR_UPLOADED_COMPANY=1;
	public static final int USR_UPLOADED_SAP=2;

	private String documentid;
	private String filename;
	private String filetype;
	private String attid;
	private String arid;
	private String upload;

	private String creator;
	
	private String uploadedBy;
	
	// -1 for non system user, 
	// 0 for vendor 
	// 1 for  company user 
	// 2 for sap
	private int usrUploaded;
	private ZonedDateTime uploadedDate;
	
	private String documentType;
	private ZonedDateTime validFromDate;
	private ZonedDateTime expiryDate;
	
	private Integer versionNo;
	private String versionType;

	private boolean restricted;
	
	private boolean primaryDoc;
	
	public DocumentHelper() {
		super();
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getFiletype() {
		return filetype;
	}
	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
	public String getDocumentid() {
		return documentid;
	}
	public void setDocumentid(String documentid) {
		this.documentid = documentid;
	}
	public String getArid() {
		return arid;
	}

	public void setArid(String arid) {
		this.arid = arid;
	}

	public String getAttid() {
		return attid;
	}

	public void setAttid(String attid) {
		this.attid = attid;
	}

	public String getUpload() {
		return upload;
	}

	public void setUpload(String upload) {
		this.upload = upload;
	}
	
	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}
    
 
	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public ZonedDateTime getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(ZonedDateTime expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Integer getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(Integer versionNo) {
		this.versionNo = versionNo;
	}
	public void setVersionNo(String versionNo) {
		try {
			if(StringUtils.isNotBlank(versionNo)) {
				this.versionNo = Integer.valueOf(versionNo);
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	public String getVersionType() {
		return versionType;
	}

	public void setVersionType(String versionType) {
		this.versionType = versionType;
	}

	public boolean isRestricted() {
		return restricted;
	}

	public void setRestricted(boolean restricted) {
		this.restricted = restricted;
	}

	public ZonedDateTime getValidFromDate() {
		return validFromDate;
	}

	public void setValidFromDate(ZonedDateTime validFromDate) {
		this.validFromDate = validFromDate;
	}

	public String getUploadedBy() {
		return uploadedBy;
	}

	public ZonedDateTime getUploadedDate() {
		return uploadedDate;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	public void setUploadedDate(ZonedDateTime uploadedDate) {
		this.uploadedDate = uploadedDate;
	}

	public int getUsrUploaded() {
		return usrUploaded;
	}

	public void setUsrUploaded(int usrUploaded) {
		this.usrUploaded = usrUploaded;
	}

	public boolean isPrimaryDoc() {
		return primaryDoc;
	}

	public void setPrimaryDoc(boolean primaryDoc) {
		this.primaryDoc = primaryDoc;
	}

	public DocumentHelper(BillDocument billDocument) {
		super();
		this.documentid = billDocument.getDocid();
		this.filename = billDocument.getFilename();
		this.filetype = billDocument.getFiletype();
		this.attid = billDocument.getAttid();
		this.arid = billDocument.getArid();
		this.uploadedBy =billDocument.getUploadedBy();
		this.uploadedDate = billDocument.getUploadedDate();
	}
	
}

