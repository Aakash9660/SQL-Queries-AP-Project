package com.smartdocs.mongo.collectionhelpers;

import com.smartdocs.dto.CustomDto;

public class UtilityInvoiceData {

	private String accountNo;
	private String assetCode;
	private Long assetId;
	private String  assetName;
	private String utilityType;
	

	public UtilityInvoiceData() 
	{
		super();
	}
	
	public UtilityInvoiceData(CustomDto dto) 
	{
		super();
		this.accountNo=dto.getAccountNo();
		this.assetCode=dto.getAssetCode();
		this.assetName=dto.getAssetName();
		this.assetId=dto.getAssetId();
		this.utilityType=dto.getUtilityType();
	}
	
	public UtilityInvoiceData(String accountNo, String assetCode, Long assetId, String assetName) {
		super();
		this.accountNo = accountNo;
		this.assetCode = assetCode;
		this.assetId = assetId;
		this.assetName = assetName;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAssetCode() {
		return assetCode;
	}
	public void setAssetCode(String assetCode) {
		this.assetCode = assetCode;
	}
	public Long getAssetId() {
		return assetId;
	}
	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	
	public String getUtilityType() {
		return utilityType;
	}

	public void setUtilityType(String utilityType) {
		this.utilityType = utilityType;
	}
	
	
	
}
