package com.smartdocs.mongo.collections;
import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.smartdocs.mongo.collectionhelpers.UtilityInvoiceData;


@Document(collection = "InvoiceBuffer")
public class InvoiceBuffer {

	public static final String STATUS_JUNK="JUNK";
	public static final String STATUS_OCR="OCR";
	public static final String STATUS_NEW="NEW";
	public static final String STATUS_PROCEED="PROCESSED";
	public static final String STATUS_RE_PROCEED="REPROCESSED";
	public static final String STATUS_REJECTED="REJECTED";
	public static final String STATUS_INIT = "INIT";
	
	@Id
	private String id;

	private String logicalSystem;
	private String clientId;
	private String sspInvoiceReferenceNo;
	private String category;
	// sender email.
	private String fromEmail;
	private String subject;
	private String channelEmail;
	private String status;
	private int totalAttachments;
	private ZonedDateTime receivedDate;
	private DocumentHelper email;
	private String invoiceDocId;
	private List<DocumentHelper> attachments;
	private String title;
	private String jobId;
	private String txDocId;
	private String groupId;
	private String abbyAuth;
	private String abbyBatchId;
	private String abbySessionId;
	
	private String invoiceNumber;
	private String companyCode;
	private String supplierId;
	private String supplier;
	private String gstNumber;
	private ZonedDateTime invoiceDate;
	private ZonedDateTime dueDate;
	private ZonedDateTime createdDate;
	private ZonedDateTime supplyDate;
	private boolean creditMemo;
	private String currency;

	private float taxPercent; 
	//calculated
	private double subTotal;
	// editable.
	private double discount;
	
	
	// editable
	private double taxAmount;
	// editable
	private double freightAmount;
	// calculated
	private double totalAmount;
	// input
	private double totalInvoiceAmount;
	
	private String dateOfIncident;
	private String turnpikeEvent;
	private String comments;
	 
	 
	private String paymentterms;
	private String freightCarrier;
	private String poNumber;
	private String poDescription;

	private String invoiceCategory;

	private String invoiceType;
	private String creator;
	private String channel;
	
	private String requestor;
	private String requestorEmail;
	private String notes;
	
	private String ocrXML;
	private String rejectionReason;
	
	private boolean editable;
	
	private String description;
	private String position;
	
	private double invoiceTotalAmount;
	private String name;
	
	private String ocrInvoiceType;
	private String datesOfService;
	
	private String ocrBatchSeqNo;
	private String technicalEmailId;
	
	private String emlHtmlData;
	
	private String ocrProfile;
	private String ocrMappingProfile;
	private String glAccount;
	private String costCenter;
	private boolean utility;
	private String accountNo;
	private UtilityInvoiceData utilityData;
	

	public InvoiceBuffer() {
		super();
	}

	public InvoiceBuffer(String fromEmail, String subject, String channelEmail, String status, int totalAttachments,
			 List<DocumentHelper> attachments, String title, String jobId, String txDocId,
			String channel) {
		super();
		this.fromEmail = fromEmail;
		this.subject = subject;
		this.channelEmail = channelEmail;
		this.status = status;
		this.totalAttachments = totalAttachments;
		this.receivedDate = ZonedDateTime.now();
		this.attachments = attachments;
		this.title = title;
		this.jobId = jobId;
		this.txDocId = txDocId;
		this.channel = channel;
	
	}
	
	public InvoiceBuffer(String fromEmail,  String channelEmail, String status, int totalAttachments,
			List<DocumentHelper> docs, String txDocId, 
			String channel, String ocrMappProf, String ocrProf) {
		super();
		this.fromEmail = fromEmail;
		this.channelEmail = channelEmail;
		this.status = status;
		this.totalAttachments = totalAttachments;
		this.attachments = docs;
		this.receivedDate = ZonedDateTime.now();
		this.txDocId = txDocId;
		this.channel = channel;
		this.ocrMappingProfile = ocrMappProf;
		this.ocrProfile = ocrProf;
		 
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getChannelEmail() {
		return channelEmail;
	}

	public void setChannelEmail(String channelEmail) {
		this.channelEmail = channelEmail;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTotalAttachments() {
		return totalAttachments;
	}

	public void setTotalAttachments(int totalAttachments) {
		this.totalAttachments = totalAttachments;
	}

	public ZonedDateTime getReceivedDate() {
		return receivedDate;
	}

	public void setReceivedDate(ZonedDateTime receivedDate) {
		this.receivedDate = receivedDate;
	}
	public List<DocumentHelper> getAttachments() {
		return attachments;
	}

	public void setAttachments(List<DocumentHelper> attachments) {
		this.attachments = attachments;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getTxDocId() {
		return txDocId;
	}

	public void setTxDocId(String txDocId) {
		this.txDocId = txDocId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public ZonedDateTime getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(ZonedDateTime invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public ZonedDateTime getDueDate() {
		return dueDate;
	}

	public void setDueDate(ZonedDateTime dueDate) {
		this.dueDate = dueDate;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public ZonedDateTime getSupplyDate() {
		return supplyDate;
	}

	public void setSupplyDate(ZonedDateTime supplyDate) {
		this.supplyDate = supplyDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	 
	public String getPaymentterms() {
		return paymentterms;
	}

	public void setPaymentterms(String paymentterms) {
		this.paymentterms = paymentterms;
	}

	public String getFreightCarrier() {
		return freightCarrier;
	}

	public void setFreightCarrier(String freightCarrier) {
		this.freightCarrier = freightCarrier;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getPoDescription() {
		return poDescription;
	}

	public void setPoDescription(String poDescription) {
		this.poDescription = poDescription;
	}

	public String getInvoiceCategory() {
		return invoiceCategory;
	}

	public void setInvoiceCategory(String invoiceCategory) {
		this.invoiceCategory = invoiceCategory;
	}

	public String getInvoiceType() {
		return invoiceType;
	}

	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getNotes() {
		return notes;
	}


	public void setNotes(String notes) {
		this.notes = notes;
	}

	public DocumentHelper getEmail() {
		return email;
	}

	public void setEmail(DocumentHelper email) {
		this.email = email;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public String getRequestorEmail() {
		return requestorEmail;
	}

	public void setRequestorEmail(String requestorEmail) {
		this.requestorEmail = requestorEmail;
	}

	public String getInvoiceDocId() {
		return invoiceDocId;
	}

	public void setInvoiceDocId(String invoiceDocId) {
		this.invoiceDocId = invoiceDocId;
	}
 
	public String getOcrXML() {
		return ocrXML;
	}

	public void setOcrXML(String ocrXML) {
		this.ocrXML = ocrXML;
	}


	public String getRejectionReason() {
		return rejectionReason;
	}

	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}

	public boolean isEditable() {
		return editable;
	}

	public void setEditable(boolean editable) {
		this.editable = editable;
	}

 
	
	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getNetAmount() {
		return this.subTotal-discount;
	}


	public double getTotalAmount() {
		return totalAmount;
	}
	public double getTotalInvoiceAmount() {
		return totalInvoiceAmount;
	}

	public void setTotalInvoiceAmount(double totalInvoiceAmount) {
		this.totalInvoiceAmount = totalInvoiceAmount;
	}

	 
	private void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public void setFreightAmount(double freightAmount) {
		this.freightAmount = freightAmount;
	}
	
	
	public Double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}
	
	public Double getFreightAmount() {
		return freightAmount;
	}

	public Float getTaxPercent() {
		return taxPercent;
	}

	public void setTaxPercent(Float taxPercent) {
		this.taxPercent = taxPercent;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setTaxPercent(float taxPercent) {
		this.taxPercent = taxPercent;
	}

	public String getAbbyAuth() {
		return abbyAuth;
	}

	public void setAbbyAuth(String abbyAuth) {
		this.abbyAuth = abbyAuth;
	}

	public String getAbbyBatchId() {
		return abbyBatchId;
	}

	public void setAbbyBatchId(String abbyBatchId) {
		this.abbyBatchId = abbyBatchId;
	}

	public String getAbbySessionId() {
		return abbySessionId;
	}

	public void setAbbySessionId(String abbySessionId) {
		this.abbySessionId = abbySessionId;
	}

	public boolean isCreditMemo() {
		return creditMemo;
	}

	public void setCreditMemo(boolean creditMemo) {
		this.creditMemo = creditMemo;
	}

	public String getLogicalSystem() {
		return logicalSystem;
	}

	public void setLogicalSystem(String logicalSystem) {
		this.logicalSystem = logicalSystem;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getGstNumber() {
		return gstNumber;
	}

	public void setGstNumber(String gstNumber) {
		this.gstNumber = gstNumber;
	}

	
	public String getDateOfIncident() {
		return dateOfIncident;
	}

	public void setDateOfIncident(String dateOfIncident) {
		this.dateOfIncident = dateOfIncident;
	}

	public String getDatesOfService() {
		return datesOfService;
	}

	public void setDatesOfService(String datesOfService) {
		this.datesOfService = datesOfService;
	}

	public String getTurnpikeEvent() {
		return turnpikeEvent;
	}

	public void setTurnpikeEvent(String turnpikeEvent) {
		this.turnpikeEvent = turnpikeEvent;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public double getInvoiceTotalAmount() {
		return invoiceTotalAmount;
	}

	public void setInvoiceTotalAmount(double invoiceTotalAmount) {
		this.invoiceTotalAmount = invoiceTotalAmount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSspInvoiceReferenceNo() {
		return sspInvoiceReferenceNo;
	}

	public void setSspInvoiceReferenceNo(String sspInvoiceReferenceNo) {
		this.sspInvoiceReferenceNo = sspInvoiceReferenceNo;
	}

	public String getOcrInvoiceType() {
		return ocrInvoiceType;
	}

	public void setOcrInvoiceType(String ocrInvoiceType) {
		this.ocrInvoiceType = ocrInvoiceType;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getOcrBatchSeqNo() {
		return ocrBatchSeqNo;
	}

	public void setOcrBatchSeqNo(String ocrBatchSeqNo) {
		this.ocrBatchSeqNo = ocrBatchSeqNo;
	}

	public String getTechnicalEmailId() {
		return technicalEmailId;
	}

	public void setTechnicalEmailId(String technicalEmailId) {
		this.technicalEmailId = technicalEmailId;
	}

	public String getEmlHtmlData() {
		return emlHtmlData;
	}

	public void setEmlHtmlData(String emlHtmlData) {
		this.emlHtmlData = emlHtmlData;
	}

	public String getOcrProfile() {
		return ocrProfile;
	}

	public void setOcrProfile(String ocrProfile) {
		this.ocrProfile = ocrProfile;
	}

	public String getOcrMappingProfile() {
		return ocrMappingProfile;
	}

	public void setOcrMappingProfile(String ocrMappingProfile) {
		this.ocrMappingProfile = ocrMappingProfile;
	}

	public String getGlAccount() {
		return glAccount;
	}

	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}

	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

	public boolean isUtility() {
		return utility;
	}

	public void setUtility(boolean utility) {
		this.utility = utility;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}


	public UtilityInvoiceData getUtilityData() {
		return utilityData;
	}

	public void setUtilityData(UtilityInvoiceData utilityData) {
		this.utilityData = utilityData;
	}
}
