package com.smartdocs.mongo.collections;


public class DataField {
	
	public static final  String TYPE_FIXED="fixed";
	public static final  String TYPE_REGEX="regex";
	
	public static final  String SCOPE_SUBJECT="subject";
	public static final  String SCOPE_BODY="body";
	public static final  String SCOPE_FROMEMAIL="fromEmail";
	
	private String field;
	private String type;
	private String value;
	
	private String scope;
	private String regex;
	
	
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public String getRegex() {
		return regex;
	}
	public void setRegex(String regex) {
		this.regex = regex;
	}
	
	
	
}
