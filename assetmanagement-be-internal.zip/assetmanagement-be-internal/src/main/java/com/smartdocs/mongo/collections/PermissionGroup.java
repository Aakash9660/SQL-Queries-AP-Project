package com.smartdocs.mongo.collections;


import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.smartdocs.mongo.collectionhelpers.Permission;


@Document(collection = "permissionGroup")
public class PermissionGroup {

	public static final String  READ="READ";
	public static final String  UPDATE="UPDATE";
	public static final String  DELETE="DELETE";
	public static final String  CREATE="CREATE";
	public static final String  APPROVE="APPROVE";
	
	
	@Id
	private String groupId;
	private String name;
	private List<Permission> permissions;
	 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Permission> getPermissions() {
		return permissions;
	}
	public void setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public PermissionGroup() {
		super();
	}
	
	

}
