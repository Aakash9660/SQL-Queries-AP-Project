package com.smartdocs.mongo.collections;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "emails")
public class Emails {

	public static final String STATUS_NOT_SEND_GRID = "savedOnly";
	public static final String STATUS_SEND_TO_SEND_GRID = "sentFromPortal";

	public static final String SYSTEM_PORTAL = "portal";
	public static final String SYSTEM_PORTAL_SAPAPI = "portal api";

	@Id
	private String id;
	private String subject;
	private String type;
	private String to;
	private List<String> toRecipients;
	private String cc;
	private List<String> ccRecipients;
	private String body;
	private ZonedDateTime dateTime;
	private String status;
	private String templateId;
	private String system;
	private String archiveId;
	private String archiveDocId;
	private String responseCode;
	private String responseText;
	private String  messageId;
	private String fromEmail;
	
	private String engine;
	
	private Map<String,String> data;
	private String refId;

	private int retryTime;
	private boolean emailSent;
	private ZonedDateTime createdDate;
	
	public Emails() {
		super();
		this.system = SYSTEM_PORTAL;
	}
	 

 

	 
	public Emails(String subject, String type,String fromEmail, List<String> toRecipients, List<String> ccRecipients, String body,
			 String templateId, String system, Map<String,String> data) {
		super();
		this.subject = subject;
		this.type = type;
		this.toRecipients = toRecipients;
		this.ccRecipients = ccRecipients;
		this.body = body;
		this.createdDate = ZonedDateTime.now();
		this.system = SYSTEM_PORTAL;
		this.data=data;
		this.status = STATUS_NOT_SEND_GRID;
		this.templateId = templateId;
		this.system = system;
		this.fromEmail=fromEmail;
		
	}
	 

	public Emails(String subject, String type,String fromEmail, List<String> toRecipients, List<String> ccRecipients, String body,
			boolean sendEmail, String templateId, String system,Map<String,String> data) {
		super();
		this.subject = subject;
		this.type = type;
		this.toRecipients = toRecipients;
		this.ccRecipients = ccRecipients;
		this.body = body;
		this.createdDate = ZonedDateTime.now();
		this.system = SYSTEM_PORTAL;
		this.data=data;
		if (sendEmail) {
			this.status = STATUS_SEND_TO_SEND_GRID;
		} else {
			this.status = STATUS_NOT_SEND_GRID;
			this.templateId = templateId;
			this.system = system;
		}
		this.fromEmail=fromEmail;
	}

	public String getStatus() {
		return status;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public ZonedDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(ZonedDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public List<String> getToRecipients() {
		return toRecipients;
	}

	public void setToRecipients(List<String> toRecipients) {
		this.toRecipients = toRecipients;
	}

	public List<String> getCcRecipients() {
		return ccRecipients;
	}

	public void setCcRecipients(List<String> ccRecipients) {
		this.ccRecipients = ccRecipients;
	}

	public String getArchiveId() {
		return archiveId;
	}

	public void setArchiveId(String archiveId) {
		this.archiveId = archiveId;
	}

	public String getArchiveDocId() {
		return archiveDocId;
	}

	public void setArchiveDocId(String archiveDocId) {
		this.archiveDocId = archiveDocId;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseText() {
		return responseText;
	}

	public void setResponseText(String responseText) {
		this.responseText = responseText;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public Map<String, String> getData() {
		return data;
	}

	public void setData(Map<String, String> data) {
		this.data = data;
	}

	public String getEngine() {
		return engine;
	}

	public void setEngine(String engine) {
		this.engine = engine;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public int getRetryTime() {
		return retryTime;
	}

	public void setRetryTime(int retryTime) {
		this.retryTime = retryTime;
	}

	public boolean isEmailSent() {
		return emailSent;
	}

	public void setEmailSent(boolean emailSent) {
		this.emailSent = emailSent;
	}

	public ZonedDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(ZonedDateTime createdDate) {
		this.createdDate = createdDate;
	}





	public String getFromEmail() {
		return fromEmail;
	}





	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}
	
	

}
