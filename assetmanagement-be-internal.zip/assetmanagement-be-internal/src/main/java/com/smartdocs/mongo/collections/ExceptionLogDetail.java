package com.smartdocs.mongo.collections;

import java.time.ZonedDateTime;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "exceptionLogDetail")
public class ExceptionLogDetail {

	private String txId;
	private String requestBody;
	private String errorLog;
	private ZonedDateTime lastUpdated;
	
	
	public ExceptionLogDetail() {
		super();
		this.lastUpdated=ZonedDateTime.now();
	}

	public ExceptionLogDetail(String txId,String request,String errorLog) {
		super();
		this.txId = txId;
		this.requestBody=request;
		this.lastUpdated=ZonedDateTime.now();
		this.errorLog=errorLog;
	}
	
	public String getTxId() {
		return txId;
	}
	public String getRequestBody() {
		return requestBody;
	}
	public String getErrorLog() {
		return errorLog;
	}
	public ZonedDateTime getLastUpdated() {
		return lastUpdated;
	}
	public void setTxId(String txId) {
		this.txId = txId;
	}
	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}
	public void setErrorLog(String errorLog) {
		this.errorLog = errorLog;
	}
	public void setLastUpdated(ZonedDateTime lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	
	
}
