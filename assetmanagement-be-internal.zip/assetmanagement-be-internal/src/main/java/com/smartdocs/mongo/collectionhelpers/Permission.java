package com.smartdocs.mongo.collectionhelpers;

public class Permission {
	
	private String name;
	private String description;
	private boolean enabled;
	private String note;
	
	private boolean view;
	private boolean edit;
	
	private boolean showView;
	private boolean showEdit;
	
	public Permission() {
		super();
	}
	
	public Permission(String name,String desc, boolean enabled, boolean view,boolean edit,boolean showView,boolean showEdit) {
		super();
		this.name = name;
		this.description=desc;
		this.enabled=enabled;
		this.view=view;
		this.edit=edit;
		this.showView=showView;
		this.showEdit=showEdit;
	}
	public Permission(String name,String desc,String note, boolean view,boolean edit,boolean showView,boolean showEdit) {
		super();
		this.name = name;
		this.description=desc;
		this.note=note;
		 
		this.view=view;
		this.edit=edit;
		
		this.showView=showView;
		this.showEdit=showEdit;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public boolean getView() {
		return view;
	}
	public void setView(boolean view) {
		this.view = view;
	}
	public boolean getEdit() {
		return edit;
	}
	public void setEdit(boolean edit) {
		this.edit = edit;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getNote() {
		return note;
	}
	public boolean getShowView() {
		return showView;
	}
	public boolean getShowEdit() {
		return showEdit;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public void setShowView(boolean showView) {
		this.showView = showView;
	}
	public void setShowEdit(boolean showEdit) {
		this.showEdit = showEdit;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	
}
