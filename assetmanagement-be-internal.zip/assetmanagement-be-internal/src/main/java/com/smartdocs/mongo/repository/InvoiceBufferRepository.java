package com.smartdocs.mongo.repository;
import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.mongo.collections.InvoiceBuffer;

@Repository
public interface InvoiceBufferRepository extends MongoRepository<InvoiceBuffer, String> {

	long countByStatusIn(List<String> status);
	long countByChannelEmailAndStatusIn(String channel,List<String> status);
	long countByStatusAndReceivedDateBetween(String status,ZonedDateTime startDate, ZonedDateTime endDate);
	long countByStatus(String status);
	List<InvoiceBuffer> findAllByStatus(String string);
	
	InvoiceBuffer findByTechnicalEmailId(String technicalEmailId);

}
