package com.smartdocs.mongo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.mongo.collections.ExceptionLogDetail;


@Repository
public interface ExceptionLogDetailRepository extends MongoRepository<ExceptionLogDetail, String>{

 
}
