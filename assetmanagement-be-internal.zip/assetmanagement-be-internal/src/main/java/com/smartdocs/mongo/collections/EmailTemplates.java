package com.smartdocs.mongo.collections;

import org.springframework.data.annotation.Id;

public class EmailTemplates {

	@Id
	private String id;
	private String name;
	private String category;
	private String desciption;
	private String templateId;
	private String templateBody;
	private String subject;
	private String description;
	/// view only field
	private boolean configured;
	private String header;
	private String logo;
	private String signature;
	
	private String mainTemplate;
	private boolean enabled;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesciption() {
		return desciption;
	}
	public void setDesciption(String desciption) {
		this.desciption = desciption;
	}
	
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	
	
	public String getTemplateBody() {
		return templateBody;
	}
	public void setTemplateBody(String templateBody) {
		this.templateBody = templateBody;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public EmailTemplates(String id, String name, String desciption, String templateId, String templateBody,
			String subject) {
		super();
		this.id = id;
		this.name = name;
		this.desciption = desciption;
		this.templateId = templateId;
		this.templateBody = templateBody;
		this.subject = subject;
	}
	public EmailTemplates() {
		super();
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public boolean isConfigured() {
		return configured;
	}
	public void setConfigured(boolean configured) {
		this.configured = configured;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getMainTemplate() {
		return mainTemplate;
	}
	public void setMainTemplate(String mainTemplate) {
		this.mainTemplate = mainTemplate;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	
}

