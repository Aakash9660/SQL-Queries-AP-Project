package com.smartdocs.mongo.collections;

public class EmailTemplatesConstants {

	public static final String AP_FAILED_BOT_L1_REVIEW= "AP_Failed_Bot_L1_Review";
	public static final String AP_FAILED_BOT_L2_REVIEW= "AP_Failed_Bot_L2_Review";
}
