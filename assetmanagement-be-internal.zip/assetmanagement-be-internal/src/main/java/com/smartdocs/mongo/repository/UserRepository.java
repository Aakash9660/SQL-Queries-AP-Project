package com.smartdocs.mongo.repository;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.smartdocs.mongo.collections.User;


@Repository
@SuppressWarnings("unused")
public interface UserRepository extends MongoRepository<User, String> {

	
	Optional<User> findByEmail(String emailId);
	Optional<User> findByEmailIgnoreCase(String emailId);

	User findOneByEmail(String Email);

	User findOneByAccessToken(String oauthToken);
	User findOneByAppAccessToken(String oauthToken);
	
	List<User> findAllByAuthPermissionGroupsIn(List<String> roles);
 
	public Page<User> findAll(Pageable pageable);

 
	
}
