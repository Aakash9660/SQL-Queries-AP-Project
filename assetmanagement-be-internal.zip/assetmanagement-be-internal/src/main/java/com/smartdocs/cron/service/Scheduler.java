package com.smartdocs.cron.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.smartdocs.model.SystemConfig;
import com.smartdocs.model.TaskStatus;
import com.smartdocs.repository.TaskStatusRepository;
import com.smartdocs.service.SystemConfigService;
import com.smartdocs.service.TaskExeutionService;

@Component
public class Scheduler {
 

	
	@Value("${cron.missingBillSync.enabled}")
	private boolean missingBillSyncEnabled;

	@Value("${cron.jkServerLogSync.enabled}")
	private boolean jkServerLogSyncEnabled;
	
	@Autowired
	private TaskExeutionService taskExeutionService;
	
	@Autowired
	private TaskStatusRepository taskStatusRepository;
	
	@Autowired
	private SystemConfigService systemConfigService;
	
			
	@Scheduled(fixedDelayString  = "${cron.missingBillSync.delay}")
	public void missingBillSync() {
		try {
			 if(missingBillSyncEnabled)
			 {
				 Optional<TaskStatus> task= taskStatusRepository.findById(TaskStatus.MISSING_BILL_RECORD_CREATE);
					if(task.isPresent() && task.get().isEnabled())
					{
						if(task.get().getState()==TaskStatus.STATE_RUNNING) {
							taskExeutionService.endTask(task.get());
						}
						else {
							taskExeutionService.executeJenkinsSyncLog(task.get());
							if(TaskStatus.MISSING_BILL_RECORD_CREATE.equalsIgnoreCase(task.get().getTaskId())) {
								String value =systemConfigService.getConfigValue(SystemConfig.MISSING_BILL_GRACE_PERIOD);
								String startMonth =systemConfigService.getConfigValue(SystemConfig.START_MONTH);
								int gracePeriod=10;
								int startMonths=6;
								try {
									gracePeriod=Integer.valueOf(value);
									startMonths=Integer.valueOf(startMonth);
								}catch(Exception e) {} 
								taskExeutionService.executeMissingRepotCreate(task.get(),gracePeriod,startMonths);
							}
						}
						
					}
			 }
				
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	
	@Scheduled(fixedDelayString  = "${cron.jkServerLogSync.delay}")
	public void jkServerLogSync() {
		try {
			if(jkServerLogSyncEnabled )
			{
				Optional<TaskStatus> task= taskStatusRepository.findById(TaskStatus.JK_SYNC_LOG);
				if(task.isPresent() && task.get().isEnabled())
				{
					if(task.get().getState()==TaskStatus.STATE_RUNNING) {
						taskExeutionService.endTask(task.get());
					}
					else {
						taskExeutionService.executeJenkinsSyncLog(task.get());
					}
					
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}