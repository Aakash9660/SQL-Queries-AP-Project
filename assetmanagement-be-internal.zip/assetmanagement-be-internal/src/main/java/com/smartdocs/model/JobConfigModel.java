package com.smartdocs.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="job_configuration")
@Data
public class JobConfigModel {

	
	@Id
	private long id;
	private int workingHours;
	private int botExecutionTime;
	private int frequency;
	
	private boolean setupJobAuto;
	
	public JobConfigModel(JobConfigModel jobConfigModel) {
		this.id = jobConfigModel.getId();
		this.workingHours=jobConfigModel.getWorkingHours();
		this.botExecutionTime=jobConfigModel.getBotExecutionTime();
		this.frequency=jobConfigModel.getFrequency();
		this.setupJobAuto=jobConfigModel.setupJobAuto;
	}


	public JobConfigModel(int workingHours,int numberOfMinutes,int frequency) {
		this.id=100L;
		this.workingHours=workingHours;
		this.botExecutionTime=numberOfMinutes;
		this.frequency=frequency;
	}
	public JobConfigModel() {
		super();
	}
 
}
