package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.smartdocs.dto.InvoiceRequest;

import lombok.Data;
import lombok.ToString;

@Entity
@Table(name = "bill_document")
@Data
@ToString
public class BillDocument {

	public static final String STATUS_NEW = "NEW";
	public static final String STATUS_INPROCESS = "INPROCESS";
	public static final String STATUS_POSTED = "Posted";
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private Long assetId;
	private double amount;
	private String txId;
	private String docid;
	private String filename;
	private String attid;
	private String arid;
	private String currency;
	private String channel;
	private String uploadedBy;
	private String assetCode;
	private String vendorId;
	private String accountNumber;
	private String costCenter;
	private String glAccount;
	private String jobId;
	private String status;
	private String assetName;
	private String filetype;
	private String coupen;
	private String portalDocId;
	private String invoiceNumber;
	private String energyCapStatus;
	private String review;
	private boolean sendToExternal;
	private boolean s1Sync;
	private ZonedDateTime invoiceDate;
	private ZonedDateTime uploadedDate;
	private ZonedDateTime dueDate;
	private ZonedDateTime billMonth;
	private ZonedDateTime invoiceCreatedDate;
	private ZonedDateTime billMonthTo;
	private String utilityType;
	private boolean portalVisible;
	
	public BillDocument() {
	}

	public BillDocument(BufferDocument bufferDoc, AssetAccount assetAccount, Asset asset) {
		super();
		this.txId = bufferDoc.getTxId();
		this.docid = bufferDoc.getDocid();
		this.filename = bufferDoc.getFilename();
		this.filetype = bufferDoc.getFiletype();
		this.attid = bufferDoc.getAttid();
		this.arid = bufferDoc.getArid();
		this.uploadedBy = bufferDoc.getUploadedBy();
		this.uploadedDate = bufferDoc.getUploadedDate();
		this.vendorId = bufferDoc.getVendorId();
		this.accountNumber = bufferDoc.getAccountNumber();
		this.assetName = asset.getName();
		this.assetId = asset.getId();
		this.jobId = bufferDoc.getJobId();
		this.sendToExternal = bufferDoc.isSendToExternal();
		this.assetCode = bufferDoc.getAssetCode();
		this.review = bufferDoc.getReview();
		this.utilityType=bufferDoc.getUtilityType();
		if (bufferDoc.getBillAmount() != null) {
			this.amount = bufferDoc.getBillAmount();
		}
		if (bufferDoc.getDueDate() != null) {
			this.dueDate = bufferDoc.getDueDate();
		}
		if (assetAccount != null) {
			this.glAccount = assetAccount.getGlAccount();
			this.costCenter = assetAccount.getCostCenter();
		}

	}

	public BillDocument(InvoiceRequest invoiceRequest, AssetAccount assetAccount) {
		if (invoiceRequest.getDocumentInfo() != null) {
			this.docid = invoiceRequest.getDocumentInfo().getDocumentid();
			this.filename = invoiceRequest.getDocumentInfo().getFilename();
			this.filetype = invoiceRequest.getDocumentInfo().getFiletype();
			this.attid = invoiceRequest.getDocumentInfo().getAttid();
			this.arid = invoiceRequest.getDocumentInfo().getArid();
			this.uploadedBy = invoiceRequest.getDocumentInfo().getUploadedBy();
			this.uploadedDate = invoiceRequest.getDocumentInfo().getUploadedDate();
		}
		this.invoiceNumber = invoiceRequest.getInvoiceNumber();
		this.vendorId = invoiceRequest.getVendorId();
		this.accountNumber = invoiceRequest.getAccountNo();
		this.status = invoiceRequest.getStatus();
		this.amount = invoiceRequest.getAmount();
		this.dueDate = invoiceRequest.getDueDate();
		this.txId = invoiceRequest.getTxId();
		//this.txId = invoiceRequest.getTxId();
		this.invoiceDate = invoiceRequest.getInvoiceDate();
		if (assetAccount != null) {
			this.assetCode = assetAccount.getAssetCode();
			this.glAccount = assetAccount.getGlAccount();
			this.costCenter = assetAccount.getCostCenter();
		}
	}

}
