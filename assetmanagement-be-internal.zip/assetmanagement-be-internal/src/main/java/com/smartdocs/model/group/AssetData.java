package com.smartdocs.model.group;

import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.CostCenter;
import com.smartdocs.model.GLAccount;
import com.smartdocs.model.Vendor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class AssetData {
	
	private AssetAccount assetAccount;
	private Vendor vendor;
	private GLAccount glAccount;
	private CostCenter costCenter;

}
