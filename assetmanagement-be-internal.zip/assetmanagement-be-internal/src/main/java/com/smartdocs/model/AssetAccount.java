package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.smartdocs.dto.AssetAccountExcelRow;

import lombok.Data;

@Entity
@Table(name = "asset_account")
@Data
public class AssetAccount {

	public static final String CHANNEL_AUTOPILOT = "AutoPilot-Bot";
	public static final String CHANNEL_EMAIL = "AutoPilot-Email";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long assetAccountId;
	private Long vaultId;
	private String accountNumber;
	private String secondaryAccountNumber;
	private String assetCode;
	private String channel;
	private String costCenter;
	private String glAccount;
	private String frequency;
	private String jobFrequency;
	private String poNumber;
	@Column(columnDefinition = "TEXT")
	private String notes;
	private String vendorId;
	private boolean s1Sync;
	private boolean schedule;
	private boolean sendToExternal;
	private ZonedDateTime startDate;
	private ZonedDateTime lmdChecked;

	public AssetAccount() {
		super();

	}

	public AssetAccount(AssetAccountExcelRow row, Long vaultId) {
		super();
		this.assetCode = row.getAssetCode();
		this.vendorId = row.getVendorId();
		if (row.getAccountNo() != null)
			this.accountNumber = row.getAccountNo().trim();
		this.glAccount = row.getGlAccount();
		this.costCenter = row.getCostCenter();
		this.vaultId = vaultId;
		this.frequency = row.getFrequency();
		this.sendToExternal = row.isSendToExternal();
		this.channel = row.getChannel();
		this.startDate = row.getStarDateTime();
		this.secondaryAccountNumber = row.getSecondaryAccountNo();
	}
}
