package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "time_slots")
@Data
@NoArgsConstructor
@ToString
public class TimeSlots {



	@Id
	private Long id;
	private int day;
	private boolean allocated;
	private String fromTime;
	private String toTime;
	private String jobId;
	private ZonedDateTime lastExecuted;
	//private String cronPattern;
	private String serverId;

}
