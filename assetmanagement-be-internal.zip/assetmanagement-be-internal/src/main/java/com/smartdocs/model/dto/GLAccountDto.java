package com.smartdocs.model.dto;

import lombok.Data;

@Data
public class GLAccountDto {

	private String id;
	private String code;
	private String description;
}
