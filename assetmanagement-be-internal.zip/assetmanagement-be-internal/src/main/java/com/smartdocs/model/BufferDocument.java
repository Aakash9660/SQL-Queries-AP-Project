package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;


@Entity
@Table(name = "buffer_document")
@Data
public class BufferDocument {

	
	public static final int STATUS_PROCESSED=1;
	public static final int STATUS_DUPLICATE=2;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String txId;
	private String docid;
	private String filename;
	private String filetype;
	private String attid;
	private String arid;
	private String uploadedBy;
	private ZonedDateTime uploadedDate;
	private String assetCode;
	private String vendorId;
	private String accountNumber;
	private String jobId;
	private int status;
	private String duplicatedocId;
	private Double billAmount;
	private ZonedDateTime dueDate;
	private boolean sendToExternal;
//	private boolean sendExtReview;
	private String review;
	private String utilityType;
	
	public BufferDocument() {
		super();
	}


}
