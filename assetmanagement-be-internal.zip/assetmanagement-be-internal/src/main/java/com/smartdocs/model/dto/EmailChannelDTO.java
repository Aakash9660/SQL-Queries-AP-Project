package com.smartdocs.model.dto;

import javax.persistence.Id;

import lombok.Data;

@Data
public class EmailChannelDTO {

	@Id
	private String id;
	private String username;
	private boolean enabled;
	
}
