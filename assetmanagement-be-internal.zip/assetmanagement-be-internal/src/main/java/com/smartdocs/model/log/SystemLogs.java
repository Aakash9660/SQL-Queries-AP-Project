package com.smartdocs.model.log;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "System_Logs")
@Data
public class SystemLogs {

	public static final String SYSTEM_TYPE_SFTP = "SFTP";
	public static final String SYSTEM_TYPE_JENKINS = "Jenkins";
	public static final String SYSTEM_TYPE_SYNC = "S1";
	public static final String SYSTEM_TYPE_AUTOPILOT = "Autopilot";
	public static final String SYSTEM_TYPE_DUPLICATECHECK = "DuplicateCheck";
	
	public static final String SYSTEM_TYPE_INFO = "Info";
	public static final String SYSTEM_TYPE_WARN = "Warn";
	public static final String SYSTEM_TYPE_ERROR = "Fail";
	public static final String SYSTEM_TYPE_SUCCESS = "Success";
	public static final String SYSTEM_TYPE_FAIL = "Fail";
	
	public static final String SYSTEM_TAG_JK = "JK";
	public static final String SYSTEM_TAG_AP="AP";
	public static final String SYSTEM_TAG_SFTP="SFTP";
	public static final String SYSTEM_TAG_S1="S1";
	
	public static final String SYSTEM="System";
	public static final String USER="User";

	public static final String CONTENT_IS_NOT_SAME="Content is not Same";
	public static final String CONTENT_IS_SAME="Content is Same";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String title;
	@Column(columnDefinition = "TEXT")
	private String description;
	private ZonedDateTime  dateTime;
	private String  txId;
	private String systemType;
	private String status;//   [info/warn/error/success]
	private String systemTag;// [ap/JK/S1/ftp]
	private String agentId;
	private String agentType;// [user/system] 
	private String accountNo;
	private String vendorid;
	private String assetId;
	private String ip;
	private String userName;
	private String jobId;
	
	
	public SystemLogs() {
		
	}

	public SystemLogs(String title, String description, ZonedDateTime dateTime, String txId, String systemType,
			String status, String systemTag, String agentId, String agentType, String accountNo, String vendorid,
			String assetId,String ip,String userName) {
		super();
		this.title = title;
		this.description = description;
		this.dateTime = dateTime;
		this.txId = txId;
		this.systemType = systemType;
		this.status = status;
		this.systemTag = systemTag;
		this.agentId = agentId;
		this.agentType = agentType;
		this.accountNo = accountNo;
		this.vendorid = vendorid;
		this.assetId = assetId;
		this.ip=ip;
		this.userName=userName;
	}
	public SystemLogs(String title, String description, ZonedDateTime dateTime, 
			String txId, String systemType,
			String status, String systemTag,
			
			String userName,String jobId) {
		super();
		this.title = title;
		this.description = description;
		this.dateTime = dateTime;
		this.txId = txId;
		this.systemType = systemType;
		this.status = status;
		this.systemTag = systemTag;
		this.userName=userName;
		this.jobId=jobId;
	}
	public SystemLogs(String title, String description, ZonedDateTime dateTime, 
			String txId, String systemType,
			String status, String systemTag,
			
			String userName,String jobId,String ip) {
		super();
		this.title = title;
		this.description = description;
		this.dateTime = dateTime;
		this.txId = txId;
		this.systemType = systemType;
		this.status = status;
		this.systemTag = systemTag;
		this.userName=userName;
		this.jobId=jobId;
	}
	
	
	

}
