package com.smartdocs.model.dto;

import java.time.ZonedDateTime;

import lombok.Data;

@Data
public class VendorScriptDto {

	private Long Id;
	private String vendorId;
	private String codeScript;
	private String version;
	private ZonedDateTime lastUpdated;
	private String updatedBy;

	private String fileName;
	private String scriptType;

	private boolean sync;

}
