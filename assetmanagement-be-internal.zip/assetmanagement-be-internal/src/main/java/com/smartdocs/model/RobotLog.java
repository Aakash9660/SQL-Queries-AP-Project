package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.smartdocs.jenkins.dto.FreeStyleBuild;
import com.smartdocs.service.util.GeneralUtil;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "RobotLog")
@Data
@NoArgsConstructor
public class RobotLog {
	
	public static final int STAGE_L1=1;
	public static final int STAGE_L2=2;

	public static final String STATUS_OPEN="OPEN";
	public static final String STATUS_COMPLETE="COMPLETE";
	public static final String STATUS_OBSOLETE="OBSOLETED";
	
	public static final String ACTION_COMPLETE="COMPLETED";
	public static final String ACTION_OBSOLETE="OBSOLETED";
	public static final String ACTION_SEND_TO_L1="SEND_TO_L1";
	public static final String ACTION_SEND_TO_L2="SEND_TO_L2";
	
	@Id
	private String id; 
	private String botName;
	private String assetCode;
	private String accountNo;
	private String vendorId;
	
	private String txId;
	private Integer stage;

	@Column(columnDefinition = "TEXT")
	private String comments;
	
	private String status;
	private String buildStatus;
	private ZonedDateTime lastExecuted;
	
	private long duration;
	private long estimatedDuration;
	private boolean inProgress;
	private boolean keepLog;
	private long number;
	private long queueId;
	private long timestamp;
	private ZonedDateTime createdDate;
	private ZonedDateTime buildExTime;
	private ZonedDateTime lastUpdated;
	
	
	public RobotLog(String jobId,String sid,
			Robot robot,
			FreeStyleBuild build) {
		super();
		this.id = jobId+"_"+sid+"_"+build.getNumber();
		this.botName = jobId;
		this.assetCode = robot.getAssetCode();
		this.accountNo = robot.getAccountNo();
		this.vendorId = robot.getVendorId();
		this.txId =  jobId+"_"+sid+"_"+build.getNumber();
		this.stage = 1;
		this.status = STATUS_OPEN;
		this.duration = build.getDuration();
		this.estimatedDuration = build.getEstimatedDuration();
		this.inProgress = build.isInProgress();
		this.keepLog = build.isKeepLog();
		this.number = build.getNumber();
		this.queueId = build.getQueueId();
		this.timestamp = build.getTimestamp();
		this.buildStatus = build.getResult();
		this.createdDate=ZonedDateTime.now();
		this.buildExTime=GeneralUtil.toDate(build.getTimestamp());
		this.lastUpdated=ZonedDateTime.now();
	}
	
 
	
	
}
