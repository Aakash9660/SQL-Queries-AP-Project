package com.smartdocs.model.group;

import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.BillDocument;
import com.smartdocs.model.CostCenter;
import com.smartdocs.model.GLAccount;
import com.smartdocs.model.Vendor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BillDataRequest {

	private BillDocument billDocument;
	private Vendor vendor;
	private GLAccount glAccount;
	private CostCenter costCenter;
	private AssetAccount assetAccount;
	private Asset asset;
	
}
