package com.smartdocs.model;


import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.smartdocs.dto.AttachmentDTO;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "RobotLogActivityDetail")
@Data
@NoArgsConstructor
public class RobotLogActivityDetail {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String robotLogId;
	private int stage;
	
	@Column(columnDefinition = "TEXT")
	private String comments;
	private String agent;
	private String userName;
	private String activityCode;
	private String activityDesc;
	private ZonedDateTime createDate;
	
	
	private String docid;
	private String filename;
	private String filetype;
	private String attid;
	private String arid;
	
	public RobotLogActivityDetail( String robotLogId, int stage, String comments, String user, String userName,
			String activityCode, String activityDesc,AttachmentDTO attachment) {
		super();
		this.robotLogId = robotLogId;
		this.stage = stage;
		this.comments = comments;
		this.agent = user;
		this.userName = userName;
		this.activityCode = activityCode;
		this.activityDesc = activityDesc;
		this.createDate = ZonedDateTime.now();
		if(attachment!=null)
		{this.docid=attachment.getDocid();
		this.filename=attachment.getFilename();
		this.filetype=attachment.getFiletype();
		this.attid=attachment.getAttid();
		this.arid=attachment.getArid();
		}
	}
	
	
}
