package com.smartdocs.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "app_config")
@Data
public class SystemConfig {
  
	public static final String DUP_CHECK="DUP_CHECK";
	public static final String MISSING_BILL_GRACE_PERIOD="MISSING_BILL_GRACE_PERIOD";
	public static final String START_MONTH="START_MONTH";
	public static final String MISSING_BILL_JOB_RUN_PER_DAY="MISSING_BILL_JOB_RUN_PER_DAY";
	
	@Id
	private String config;
	private String value;
	private String description;
}
