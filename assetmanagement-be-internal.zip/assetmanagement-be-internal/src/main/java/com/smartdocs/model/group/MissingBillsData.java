package com.smartdocs.model.group;

import com.smartdocs.model.Asset;
import com.smartdocs.model.MissingBills;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MissingBillsData {

	private MissingBills missingBills;
	private Asset asset;
}
