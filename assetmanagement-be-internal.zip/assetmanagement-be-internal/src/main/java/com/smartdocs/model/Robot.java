package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "robot")
@Data
public class Robot {
	
	public static final String STATUS_NEW="NEW";
	public static final String STATUS_PUBLISHED="PUBLISHED";
	public static final String STATUS_PAUSED="PAUSED";

	@Id
	private String id;
	private String accountNo;
	private String vendorId;
	private String assetCode;
	private int scriptVersion;
	private String vaultVersion;
	private ZonedDateTime lastUpdated;
	private String status;
	
	private String buildStatus;
	private ZonedDateTime lastExecuted;
	private ZonedDateTime nextExecution;
	private String executedStatus;
	private String leLogId;
	private boolean schedule;
	
	private String jobId;
	private String jobPath;
	private String jobStatus;
	private String jenkinsCommand;
	private String frequency;
	private String txId;
	private long lastExecutedms;

	
	public Robot() {
		super();
	}
	public Robot(AssetAccount assetAccount) {
		super();
		this.id = assetAccount.getAssetCode()+"-"+assetAccount.getVendorId()+"-"+assetAccount.getAccountNumber();
		this.accountNo = assetAccount.getAccountNumber();
		this.vendorId = assetAccount.getVendorId();
		this.assetCode = assetAccount.getAssetCode();
		this.lastUpdated = ZonedDateTime.now();
		this.status = Robot.STATUS_NEW;
		this.frequency=assetAccount.getFrequency();
	}
	
}
