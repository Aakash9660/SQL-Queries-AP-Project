package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "vendor_script")
@Data
public class VendorScript {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String vendorId;
	@Column(columnDefinition = "TEXT")
	private String codeScript;
	private String fileName;
	private String scriptType;
	private ZonedDateTime lastUpdated;
	private String updatedBy;
	private boolean sync;
	private int version;

}
