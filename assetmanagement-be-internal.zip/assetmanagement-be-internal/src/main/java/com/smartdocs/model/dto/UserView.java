package com.smartdocs.model.dto;

import java.time.ZonedDateTime;

import lombok.Data;

@Data
public class UserView {
	
	private String email;
	private String firstName;
	private String lastName;
	private boolean enabled;
	private ZonedDateTime lastLogin;

}
