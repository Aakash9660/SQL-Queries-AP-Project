package com.smartdocs.model.group;

import com.smartdocs.model.CostCenter;
import com.smartdocs.model.GLAccount;
import com.smartdocs.model.helper.Address;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class AssetAccountProjection {
	
	private String assetCode;
	private String assetName;
	private Address assetAddress;
	private String accountNo;
	private boolean sendToExternal;
	private String channel;
	private String frequency;
	private GLAccount glAccount;
	private CostCenter costCenter;
}
