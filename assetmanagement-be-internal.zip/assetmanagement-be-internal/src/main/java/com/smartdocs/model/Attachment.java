package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "attachment")
@Data
public class Attachment {
	
	@Id
	private String docid;
	private Integer sharadId;
 
	private String filename;
	private String filetype;
	private String attid;
	private String arid;
	private String uploadedBy;
	private ZonedDateTime uploadedDate;

}
