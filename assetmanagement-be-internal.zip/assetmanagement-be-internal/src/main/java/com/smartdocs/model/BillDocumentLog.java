package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "bill_document_log")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BillDocumentLog {

	public static final String DIRECTION_EMAIL_TO_AP = "Email-AP";
	public static final String DIRECTION_CREATE = "Created-AP";
	public static final String DIRECTION_S1_TO_AP="S1-AP";
	public static final String DIRECTION_AP_TO_S1="AP-S1";
	
	public static final String STATUS_FAIL="Fail";
	public static final String STATUS_SUCCESS="Success";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private ZonedDateTime  dateTime;
	private long  billId;
	private String direction;
	private String desciption;
	private String channel;
	private String status;
	
	public BillDocumentLog(long billId, String direction, String desciption,
			String status,String channel) {
		super();
		this.dateTime = ZonedDateTime.now();
		this.billId = billId;
		this.direction = direction;
		this.desciption = desciption;
		this.status = status;
		this.channel=channel;
	}
	public BillDocumentLog(long billId, String direction, String desciption,
			String status) {
		super();
		this.dateTime = ZonedDateTime.now();
		this.billId = billId;
		this.direction = direction;
		this.desciption = desciption;
		this.status = status;
	}
	
}
