package com.smartdocs.model.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.smartdocs.model.Asset;
import com.smartdocs.model.Manager;
import com.smartdocs.model.helper.Address;

import lombok.Data;

@Data
public class AssetDetail {
	
	private Long id;
	private String assetCode;
	private String name;
	private String assetType;
	private double latitude;
	private double  longitude;
	private Address address;
	private List<AssetAccountDetail> accounts;
	private List<Manager> managers;
	private ZonedDateTime lastUpdated;
	private ZonedDateTime createdDate;
	private Integer totalVendors;

	public AssetDetail() {
		super();
	}
	
	public AssetDetail(Asset asset) {
		this.id = asset.getId();
		this.assetCode = asset.getAssetCode();
		this.name = asset.getName();
		this.assetType = asset.getAssetType();
		this.latitude = asset.getLatitude();
		this.longitude = asset.getLongitude();
		this.address = asset.getAddress();
		this.lastUpdated = asset.getLastUpdated();
		this.createdDate = asset.getCreatedDate();
	}

	
}
