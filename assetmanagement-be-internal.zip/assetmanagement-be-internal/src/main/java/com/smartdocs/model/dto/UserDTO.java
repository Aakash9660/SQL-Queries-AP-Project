package com.smartdocs.model.dto;

import java.time.ZonedDateTime;

import lombok.Data;
@Data
public class UserDTO {

	private String email;
	private String firstName;
	private String lastName;
	private String password;
	private boolean enabled;
	private int invalidPasswordAttempts;
	
	
	private ZonedDateTime lastLogin;
	private ZonedDateTime lastActivity;

	private String vendorId;
	private String role;
	
	private String accessToken;
	private String loginType;
	
}
