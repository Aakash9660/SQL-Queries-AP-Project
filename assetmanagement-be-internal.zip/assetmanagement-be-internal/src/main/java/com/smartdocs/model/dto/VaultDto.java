package com.smartdocs.model.dto;

import lombok.Data;

@Data
public class VaultDto {

	private Long id;
	private String name;
	private String description;
	private String userId;
	private String password;
	private String toEmail;
	private String vendorURL;

}
