package com.smartdocs.model.helper;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "contact")
@Data
public class Contact {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String contactId;
	private boolean isDefault;
	private String firstname;
	private String lastname;
	private String email;
	private String  functionName;
	private boolean admin;
	private boolean isPortalAccount;
	private boolean asPrimaryEmail;
	private String phoneCountryCode;
	private String phoneNumber;
	private String phoneExtension;
	private String mobileCountryCode;
	private String mobileNumber;
	private String faxCountryCode;
	private String faxNumber;
	
}
