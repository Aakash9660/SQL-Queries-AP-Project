package com.smartdocs.model.group;

import com.smartdocs.model.RobotLog;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RobotLogData {

	private RobotLog robotLog;
	private String assetName;
	private String vendorName;
}
