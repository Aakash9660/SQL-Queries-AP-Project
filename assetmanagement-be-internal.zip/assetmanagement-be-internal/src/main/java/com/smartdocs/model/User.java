//package com.smartdocs.model;
//
//import java.io.Serializable;
//import java.time.ZonedDateTime;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//
//import lombok.Data;
//
//@Entity
//@Table(name = "users")
//@Data
//public class User implements Serializable{
//	
//	private static final long serialVersionUID = 1L;
//	
//
//	public static final String ROLE_SUPER_ADMIN = "SuperAdmin";
//	public static final String ROLE_BUSINESS_ADMIN= "BusinessAdmin";
//	public static final String ROLE_SUPPLIER_USER = "SupplierUser";
//	public static final String ROLE_COMPANY_USER = "CompanyUser";
//	public static final String ROLE_SYSTEM_ADMIN = "SystemAdmin";
//	public static final String ROLE_SYSTEM_INTEGRATION = "SystemIntegration";
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long id;
//	private String email;
//	private String firstName;
//	private String lastName;
//	private String password;
//	
//	private boolean enabled;
//	private int invalidPasswordAttempts;
//
//	private ZonedDateTime lastLogin;
//	private ZonedDateTime lastActivity;
//	private String vendorId;
//	private String role;
//	
//	@Column(columnDefinition = "TEXT")
//	private String accessToken;
//	
//	@Column(columnDefinition = "TEXT")
//	private String appAccessToken;
//
//	private String loginType;
//	
//	
//	public User() {
//	}
//	public String getName() {
//		return this.getFirstName()+" "+this.getLastName();
//	}
//	public User(String email, String password) {
//		super();
//		this.email = email;
//		this.password = password;
//	}
//
//	public void addInvalidPasswordAttempt() {
//		this.invalidPasswordAttempts = invalidPasswordAttempts + 1;
//	}
//
//}
