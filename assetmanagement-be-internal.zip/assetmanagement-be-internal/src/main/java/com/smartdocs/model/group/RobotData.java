package com.smartdocs.model.group;

import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.Robot;
import com.smartdocs.model.Vendor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class RobotData {

	private Robot robot;
	private Asset asset;
	private AssetAccount assetAccount;
	private Vendor vendor;
}
