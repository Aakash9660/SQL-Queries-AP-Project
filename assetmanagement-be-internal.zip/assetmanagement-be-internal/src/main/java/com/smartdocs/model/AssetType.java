package com.smartdocs.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name = "asset_type")
@Data
@RequiredArgsConstructor
public class AssetType {
	
	@Id
	private String name;
	private String description;

}
