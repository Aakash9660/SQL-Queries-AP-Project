package com.smartdocs.model.dto;


import lombok.Data;

@Data
//@Entity
//@Table(name = "manager")
public class ManagerDto {
	
//	@Id
//    @GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	private String name;
	private String url;
	private String email;
	private String role;

}