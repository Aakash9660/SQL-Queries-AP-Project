package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;


@Entity
@Table(name = "task_status")
@Data
public class TaskStatus {
  
	public static final String MISSING_BILL_RECORD_CREATE="MBRC";
	
	public static final String JK_SYNC_LOG="JKSYNCLOG";
	
	public static final String RESET_TIME_SLOT="RESET_TIME_SLOT";
	
	public static final String UNSCHEDULE_ALL_BOTS="UNSCHEDULE_ALL_BOTS";
	public static final String SCHEDULE_ALL_BOTS="SCHEDULE_ALL_BOTS";
	public static final String PUBLISH_ALL_BOTS="PUBLISH_ALL_BOTS";
	public static final String UNPUBLISH_ALL_BOTS="UNPUBLISH_ALL_BOTS";
	
	public static final int STATE_STOPED=0;
	public static final int STATE_RUNNING=1;
	
	 
	@Id
	private String taskId;
	private String name;
	private long executionNumber;
	private int state;
	private ZonedDateTime startTime;
	private ZonedDateTime endTime;	
	private String recorProcessed;
	private long lastExecutedTime;
	private ZonedDateTime lastExCompletionDate;
	private boolean enabled;
	private boolean manualExecution;
	private long totalDataToProcees;
}
