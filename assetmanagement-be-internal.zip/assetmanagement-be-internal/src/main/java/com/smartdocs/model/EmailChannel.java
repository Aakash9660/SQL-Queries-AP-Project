package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "EmailChannel")
@Data
public class EmailChannel {
	
	public static final String AUTH_TYPE_OAUTH="oauth";

	
	@Id
	private String id;
	
	private String email;
	private boolean enabled;
	private boolean isSharedEmailId;
	private String authType;
	private long expires_in;
	private String tenantId;
	private String sharedEmail;
	
	@Column( length = 3048)
	private String access_token;
	@Column( length = 2048)
	private String refresh_token;
	private String redirectURI;
	private ZonedDateTime lastUpdated;
	
}
