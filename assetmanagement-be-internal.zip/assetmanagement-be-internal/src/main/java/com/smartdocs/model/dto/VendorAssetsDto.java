package com.smartdocs.model.dto;

import com.smartdocs.model.helper.Address;

import lombok.Data;

@Data
public class VendorAssetsDto {

	private String assetCode;
	private String assetName;
	private Address assetAddress;
	private String accountNo;
	private String channel;
	private String frequency;
	private String costCenter;
	private String costCenterDesc;
	private String glAccount;
	private String glAccountDesc;

}