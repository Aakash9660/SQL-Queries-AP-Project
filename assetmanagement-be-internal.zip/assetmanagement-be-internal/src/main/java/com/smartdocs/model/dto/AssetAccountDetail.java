package com.smartdocs.model.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.smartdocs.model.Robot;
import com.smartdocs.model.helper.Address;

import lombok.Data;

@Data
public class AssetAccountDetail {
	 
	private Long assetAccountId;
	private String vendorId;
	private String vendorName;
	private List<String> classifications;
	private Address address;
	private String accountNumber;
	private String costCenter;
	private String costCenterDesc;
	private String glAccount;
	private String glAccountDesc;
	private String poNumber;
	private Long vaultId;
	private String frequency;
	private Robot robot;
	private ZonedDateTime startDate;
	private String channel;
	private boolean sendToExternal;
}
