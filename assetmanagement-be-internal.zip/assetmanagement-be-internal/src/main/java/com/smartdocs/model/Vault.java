package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.smartdocs.dto.VaultExcelRow;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "vault")
@Data
@NoArgsConstructor
public class Vault {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(unique = true)
	private String name;
	private String description;
	private String userId;
	private String password;
	private int version;
	private String toEmail;
	private ZonedDateTime lastUpdated;
	private ZonedDateTime createdDate;

	public Vault(VaultExcelRow row) {
		this.name = row.getName();
		this.description = row.getDescription();
		this.userId = row.getUserId();
		this.toEmail = row.getToEmail();
		this.lastUpdated = ZonedDateTime.now();
		this.createdDate = ZonedDateTime.now();
	}

}
