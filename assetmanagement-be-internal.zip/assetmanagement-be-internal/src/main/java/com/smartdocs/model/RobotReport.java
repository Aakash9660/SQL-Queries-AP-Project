package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "robot_report")
@Data
@NoArgsConstructor
public class RobotReport {


	@Id
	private String id;
	private String comment;
	private String status;
	private String jobId;
	private int day;
	private ZonedDateTime dateTime;
}
