package com.smartdocs.model.dto;


import lombok.Data;

@Data
public class SmartStoreConfiguratorDTO {

	private Long id;
	private String serverURL;
	private String system;
	private String pVersion;
	private String contRep;
	private String compId;
	private String authId;
	private String expiration;
	private String secKey;
	
}
