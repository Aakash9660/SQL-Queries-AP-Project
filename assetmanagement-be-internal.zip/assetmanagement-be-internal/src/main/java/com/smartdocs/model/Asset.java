package com.smartdocs.model;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.smartdocs.model.helper.Address;

import lombok.Data;

@Entity
@Table(name = "asset")
@Data
public class Asset {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(unique = true)
	private String assetCode;
	private String description;
	private String name;
	private String assetType;
	private ZonedDateTime lastUpdated;
	private ZonedDateTime createdDate;
	
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	private Address address;

	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY,orphanRemoval = true)
	@JoinColumn(name = "asset_id")
	private List<AssetAccount> accounts = new ArrayList<>();
	

	@ElementCollection
	private List<Long> managersIds;
	private String approvers;
	private double latitude;
	private double  longitude;
	
	@Override
	public String toString() {
		return "Asset [id=" + id + ", assetCode=" + assetCode + ", description=" + description + ", name=" + name
				+ ", assetType=" + assetType + ", lastUpdated=" + lastUpdated + ", createdDate=" + createdDate
				+ ", address=" + address + ", accounts=" + accounts + ", managersIds=" + managersIds + ", approvers="
				+ approvers + ", latitude=" + latitude + ", longitude=" + longitude + "]";
	}
	
	
	
	
}
