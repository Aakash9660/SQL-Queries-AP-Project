package com.smartdocs.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "vendorclassifications")
@Data
public class VendorClassifications {

	@Id
	private String name;
	private String description;
}
