package com.smartdocs.model.dto;

import lombok.Data;

@Data
public class DCMProcessRequest {

	private String txId;
	private String arDocId;
	private String status;
	private boolean duplicate;
	private String duplicateDocId;

}
