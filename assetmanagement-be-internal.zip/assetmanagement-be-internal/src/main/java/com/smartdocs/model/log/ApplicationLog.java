package com.smartdocs.model.log;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
import lombok.Data;


@Entity
@Table(name = "applicationLog")
@Data
public class ApplicationLog {

	public static final String TYPE_USER_SIGNIN="SignIn";
	public static final String TYPE_INVOICE_SUBMISSION = "InvoiceSubmission";
	public static final String TYPE_VENDOR_CHANGE_REQ_SUBMISSION = "VendorChangeRequestSubmission";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String id;
	
	private String ipAddress;
	
	private ZonedDateTime dateTime;
	
	private String type;
	
	//agent means who user did this activity.
	private String agent;
	
	private String name;
	
	private String itemType;
	
	private String itemId;
	
	private String title;
	
	private String description;
	
	private String buyerId;
	
	private String logSource;
	
	private String apiPath;
	
	private String role;
	
	public ApplicationLog() {
		super();
	}

	public ApplicationLog(String ip,String type, String agent,String name, String itemType, String itemId,
			String title, String description,String logSource,String apiPath,String role) {
		super();
		this.ipAddress = ip;
		this.dateTime = ZonedDateTime.now();
		this.type = type;
		this.agent = agent;
		this.name = name;
		this.itemType = itemType;
		this.itemId = itemId;
		this.title = title;
		this.description = description;
		this.logSource=logSource;
		this.apiPath=apiPath;
		this.role=role;
	}
	public ApplicationLog(String ip,String type, String agent,String name, String itemType,
			String title, String description,String logSource,String apiPath) {
		super();
		this.ipAddress = ip;
		this.dateTime = ZonedDateTime.now();
		this.type = type;
		this.agent = agent;
		this.name = name;
		this.itemType = itemType;
		this.title = title;
		this.description = description;
		this.logSource=logSource;
		this.apiPath=apiPath;
	}
}
