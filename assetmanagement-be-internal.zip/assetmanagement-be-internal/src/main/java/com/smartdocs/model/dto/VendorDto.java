package com.smartdocs.model.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.smartdocs.model.helper.Address;

import lombok.Data;

@Data
public class VendorDto {
	

	private Long id;
	private String vendorId;
	private String name;
	private Address address;
	private boolean utilityVendor;
	private List<String> classifications;
	private String url;

	private String fromEmail;
	private String toEmail;
	private Boolean mfa;
	private ZonedDateTime lastUpdated;
	
	private boolean isCoupon;
	private int pageNo;
	private double lx;
	private double ly;
	private double ry;
	private double rx;
	private Integer totalAccounts;
	private boolean manualIntervention;
	private boolean cleanupInvoice;
}
