package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "access_management")
@Data
public class AccessManagement {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String appName;
	private String appId;
	private String appSecret;
	private ZonedDateTime createdDate;
	private ZonedDateTime lastAccessed;	
	private String userEmail;

}
