package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "MissingBills")
@Data
@NoArgsConstructor
public class MissingBills {

	public static final String STATUS_COMPLETED = "Completed";
	public static final String STATUS_OBSOLETE = "Obsolete";
	public static final String STATUS_NEW = "New";
	@Id
	private String id;
	private String assetCode;
	private String accountNo;
	private String vendorId;
	private String status;
	private String comments;
	private String period;
	private ZonedDateTime createdDate;
	private String assetName;
	private String vendorName;
	private ZonedDateTime lastUpdated;
	
	public MissingBills(AssetAccount assetAccount) {
		this.assetCode = assetAccount.getAssetCode();
		this.accountNo = assetAccount.getAccountNumber();
		this.vendorId = assetAccount.getVendorId();

	}

}
