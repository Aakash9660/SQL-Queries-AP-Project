package com.smartdocs.model;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.smartdocs.dto.UpdateActionRequest;
import com.smartdocs.security.service.UserPrincipal;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "ManageBillsLog")
@NoArgsConstructor
public class ManageBillsLog {
	
	
	public static final String ACTIVITY_ADDING_NOTES="ADDING_NOTES";
	public static final String ACTIVITY_EMAIL_BILLS="EMAIL_BILLS";
	public static final String ACTIVITY_SYSTEM_BILLS="SYSTEM_BILLS";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String assetCode;
	private String accountNo;
	private String vendorId;
	private String userName;
	private String activityCode;
	private String activityDesc;

	@Column(columnDefinition = "TEXT")
	private String comments;
	private String docId;
	private String fileName;
	private String fileType;
	private ZonedDateTime uploadedDate;

	public ManageBillsLog(UpdateActionRequest actionRequest, UserPrincipal logedInUser) {
		super();
		this.assetCode = actionRequest.getAssetCode();
		this.accountNo = actionRequest.getAccountNo();
		this.vendorId = actionRequest.getVendorId();
		this.comments = actionRequest.getComment();
		if ( actionRequest.getAttachment() != null) {
			this.docId = actionRequest.getAttachment().getDocid();
			this.fileName = actionRequest.getAttachment().getFilename();
			this.fileType = actionRequest.getAttachment().getFiletype();
		}
		this.uploadedDate = ZonedDateTime.now();
		this.userName = logedInUser.getName();
	}

	public ManageBillsLog(BillDocument actionRequest) {
		super();
		this.assetCode = actionRequest.getAssetCode();
		this.accountNo = actionRequest.getAccountNumber();
		this.vendorId = actionRequest.getVendorId();
		this.docId = actionRequest.getDocid();
		this.fileName = actionRequest.getFilename();
		this.fileType = actionRequest.getFiletype();
		this.userName=actionRequest.getUploadedBy();
		this.uploadedDate = ZonedDateTime.now();
	}
}
