package com.smartdocs.model.dto;

import java.util.List;

import com.smartdocs.model.Asset;
import com.smartdocs.model.AssetAccount;
import com.smartdocs.model.Manager;
import com.smartdocs.model.helper.Address;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AssetDto {

	private Long id;
	private Long assetAccountId;
	private String assetCode;
	private String name;
	private String assetType;
	private Address address;
	private List<AssetAccount> accounts;
	private List<Manager> managers;
	private String approvers;
	private double latitude;
	private double  longitude;
	private Integer totalVendors;
	
	public AssetDto(Asset asset) {
		this.id=asset.getId();
		this.assetCode = asset.getAssetCode();
		this.name = asset.getName();
		this.assetType = asset.getAssetType();
		this.address = asset.getAddress();
		this.accounts = asset.getAccounts();
		this.latitude = asset.getLatitude();
		this.longitude = asset.getLongitude();
	}
	
	

}
