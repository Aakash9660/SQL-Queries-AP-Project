package com.smartdocs.model;

import java.time.ZonedDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.smartdocs.model.helper.Address;

import lombok.Data;

@Entity
@Table(name = "vendor")
@Data
public class Vendor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String vendorId;
	private String name;

	private String primaryContactName;
	private String primaryEmail;
	private String phone;
	private String countryCode;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	private Address address;
	private boolean utilityVendor;

	@ElementCollection
	private List<String> classifications;
	private String url;
	private Boolean isVendorScriptPresent;
	private String iconUrl;
	
	private String fromEmail;
	private Boolean mfa;
	private ZonedDateTime lastUpdated;
	
	private boolean isCoupon;
	private int pageNo;
	private double lx;
	private double ly;
	private double ry;
	private double rx;
	
	private boolean manualIntervention;
	private String manualInterventionAddedBy;

	@Column(columnDefinition="boolean default false")
	private boolean cleanupInvoice;

}
