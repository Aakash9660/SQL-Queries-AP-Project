package com.smartdocs.model.group;

import com.smartdocs.model.helper.Address;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AssetRequireData {
	private Long id;
	private String assetCode;
	private String name;
	private String assetType;
	private Address address;
	private double latitude;
	private double  longitude;
}