package com.smartdocs.model.dto;

import lombok.Data;

@Data
public class CostCenterDto {
	
	private String id;
	private String code;
	private String description;
}
