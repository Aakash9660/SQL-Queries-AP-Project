package com.smartdocs.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "smart_store_configurator")
@Data
public class SmartStoreConfigurator {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String serverURL;
	private String system;
	private String pVersion;
	private String contRep;
	private String compId;
	private String authId;
	private String expiration;
	@Column(columnDefinition="TEXT")
	private String secKey;
}
