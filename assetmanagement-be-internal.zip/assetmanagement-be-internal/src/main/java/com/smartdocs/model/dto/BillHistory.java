package com.smartdocs.model.dto;

import java.time.ZonedDateTime;
import java.util.List;

import com.smartdocs.model.BillDocument;
import com.smartdocs.model.helper.Address;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BillHistory {

	private Long id;
	private String vendorId;
	private String vendorName;
	private List<String> classifications;
	private String accountNumber;
	private String costCenter;
	private String costCenterDesc;
	private String glAccount;
	private String glAccountDesc;
	private String docId;
	private String url;
	private String status;
	private double amount;
	private String txId;
	private String uploadedBy;
	private String assetcode;
	private Address assetAddress;
	private Long assetId;
	private String assetname;
	private String portalDocId;
	private String invoiceNumber;
	private String channel;
	private ZonedDateTime billMonth;
	private ZonedDateTime dueDate;
	private ZonedDateTime invoiceDate;
	private ZonedDateTime uploadedDate;
	private ZonedDateTime invoiceCreatedDate;
	

	public BillHistory(BillDocument billDocument) {
		super();
		this.id = billDocument.getId();
		this.accountNumber = billDocument.getAccountNumber();
		this.docId = billDocument.getDocid();
		this.status = billDocument.getStatus();
		this.dueDate = billDocument.getDueDate();
		this.amount = billDocument.getAmount();
		this.txId = billDocument.getTxId();
		this.uploadedDate = billDocument.getUploadedDate();
		this.uploadedBy = billDocument.getUploadedBy();
		this.assetcode = billDocument.getAssetCode();
		this.assetId = billDocument.getAssetId();
		this.assetname = billDocument.getAssetName();
		this.portalDocId = billDocument.getPortalDocId();
		this.invoiceNumber = billDocument.getInvoiceNumber();
		this.billMonth=billDocument.getBillMonth();
		this.invoiceCreatedDate=billDocument.getInvoiceCreatedDate();
		this.invoiceDate=billDocument.getInvoiceDate();
	}

}
