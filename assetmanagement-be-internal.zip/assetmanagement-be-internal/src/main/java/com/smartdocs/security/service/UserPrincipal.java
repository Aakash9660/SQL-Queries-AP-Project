package com.smartdocs.security.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.smartdocs.model.helper.RoleName;
import com.smartdocs.mongo.collectionhelpers.Permission;
import com.smartdocs.mongo.collections.User;

public class UserPrincipal implements UserDetails {

	private static final Logger logger = LoggerFactory.getLogger(UserPrincipal.class);

	private static final long serialVersionUID = 1L;

	private String id;

	private String name;

	private String email;

	private String currency;

	private String role;

	private String vendorId;

	private List<String> permissionsGroups;
	private Map<String,Permission> permissions;

	@JsonIgnore
	private String password;

	@JsonDeserialize(using = CustomAuthorityDeserializer.class)
	private Collection<? extends SimpleGrantedAuthority> authorities;

	private String dateformate;

	private String dateAndTimeFormate;

	public UserPrincipal(User user, Collection<? extends SimpleGrantedAuthority> authorities,Map<String,Permission> permissions ) {
		this.id = user.getId();
		this.name = user.getFirstname() + " " + user.getLastname();
		this.email = user.getEmail();
		this.password = user.getPassword();
		this.role = user.getRole();
		this.authorities = authorities;
		this.vendorId = user.getSupplierId();
		this.permissionsGroups=user.getAuthPermissionGroups();
		this.permissions=permissions;
//		this.systemId = user.getSystemId();
	}

	public String getDateformate() {
		return dateformate;
	}

	public void setDateformate(String dateformate) {
		this.dateformate = dateformate;
	}

	public String getDateAndTimeFormate() {
		return dateAndTimeFormate;
	}

	public void setDateAndTimeFormate(String dateAndTimeFormate) {
		this.dateAndTimeFormate = dateAndTimeFormate;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	@Override
	public String getUsername() {
		return email;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		UserPrincipal user = (UserPrincipal) o;
		return Objects.equals(id, user.id);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());

		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	public String getCurrency() {
		return this.currency;
	}

	public String getRole() {
		return role;
	}

	public boolean isSystemAdmin() {
		if (this.role == null)
			return false;
		return (this.role.equals(User.ROLE_ADMIN));
	}

//	public boolean isBusinessAdmin() {
//		if (this.role == null)
//			return false;
//		return (this.role.equals(User.ROLE_BUSINESS_ADMIN));
//	}

	public boolean isCompanyUser() {
		if (this.role == null)
			return false;
		return (this.role.equals(User.ROLE_COMPANY_USER));
	}

//	public boolean isSystemIntegration() {
//		if (this.role == null)
//			return false;
//		return (this.role.equals(User.ROLE_SYSTEM_INTEGRATION)) ? true : false;
//	}

	public boolean isSupplierUser() {
		if (this.role == null)
			return false;
		return (this.role.equals(User.ROLE_SUPPLIER_USER)) ? true : false;
	}

	private static List<SimpleGrantedAuthority> getGrantAutoorities(User user) {
		logger.info("UserPrinciple -> getGrantAutoorities for {}", user.getEmail());
		List<SimpleGrantedAuthority> authorities = new ArrayList<>();
		//if (user.getRole().equals(User.ROLE_BUSINESS_ADMIN)) {
		//	authorities.add(new SimpleGrantedAuthority(RoleName.ROLE_BUSINESS_ADMIN.name()));
		//} else 
		//if (user.getRole().equals(User.ROLE_SYSTEM_ADMIN)) {
		//	authorities.add(new SimpleGrantedAuthority(RoleName.ROLE_SYSTEM_ADMIN.name()));
		//} else
		if (user.getRole().equals(User.ROLE_COMPANY_USER)) {
			authorities.add(new SimpleGrantedAuthority(RoleName.ROLE_COMPANY_USER.name()));
		} 
		else if (user.getRole().equals(User.ROLE_SYSTEM_ADMIN)) {
			authorities.add(new SimpleGrantedAuthority(RoleName.ROLE_SYSTEM_ADMIN.name()));
		} 
		//else if (user.getRole().equals(User.ROLE_SYSTEM_INTEGRATION)) {
		//	authorities.add(new SimpleGrantedAuthority(RoleName.ROLE_SYSTEM_INTEGRATION.name()));
		//}

		else if (user.getRole().equals("SupplierUser")) {
			authorities.add(new SimpleGrantedAuthority(RoleName.ROLE_SUPPLIER_USER.name()));
		}
//	    	else if(user.getRole().equals(User.ROLE_VENDOR))
//	    	{
//	    		authorities.add(new SimpleGrantedAuthority(RoleName.ROLE_VENDOR.name()));
//	    	}
		return authorities;
	}

	public static UserPrincipal build(User user,Map<String,Permission> permissions) {
		logger.info("UserPrinciple -> build");
		List<SimpleGrantedAuthority> authorities = getGrantAutoorities(user);
		return new UserPrincipal(user, authorities,permissions

		);
	}

	public String getVendorId() {
		return vendorId;
	}

	 

//		public String getSystemId() {
//			return systemId;
//		}

//		public AccessControlList getAcl() {
//			return acl;
//		}
	public Map<String,Permission> getPermissions() {
		return permissions;
	}
	public List<String> getPermissionsGroups() {
		return permissionsGroups;
	}
}
