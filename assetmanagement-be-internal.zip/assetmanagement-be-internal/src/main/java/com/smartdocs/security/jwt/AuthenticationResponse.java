package com.smartdocs.security.jwt;

import java.io.Serializable;

import com.smartdocs.mongo.collections.User;


public class AuthenticationResponse implements Serializable {

	public static final String LOGIN_BASIC_UP = "basic";

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private User user;
	private String accessToken;
	private String loginType;

	public AuthenticationResponse( String accessToken,User user, String loginType) {
		super();
		this.accessToken = accessToken;
		this.user = user;
		this.loginType = loginType;
	}


	public User getUser() {
		return user;
	}



	public void setUser(User user) {
		this.user = user;
	}



	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

}
