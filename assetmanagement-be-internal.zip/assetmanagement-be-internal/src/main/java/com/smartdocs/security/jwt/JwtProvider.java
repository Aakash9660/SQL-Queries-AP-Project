package com.smartdocs.security.jwt;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.smartdocs.security.service.UserPrincipal;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;

@Component
public class JwtProvider {

	private static final Logger logger = LoggerFactory.getLogger(JwtProvider.class);

	@Value("${grokonez.app.jwtSecret}")
	private String jwtSecret;

	@Value("${grokonez.app.jwtExpiration}")
	private int jwtExpiration;

	public String generateJwtToken(Authentication authentication, String ipAddress) {
		logger.info("JwtProvider -> generateJwtToken");
		UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();

		Claims claims = Jwts.claims().setSubject(userPrincipal.getUsername());
		claims.put("username", userPrincipal.getUsername());
		claims.put("role", userPrincipal.getRole());
		claims.put("email", userPrincipal.getEmail());

		return Jwts.builder().setSubject((userPrincipal.getUsername())).setClaims(claims).setIssuedAt(new Date())
				.setExpiration(new Date((new Date()).getTime() + jwtExpiration * 1000))
				.signWith(SignatureAlgorithm.HS512, jwtSecret + "_" + ipAddress).compact();
	}

	public String generateJwtTokenForMSAUser(UserPrincipal userprinciple, String ipAddress) {
		logger.info("JwtProvider -> generateJwtTokenForMSAUser {}", userprinciple.getEmail());
		Claims claims = Jwts.claims().setSubject(userprinciple.getUsername());
		claims.put("username", userprinciple.getUsername());
		claims.put("role", userprinciple.getRole());
		claims.put("email", userprinciple.getEmail());

		return Jwts.builder().setSubject((userprinciple.getUsername())).setClaims(claims).setIssuedAt(new Date())
				.setExpiration(new Date((new Date()).getTime() + jwtExpiration * 1000))
				.signWith(SignatureAlgorithm.HS512, jwtSecret + "_" + ipAddress).compact();
	}

	public boolean validateJwtToken(String authToken, String ipAddress) {
		System.out.println("Ip Address to validate JWT Token is "+ ipAddress);
		logger.info("Ip Address to validate JWT Token is {}", ipAddress);
		try {
			Jwts.parser().setSigningKey(jwtSecret + "_" + ipAddress).parseClaimsJws(authToken);
			return true;
		} catch (SignatureException e) {
			logger.error("Invalid JWT signature -> Message: {} ", e.getMessage());
		} catch (MalformedJwtException e) {
			logger.error("Invalid JWT token -> Message: {}", e.getMessage());
		} catch (ExpiredJwtException e) {
			logger.info("Expired JWT token -> Message: {}", e.getMessage());
		} catch (UnsupportedJwtException e) {
			logger.error("Unsupported JWT token -> Message: {}", e.getMessage());
		} catch (IllegalArgumentException e) {
			logger.error("JWT claims string is empty -> Message: {}", e.getMessage());
		}

		return false;
	}

	/**
	 * This method helps user when one user is part of multiple vendors.
	 */
	public String generateJwtToken(UserPrincipal userPrincipal, String ipAddress) {
		logger.info("JwtProvider -> generateJwtToken for {}", userPrincipal.getEmail());
		Claims claims = Jwts.claims().setSubject(userPrincipal.getUsername());
		claims.put("username", userPrincipal.getUsername());
		claims.put("role", userPrincipal.getRole());
		claims.put("email", userPrincipal.getEmail());

		return Jwts.builder().setSubject((userPrincipal.getUsername())).setClaims(claims).setIssuedAt(new Date())
				.setExpiration(new Date((new Date()).getTime() + jwtExpiration * 1000))
				.signWith(SignatureAlgorithm.HS512, jwtSecret + "_" + ipAddress).compact();
	}

}