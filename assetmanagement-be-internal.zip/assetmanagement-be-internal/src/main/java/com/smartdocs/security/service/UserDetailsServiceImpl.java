package com.smartdocs.security.service;

import java.time.ZonedDateTime;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smartdocs.mongo.collectionhelpers.Permission;
import com.smartdocs.mongo.collections.User;
import com.smartdocs.mongo.repository.UserRepository;
import com.smartdocs.service.AuthProfileService;

 

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private AuthProfileService authProfileService;

	private static final Logger logger = LoggerFactory.getLogger(UserDetailsServiceImpl.class);

	public boolean logoutDeleteToken(String app, String email) {
		logger.info("UserDetailsServiceImpl -> logoutDeleteToken for: {}", email);
		Optional<User> user = userRepository.findByEmailIgnoreCase(email);
		if (user.isPresent()) {
			user.get().setAccessToken(null);

			userRepository.save(user.get());
		}
		return true;
	}

	@Override
	@Transactional
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException, LockedException, DisabledException {
		logger.debug("loadUserByUsername {}", username);

		User user = userRepository.findByEmailIgnoreCase(username).orElseThrow(
				() -> new UsernameNotFoundException("User Not Found with -> username or email : " + username));
		logger.debug("user Found {}", user.getId());

		if (!user.isEmailEnabled()) {
			throw new DisabledException("ACOUNT_DISABLED");
		}
		
		return loadUserByUser(user);
	}

	@Transactional
	public UserDetails loadUserByUser(User user) throws UsernameNotFoundException, LockedException, DisabledException {
		Map<String,Permission> pg= null;
		if (!user.isEmailEnabled()) {
			logger.error("{} Account is disabled by admin. cound not login.", user.getEmail());
			throw new DisabledException("ACOUNT_DISABLED");
		}
		if(user.getLastActivity()!=null) {
			System.out.println(" last activity before 3 min >> " + user.getLastActivity().plusMinutes(3).isBefore(ZonedDateTime.now()));
		}
		if(user.getLastActivity()==null || user.getLastActivity().plusMinutes(3).isBefore(ZonedDateTime.now()) ) {
			user.setLastActivity(ZonedDateTime.now());
			userRepository.save(user);
		}
		 if(user.getRole().equals("CompanyUser")) {
			 pg= authProfileService.getAllPermissionGroups(user);
		}
		logger.info("User found in db. with email: {}", user.getEmail());

		return UserPrincipal.build(user,pg);
	}

}