package com.smartdocs.security.jwt;


import java.io.IOException;
import java.io.PrintWriter;
import java.time.ZonedDateTime;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.UrlPathHelper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.smartdocs.dto.JsonResponse;
import com.smartdocs.mongo.collections.User;
import com.smartdocs.mongo.repository.UserRepository;
import com.smartdocs.security.service.UserDetailsServiceImpl;
import com.smartdocs.service.util.HttpReqRespUtils;

import io.jsonwebtoken.ExpiredJwtException;

public class JwtAuthTokenFilter extends OncePerRequestFilter {

    @Autowired
    private JwtProvider tokenProvider;

    @Autowired
    private UserDetailsServiceImpl userDetailsService;
    
    @Autowired
    private UserRepository userRepository;
    
    @Value("${grokonez.app.sessionExpiration}")
    private int sessionExpiration;
    

    private static final Logger log = LoggerFactory.getLogger(JwtAuthTokenFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request, 
    								HttpServletResponse response, 
    								FilterChain filterChain) 
    										throws ServletException, IOException {
    	boolean returnError=false;
    	boolean invalidJWT=false;
        try {
        	
            String jwt = getJwt(request);
             
            String path = new UrlPathHelper().getPathWithinApplication(request);
            log.info("path : {}", path);
            if (StringUtils.isNotBlank(jwt) && !jwt.equals("undefined")) {
            	if(tokenProvider.validateJwtToken(jwt,HttpReqRespUtils.getClientIpAddressIfServletRequestExist()))
            	{
            		User user=userRepository.findOneByAccessToken(jwt);
            		if(user==null) {
            			user=userRepository.findOneByAppAccessToken(jwt);	
            		}
                	if(user!=null && user.isEmailEnabled()) {
                		  if(!user.getLastActivity().plusMinutes(sessionExpiration).isBefore(ZonedDateTime.now()))
                		  {
                			  log.info("User {}, role {} is accessing {}", user.getEmail(), user.getRole(), path);
                    		  UserDetails userDetails=   userDetailsService.loadUserByUser(user);
                              UsernamePasswordAuthenticationToken authentication 
                              		= new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                              authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                              SecurityContextHolder.getContext().setAuthentication(authentication);
                		  }
                		  else {
                			  invalidJWT=true;
                		  }
                		 
                	} 
                	else if(StringUtils.isNotBlank(jwt) && !jwt.equals("undefined")) {
               	 		returnError=true;
               	 		log.info("Error: Invalid auth header");
               	 		log.debug(jwt);
                	}
            	}
            	else {
            		invalidJWT=true;
            	}
            }
            else if(StringUtils.isNotBlank(jwt)) {
           	 log.info("Error: Invalid auth header");
           	 log.debug(jwt);
           }
        } 
        catch (ExpiredJwtException ex) {
            log.error("Can NOT set user authentication -> Message:", ex);
            throw ex;
        } 
        catch (Exception e) {
            log.error("Can NOT set user authentication -> Message: {}", e.getMessage());
        }
        if(returnError) {
        	
             PrintWriter writer = response.getWriter();
              response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
              JsonResponse resp=new JsonResponse();
              resp.setMessage("LOGGED_OUT");
              writer.write(convertObjectToJson(resp));
             response.setContentType("application/json");
             
             writer.flush();
             return;
        }
        if(invalidJWT) {
        	 PrintWriter writer = response.getWriter();
             response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
             JsonResponse resp=new JsonResponse();
             resp.setMessage("SESSION_EXPIRED");
             writer.write(convertObjectToJson(resp));
             response.setContentType("application/json");
             writer.flush();
             return;
        	
        }
        else{
        	filterChain.doFilter(request, response);
        }
    }
    public String convertObjectToJson(Object object) throws JsonProcessingException {
        if (object == null) {
            return null;
        }
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(object);
    }
    private String getJwt(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
        	return authHeader.replace("Bearer ","");
        }

        return null;
    }
}
